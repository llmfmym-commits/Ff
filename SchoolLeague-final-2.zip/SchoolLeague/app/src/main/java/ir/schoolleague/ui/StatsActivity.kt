package ir.schoolleague.ui

import android.os.Bundle
import android.widget.LinearLayout
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import ir.schoolleague.data.Sport
import ir.schoolleague.data.Status
import kotlinx.coroutines.launch

/** Overall statistics across every league (bottom-nav tab). */
class StatsActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val r = buildScreen("آمار کلی", back = false, nav = 2)
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                repo.dao.observeAll().collect { leagues ->
                    val matches = repo.dao.allMatches().filter { !it.isBye }
                    val sportOf = leagues.associate { it.id to it.sport }
                    r.removeAllViews()
                    val total = Ui.card(this@StatsActivity)
                    total.addView(Ui.tv(this@StatsActivity, "خلاصه", 17f, true))
                    total.addView(line("تعداد لیگ‌ها", leagues.size))
                    total.addView(line("در حال برگزاری", leagues.count { it.status == Status.ACTIVE }))
                    total.addView(line("پایان‌یافته", leagues.count { it.status == Status.FINISHED }))
                    total.addView(line("مسابقه‌های انجام‌شده", matches.count { it.played }))
                    r.addView(total)
                    listOf(Sport.FOOTBALL, Sport.VOLLEYBALL, Sport.PINGPONG).forEach { s ->
                        val ls = leagues.filter { it.sport == s }
                        val ms = matches.filter { sportOf[it.leagueId] == s }
                        val c = Ui.card(this@StatsActivity)
                        c.addView(Ui.tv(this@StatsActivity, "${Labels.emoji(s)} ${Labels.sport(s)}", 16f, true))
                        c.addView(line("لیگ‌ها", ls.size))
                        c.addView(line("مسابقه‌های انجام‌شده", ms.count { it.played }))
                        c.addView(line("مسابقه‌های باقی‌مانده", ms.count { !it.played }))
                        r.addView(c)
                    }
                }
            }
        }
    }

    private fun line(label: String, n: Int) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(6), 0, 0)
        addView(Ui.tv(this@StatsActivity, label, 14f, false, Ui.sub(this@StatsActivity)), Ui.lp(0, Ui.WRAP, 1f))
        addView(Ui.tv(this@StatsActivity, Ui.fa(n), 14f, true))
    }
}
