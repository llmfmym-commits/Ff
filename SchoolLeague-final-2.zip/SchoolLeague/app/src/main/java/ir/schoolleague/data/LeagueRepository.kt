package ir.schoolleague.data

import androidx.room.withTransaction
import ir.schoolleague.engine.FootballRules
import ir.schoolleague.engine.KnockoutBracket
import ir.schoolleague.engine.PingPongRules
import ir.schoolleague.engine.ScheduleGenerator
import ir.schoolleague.engine.SetMatchRules
import ir.schoolleague.engine.VolleyballRules

class LeagueRepository(private val db: AppDatabase) {
    val dao = db.dao()

    companion object {
        fun defaultSettings(leagueId: Long, sport: String): LeagueSettings = when (sport) {
            Sport.FOOTBALL -> LeagueSettings(leagueId, 3, 1, 0, 11, 15, false)
            Sport.VOLLEYBALL -> LeagueSettings(leagueId, 2, 0, 0, 25, 15, false)
            else -> LeagueSettings(leagueId, 2, 0, 0, 11, 11, false)
        }

        fun rulesFor(sport: String, s: LeagueSettings): SetMatchRules? = when (sport) {
            Sport.PINGPONG -> PingPongRules(s.gamePoints)
            Sport.VOLLEYBALL -> VolleyballRules(s.gamePoints, s.deciderPoints)
            else -> null
        }
    }

    // ---------- creation ----------
    suspend fun createLeague(
        name: String, sport: String, format: String, names: List<String>,
        settings: LeagueSettings, shuffle: Boolean
    ): Long {
        require(name.isNotBlank()) { "نام لیگ نباید خالی باشد." }
        val clean = names.map { it.trim() }
        require(clean.size >= 2 && clean.all { it.isNotEmpty() }) { "نام شرکت‌کنندگان نامعتبر است." }
        require(clean.map { it.lowercase() }.toSet().size == clean.size) { "نام شرکت‌کنندگان تکراری است." }
        return db.withTransaction {
            val id = dao.insertLeague(League(name = name.trim(), sport = sport, format = format))
            val ordered = if (shuffle) clean.shuffled() else clean
            dao.insertParticipants(ordered.mapIndexed { i, n -> Participant(leagueId = id, name = n, seed = i) })
            dao.saveSettings(settings.copy(leagueId = id))
            buildMatches(id)
            id
        }
    }

    private suspend fun buildMatches(leagueId: Long) {
        val league = dao.getLeague(leagueId)!!
        val ps = dao.getParticipants(leagueId)
        val st = dao.getSettings(leagueId)!!
        val list = ArrayList<MatchEntity>()
        if (league.format == Format.KNOCKOUT) {
            val br = KnockoutBracket(ps.size)
            fun idOf(seed: Int): Long? = if (seed >= 0) ps[seed].id else null
            for (r in 0 until br.rounds) for (nd in br.round(r)) {
                val bye = nd.isBye
                val winner = if (bye) idOf(if (nd.a >= 0) nd.a else nd.b) else null
                list.add(MatchEntity(leagueId = leagueId, round = r, indexInRound = nd.index,
                    aId = idOf(nd.a), bId = idOf(nd.b), played = bye, winnerId = winner, isBye = bye))
            }
        } else {
            val counter = HashMap<Int, Int>()
            for (p in ScheduleGenerator.roundRobin(ps.size, st.doubleRound)) {
                val idx = counter.getOrDefault(p.round, 0)
                counter[p.round] = idx + 1
                list.add(MatchEntity(leagueId = leagueId, round = p.round - 1, indexInRound = idx,
                    aId = ps[p.a].id, bId = ps[p.b].id))
            }
        }
        dao.insertMatches(list)
    }

    // ---------- results ----------
    suspend fun saveSetResult(matchId: Long, games: List<IntArray>): String? = db.withTransaction<String?> {
        val m = dao.getMatch(matchId) ?: return@withTransaction "مسابقه پیدا نشد."
        val league = dao.getLeague(m.leagueId)!!
        val st = dao.getSettings(m.leagueId)!!
        val rules = rulesFor(league.sport, st) ?: return@withTransaction "این ورزش نتیجه‌ی گیم/ست ندارد."
        if (m.aId == null || m.bId == null) return@withTransaction "هنوز دو طرف مسابقه مشخص نیست."
        val o = rules.evaluate(games)
        if (!o.valid) return@withTransaction o.error
        val winner = if (o.winner == 1) m.aId else m.bId
        applyResult(m, league, o.setsA, o.setsB, winner, null, null, false)
        dao.deleteGames(matchId)
        dao.insertGames(games.mapIndexed { i, g -> GameScore(matchId = matchId, gameNo = i + 1, pointsA = g[0], pointsB = g[1]) })
        null
    }

    suspend fun saveFootballResult(
        matchId: Long, a: Int, b: Int, penA: Int?, penB: Int?, extra: Boolean,
        yellowA: Int = 0, yellowB: Int = 0, redA: Int = 0, redB: Int = 0, dateText: String? = null
    ): String? =
        db.withTransaction<String?> {
            val m = dao.getMatch(matchId) ?: return@withTransaction "مسابقه پیدا نشد."
            val league = dao.getLeague(m.leagueId)!!
            if (m.aId == null || m.bId == null) return@withTransaction "هنوز دو طرف مسابقه مشخص نیست."
            FootballRules.validateScore(a, b)?.let { return@withTransaction it }
            val winner: Long?
            if (league.format == Format.KNOCKOUT) {
                val w = FootballRules.knockoutWinner(a, b, penA, penB)
                if (w == 0) return@withTransaction "در مسابقه‌ی حذفی، تساوی باید با ضربات پنالتی (بدون تساوی) مشخص شود."
                winner = if (w == 1) m.aId else m.bId
            } else {
                winner = when (FootballRules.leagueWinner(a, b)) { 1 -> m.aId; 2 -> m.bId; else -> null }
            }
            val pa = if (a == b && league.format == Format.KNOCKOUT) penA else null
            val pb = if (a == b && league.format == Format.KNOCKOUT) penB else null
            if (yellowA < 0 || yellowB < 0 || redA < 0 || redB < 0) return@withTransaction "تعداد کارت‌ها نمی‌تواند منفی باشد."
            applyResult(m, league, a, b, winner, pa, pb, extra) {
                it.copy(yellowA = yellowA, yellowB = yellowB, redA = redA, redB = redB, dateText = dateText)
            }
            null
        }

    private suspend fun applyResult(m: MatchEntity, league: League, sa: Int, sb: Int, winner: Long?,
                                    penA: Int?, penB: Int?, extra: Boolean,
                                    more: (MatchEntity) -> MatchEntity = { it }) {
        if (league.format == Format.KNOCKOUT) {
            if (m.played && m.winnerId != winner) clearDownstream(m)
            setNextSlot(m, winner)
        }
        dao.updateMatch(more(m.copy(played = true, winnerId = winner, scoreA = sa, scoreB = sb,
            penA = penA, penB = penB, extraTime = extra)))
    }

    private suspend fun nextOf(m: MatchEntity): MatchEntity? =
        dao.getMatches(m.leagueId).firstOrNull { it.round == m.round + 1 && it.indexInRound == m.indexInRound / 2 }

    private suspend fun setNextSlot(m: MatchEntity, winner: Long?) {
        val nx = nextOf(m) ?: return
        dao.updateMatch(if (m.indexInRound % 2 == 0) nx.copy(aId = winner) else nx.copy(bId = winner))
    }

    private suspend fun clearDownstream(m: MatchEntity) {
        val nx = nextOf(m) ?: return
        val wasPlayed = nx.played
        val cleared = if (m.indexInRound % 2 == 0) nx.copy(aId = null) else nx.copy(bId = null)
        dao.updateMatch(cleared.copy(played = false, winnerId = null, scoreA = 0, scoreB = 0,
            penA = null, penB = null, extraTime = false,
            yellowA = 0, yellowB = 0, redA = 0, redB = 0, dateText = null))
        dao.deleteGames(nx.id)
        if (wasPlayed) clearDownstream(nx)
    }

    /** True when editing/deleting this knockout result would affect an already played later match. */
    suspend fun hasDependentResults(matchId: Long): Boolean {
        val m = dao.getMatch(matchId) ?: return false
        val league = dao.getLeague(m.leagueId) ?: return false
        if (league.format != Format.KNOCKOUT) return false
        val nx = nextOf(m) ?: return false
        return nx.played
    }

    suspend fun deleteResult(matchId: Long) = db.withTransaction {
        val m = dao.getMatch(matchId) ?: return@withTransaction
        if (m.isBye) return@withTransaction
        val league = dao.getLeague(m.leagueId)!!
        if (league.format == Format.KNOCKOUT) clearDownstream(m)
        dao.updateMatch(m.copy(played = false, winnerId = null, scoreA = 0, scoreB = 0,
            penA = null, penB = null, extraTime = false,
            yellowA = 0, yellowB = 0, redA = 0, redB = 0, dateText = null))
        dao.deleteGames(matchId)
    }

    // ---------- league / participants ----------
    suspend fun renameLeague(id: Long, name: String) {
        val l = dao.getLeague(id) ?: return
        if (name.isNotBlank()) dao.updateLeague(l.copy(name = name.trim()))
    }

    suspend fun setFinished(id: Long, finished: Boolean) {
        val l = dao.getLeague(id) ?: return
        dao.updateLeague(l.copy(status = if (finished) Status.FINISHED else Status.ACTIVE))
    }

    suspend fun deleteLeague(id: Long) = dao.deleteLeague(id)

    suspend fun renameParticipant(p: Participant, name: String): String? {
        val n = name.trim()
        if (n.isEmpty()) return "نام نباید خالی باشد."
        val others = dao.getParticipants(p.leagueId).filter { it.id != p.id }
        if (others.any { it.name.equals(n, ignoreCase = true) }) return "این نام تکراری است."
        dao.updateParticipant(p.copy(name = n))
        return null
    }

    suspend fun canEditStructure(leagueId: Long): Boolean =
        dao.getMatches(leagueId).none { it.played && !it.isBye }

    suspend fun addParticipant(leagueId: Long, name: String): String? = db.withTransaction<String?> {
        val n = name.trim()
        if (n.isEmpty()) return@withTransaction "نام نباید خالی باشد."
        if (!canEditStructure(leagueId)) return@withTransaction "پس از ثبت نتیجه نمی‌توان شرکت‌کننده اضافه کرد."
        val ps = dao.getParticipants(leagueId)
        if (ps.any { it.name.equals(n, ignoreCase = true) }) return@withTransaction "این نام تکراری است."
        dao.insertParticipants(listOf(Participant(leagueId = leagueId, name = n, seed = (ps.maxOfOrNull { it.seed } ?: -1) + 1)))
        dao.deleteMatchesOf(leagueId)
        buildMatches(leagueId)
        null
    }

    suspend fun removeParticipant(p: Participant): String? = db.withTransaction<String?> {
        if (!canEditStructure(p.leagueId)) return@withTransaction "پس از ثبت نتیجه نمی‌توان شرکت‌کننده حذف کرد."
        if (dao.countParticipants(p.leagueId) <= 2) return@withTransaction "حداقل دو شرکت‌کننده لازم است."
        dao.deleteMatchesOf(p.leagueId)
        dao.deleteParticipant(p.id)
        buildMatches(p.leagueId)
        null
    }

    suspend fun saveSettings(s: LeagueSettings) = dao.saveSettings(s)

    // ---------- backup ----------
    suspend fun exportJson(): String = BackupCodec.encode(
        BackupData(dao.allLeagues(), dao.allParticipants(), dao.allMatches(), dao.allGames(), dao.allSettings())
    )

    /** Throws IllegalArgumentException (Persian message) for invalid files; nothing is changed then. */
    suspend fun importJson(text: String) {
        val d = BackupCodec.decode(text)
        db.withTransaction {
            dao.clearAll()
            d.leagues.forEach { dao.insertLeague(it) }
            dao.insertParticipants(d.participants)
            dao.insertMatches(d.matches)
            dao.insertGames(d.games)
            d.settings.forEach { dao.saveSettings(it) }
        }
    }
}
