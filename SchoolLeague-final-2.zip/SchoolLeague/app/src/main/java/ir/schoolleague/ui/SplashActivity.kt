package ir.schoolleague.ui

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c = this
        val root = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(Ui.bg(c)); setPadding(Ui.dp(c, 32), Ui.dp(c, 32), Ui.dp(c, 32), Ui.dp(c, 40))
        }
        root.addView(View(c), Ui.lp(Ui.MATCH, 0, 1f))
        root.addView(Ui.tv(c, "🏆", 110f).apply { gravity = Gravity.CENTER })
        root.addView(Ui.tv(c, "SchoolLeague", 34f, true, if (Ui.isDark(c)) Color.WHITE else Prefs.primary(c)).apply {
            gravity = Gravity.CENTER; setPadding(0, Ui.dp(c, 16), 0, Ui.dp(c, 8))
        })
        root.addView(Ui.tv(c, "مدیریت لیگ‌های ورزشی مدرسه", 16f, true).apply { gravity = Gravity.CENTER })
        root.addView(View(c), Ui.lp(Ui.MATCH, 0, 1.3f))
        root.addView(Ui.button(c, "شروع") {
            startActivity(Intent(c, MainActivity::class.java)); finish()
        }, Ui.lp())
        setContentView(root)
        window.statusBarColor = Ui.bg(c)
    }
}
