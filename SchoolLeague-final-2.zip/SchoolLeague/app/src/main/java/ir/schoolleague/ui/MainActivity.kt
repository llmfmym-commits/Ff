package ir.schoolleague.ui

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.PopupMenu
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import ir.schoolleague.data.Sport
import ir.schoolleague.data.Status
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

class MainActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val r = buildScreen("SchoolLeague", back = false, nav = 0, titleAtStart = true)
        addHeaderAction("☰", "منو") { anchor ->
            val pm = PopupMenu(this, anchor)
            pm.menu.add(0, 1, 0, "لیگ‌های من"); pm.menu.add(0, 2, 1, "آمار"); pm.menu.add(0, 3, 2, "تنظیمات")
            pm.setOnMenuItemClickListener {
                startActivity(Intent(this, when (it.itemId) { 1 -> LeagueListActivity::class.java; 2 -> StatsActivity::class.java; else -> SettingsActivity::class.java }))
                true
            }
            pm.show()
        }
        r.addView(Ui.tv(this, "انتخاب ورزش", 20f, true).apply { setPadding(dp(2), 0, dp(2), dp(12)) })

        fun openList(s: String) = startActivity(Intent(this, LeagueListActivity::class.java).putExtra(LeagueListActivity.EXTRA_SPORT, s))
        val create = { startActivity(Intent(this, CreateLeagueActivity::class.java)) }
        val rows = listOf(
            listOf(Triple("⚽", "فوتبال", 0xFF16A34A.toInt()) to { openList(Sport.FOOTBALL) },
                Triple("🏐", "والیبال", 0xFFF97316.toInt()) to { openList(Sport.VOLLEYBALL) }),
            listOf(Triple("➕", "ساخت لیگ جدید", 0xFF1677FF.toInt()) to create,
                Triple("🏓", "پینگ‌پنگ", 0xFF7C3AED.toInt()) to { openList(Sport.PINGPONG) })
        )
        var idx = 0
        rows.forEach { pair ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEachIndexed { j, (info, action) ->
                val card = sportCard(info.first, info.second, info.third, action)
                row.addView(card, Ui.lp(0, Ui.WRAP, 1f, this, if (j == 0) 6 else 0, 0, if (j == 0) 0 else 6, 0))
                Ui.fadeIn(card, idx++)
            }
            r.addView(row, Ui.lp(c = this, b = 12))
        }

        val sub = Ui.tv(this, "مشاهده و مدیریت لیگ‌های ایجاد شده", 12f, false, Ui.sub(this))
        val mine = Ui.card(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            isClickable = true; isFocusable = true; contentDescription = "لیگ‌های من"
            setOnClickListener { startActivity(Intent(this@MainActivity, LeagueListActivity::class.java)) }
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(Ui.tv(this, "لیگ‌های من", 16f, true)); col.addView(sub)
        mine.addView(col, Ui.lp(0, Ui.WRAP, 1f))
        mine.addView(Ui.badge(this, "📅", Ui.line(this), 44, Color.WHITE, 22f))
        r.addView(mine)

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                combine(repo.dao.countByStatus(Status.ACTIVE), repo.dao.countByStatus(Status.FINISHED)) { a, f -> a to f }
                    .collect { sub.text = "${Ui.fa(it.first)} در حال برگزاری • ${Ui.fa(it.second)} پایان‌یافته" }
            }
        }
    }

    private fun sportCard(emoji: String, label: String, color: Int, onClick: () -> Unit): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            background = Ui.rounded(color, dp(20)); elevation = dp(3).toFloat()
            minimumHeight = dp(132); isClickable = true; isFocusable = true
            contentDescription = label
            setOnClickListener { onClick() }
        }
        card.addView(Ui.badge(this, emoji, 0x33FFFFFF, 56, Color.WHITE, 28f))
        card.addView(Ui.tv(this, "$label ‹", 16f, true, Color.WHITE).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, 0) })
        return card
    }
}
