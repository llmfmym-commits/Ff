/* Nova Python 3D Studio: runs Python (Pyodide), converts the result to GLB for <model-viewer>. */
var py = null;
var ready = false;
var currentScene = null;
var currentUrl = null;
var mv = null;

function nativeCall(name, a, b, c) {
  try {
    if (typeof Nova !== 'undefined' && Nova.event) {
      Nova.event(name, a === undefined ? '' : String(a), b === undefined ? '' : String(b), c === undefined ? '' : String(c));
    }
  } catch (e) {}
}

function setStatus(text) {
  var el = document.getElementById('status');
  if (el) { el.textContent = text; el.style.display = text ? 'block' : 'none'; }
}

function u8ToB64(u8) {
  var s = '';
  var chunk = 0x8000;
  for (var i = 0; i < u8.length; i += chunk) {
    s += String.fromCharCode.apply(null, u8.subarray(i, i + chunk));
  }
  return btoa(s);
}

// ---------- GLB (Y-up; Python data is Z-up) ----------
function buildGLB(scene) {
  var meshes = scene.meshes;
  if (!meshes || meshes.length === 0) return null;
  var chunks = [];
  var offset = 0;
  var bufferViews = [], accessors = [], gltfMeshes = [], nodes = [], materials = [], sceneNodes = [];
  for (var i = 0; i < meshes.length; i++) {
    var m = meshes[i];
    var n = m.positions.length / 3;
    var pos = new Float32Array(n * 3);
    var nor = new Float32Array(n * 3);
    var mn = [Infinity, Infinity, Infinity], mx = [-Infinity, -Infinity, -Infinity];
    for (var k = 0; k < n; k++) {
      var x = m.positions[3 * k], y = m.positions[3 * k + 1], z = m.positions[3 * k + 2];
      pos[3 * k] = x; pos[3 * k + 1] = z; pos[3 * k + 2] = -y;
      nor[3 * k] = m.normals[3 * k]; nor[3 * k + 1] = m.normals[3 * k + 2]; nor[3 * k + 2] = -m.normals[3 * k + 1];
      for (var a = 0; a < 3; a++) {
        var v = pos[3 * k + a];
        if (v < mn[a]) mn[a] = v;
        if (v > mx[a]) mx[a] = v;
      }
    }
    var bv0 = bufferViews.length;
    bufferViews.push({ buffer: 0, byteOffset: offset, byteLength: pos.byteLength, target: 34962 });
    chunks.push(new Uint8Array(pos.buffer)); offset += pos.byteLength;
    bufferViews.push({ buffer: 0, byteOffset: offset, byteLength: nor.byteLength, target: 34962 });
    chunks.push(new Uint8Array(nor.buffer)); offset += nor.byteLength;
    var ac0 = accessors.length;
    accessors.push({ bufferView: bv0, componentType: 5126, count: n, type: 'VEC3', min: mn, max: mx });
    accessors.push({ bufferView: bv0 + 1, componentType: 5126, count: n, type: 'VEC3' });
    materials.push({
      name: m.name,
      pbrMetallicRoughness: { baseColorFactor: m.color, metallicFactor: 0.15, roughnessFactor: 0.55 },
      doubleSided: true
    });
    gltfMeshes.push({ name: m.name, primitives: [{ attributes: { POSITION: ac0, NORMAL: ac0 + 1 }, material: i, mode: 4 }] });
    nodes.push({ mesh: i, name: m.name });
    sceneNodes.push(i);
  }
  var json = {
    asset: { version: '2.0', generator: 'Nova Browser' },
    scene: 0, scenes: [{ nodes: sceneNodes }],
    nodes: nodes, meshes: gltfMeshes, materials: materials,
    accessors: accessors, bufferViews: bufferViews, buffers: [{ byteLength: offset }]
  };
  var jsonBytes = new TextEncoder().encode(JSON.stringify(json));
  var jsonPad = (4 - (jsonBytes.length % 4)) % 4;
  var jsonLen = jsonBytes.length + jsonPad;
  var binLen = offset;
  var total = 12 + 8 + jsonLen + 8 + binLen;
  var out = new Uint8Array(total);
  var dv = new DataView(out.buffer);
  dv.setUint32(0, 0x46546C67, true);
  dv.setUint32(4, 2, true);
  dv.setUint32(8, total, true);
  dv.setUint32(12, jsonLen, true);
  dv.setUint32(16, 0x4E4F534A, true);
  out.set(jsonBytes, 20);
  for (var p = 0; p < jsonPad; p++) out[20 + jsonBytes.length + p] = 0x20;
  var binStart = 20 + jsonLen;
  dv.setUint32(binStart, binLen, true);
  dv.setUint32(binStart + 4, 0x004E4942, true);
  var o = binStart + 8;
  for (var c = 0; c < chunks.length; c++) { out.set(chunks[c], o); o += chunks[c].length; }
  return out;
}

// ---------- STL (binary, Z-up, as modelled) ----------
function buildSTL(scene) {
  var tris = 0, i;
  for (i = 0; i < scene.meshes.length; i++) tris += scene.meshes[i].positions.length / 9;
  var buf = new ArrayBuffer(84 + tris * 50);
  var dv = new DataView(buf);
  var header = 'Nova Browser STL';
  for (i = 0; i < header.length; i++) dv.setUint8(i, header.charCodeAt(i));
  dv.setUint32(80, tris, true);
  var off = 84;
  for (i = 0; i < scene.meshes.length; i++) {
    var P = scene.meshes[i].positions;
    for (var t = 0; t < P.length; t += 9) {
      var ax = P[t], ay = P[t + 1], az = P[t + 2], bx = P[t + 3], by = P[t + 4], bz = P[t + 5], cx = P[t + 6], cy = P[t + 7], cz = P[t + 8];
      var ux = bx - ax, uy = by - ay, uz = bz - az, vx = cx - ax, vy = cy - ay, vz = cz - az;
      var nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
      var l = Math.sqrt(nx * nx + ny * ny + nz * nz) || 1;
      var vals = [nx / l, ny / l, nz / l, ax, ay, az, bx, by, bz, cx, cy, cz];
      for (var q = 0; q < 12; q++) { dv.setFloat32(off, vals[q], true); off += 4; }
      dv.setUint16(off, 0, true); off += 2;
    }
  }
  return new Uint8Array(buf);
}

// ---------- OBJ (text, Z-up) ----------
function buildOBJ(scene) {
  var lines = ['# Nova Browser OBJ'];
  var base = 1;
  for (var i = 0; i < scene.meshes.length; i++) {
    var m = scene.meshes[i];
    lines.push('o ' + m.name);
    var n = m.positions.length / 3;
    for (var k = 0; k < n; k++) {
      lines.push('v ' + m.positions[3 * k] + ' ' + m.positions[3 * k + 1] + ' ' + m.positions[3 * k + 2]);
    }
    for (var t = 0; t < n; t += 3) {
      lines.push('f ' + (base + t) + ' ' + (base + t + 1) + ' ' + (base + t + 2));
    }
    base += n;
  }
  return new TextEncoder().encode(lines.join('\n') + '\n');
}

function exportAs(fmt) {
  if (!currentScene || !currentScene.meshes || currentScene.meshes.length === 0) {
    nativeCall('error', 'ابتدا کد را اجرا کنید تا مدلی ساخته شود.');
    return;
  }
  var bytes, mime;
  if (fmt === 'stl') { bytes = buildSTL(currentScene); mime = 'model/stl'; }
  else if (fmt === 'obj') { bytes = buildOBJ(currentScene); mime = 'text/plain'; }
  else { bytes = buildGLB(currentScene); mime = 'model/gltf-binary'; fmt = 'glb'; }
  nativeCall('export', 'model.' + fmt, u8ToB64(bytes), mime);
}

// ---------- viewer controls ----------
function setAuto(v) { if (v) { mv.setAttribute('auto-rotate', ''); } else { mv.removeAttribute('auto-rotate'); } }
function setExposure(v) { mv.exposure = v; }
function setBg(c) { document.body.style.background = c; }
function setEnv(on) { if (on) { mv.setAttribute('environment-image', 'neutral'); } else { mv.removeAttribute('environment-image'); } }
function resetCam() { mv.cameraOrbit = 'auto auto auto'; mv.cameraTarget = 'auto auto auto'; mv.fieldOfView = 'auto'; }

function showScene(scene) {
  currentScene = scene;
  var glb = buildGLB(scene);
  if (!glb) { mv.removeAttribute('src'); return; }
  var url = URL.createObjectURL(new Blob([glb], { type: 'model/gltf-binary' }));
  mv.src = url;
  if (currentUrl) URL.revokeObjectURL(currentUrl);
  currentUrl = url;
}

// ---------- python ----------
function loadScript(src) {
  return new Promise(function (resolve, reject) {
    var s = document.createElement('script');
    s.src = src; s.onload = resolve; s.onerror = function () { reject(new Error('load failed: ' + src)); };
    document.head.appendChild(s);
  });
}

async function initPython() {
  try {
    var offline = location.search.indexOf('offline=1') >= 0;
    var base = offline ? 'https://nova.local/pyodide/' : 'https://cdn.jsdelivr.net/pyodide/v0.26.4/full/';
    setStatus('در حال بارگذاری پایتون…');
    await loadScript(base + 'pyodide.js');
    py = await loadPyodide({ indexURL: base });
    py.setStdout({ batched: function (s) { nativeCall('output', s); } });
    py.setStderr({ batched: function (s) { nativeCall('output', s); } });
    var libResponse = await fetch('https://nova.local/nova3d.py');
    if (!libResponse.ok) throw new Error('nova3d.py HTTP ' + libResponse.status);
    var lib = await libResponse.text();
    py.FS.writeFile('nova3d.py', lib);
    py.runPython("import sys, os\nif os.getcwd() not in sys.path:\n    sys.path.insert(0, os.getcwd())\nimport nova3d");
    ready = true;
    setStatus('');
    nativeCall('ready');
  } catch (e) {
    setStatus('');
    nativeCall('error', 'بارگذاری پایتون ناموفق بود. اینترنت لازم است (یا فایل‌های Pyodide را داخل assets بگذارید). ' + e);
  }
}

async function runCode(code) {
  if (!ready) { nativeCall('error', 'پایتون هنوز آماده نیست.'); return; }
  try {
    setStatus('در حال اجرا…');
    py.runPython('import nova3d\nnova3d._reset()');
    py.globals.set('_nova_code', code);
    await new Promise(function (r) { setTimeout(r, 30); });
    py.runPython("_g = {'__name__': '__main__'}\nexec(compile(_nova_code, '<nova>', 'exec'), _g)\ndel _g");
    var json = py.runPython('import nova3d\nnova3d._export_json()');
    var scene = JSON.parse(json);
    showScene(scene);
    setStatus('');
    nativeCall('done', JSON.stringify(scene.stats));
  } catch (e) {
    setStatus('');
    var msg = String(e);
    var lines = msg.split('\n');
    if (lines.length > 8) { lines = lines.slice(lines.length - 8); }
    nativeCall('error', lines.join('\n'));
  }
}

window.addEventListener('load', function () {
  mv = document.getElementById('mv');
  initPython();
});
