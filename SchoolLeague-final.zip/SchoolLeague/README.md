# لیگ مدرسه — مدیریت مسابقات ورزشی (اندروید)

برنامه‌ی بومی اندروید (Kotlin + Java) برای مدیریت لیگ‌های **پینگ‌پنگ، فوتبال و والیبال** با قالب **حذفی** یا **لیگ جدولی**؛ راست‌چین و فارسی، با ذخیره‌ی دائمی در Room.

## ساختار
- `engine/` (Java): قوانین مسابقه (`PingPongRules`, `VolleyballRules`, `FootballRules`)، تولید برنامه (`ScheduleGenerator`)، نمودار حذفی با Bye (`KnockoutBracket`) و جدول (`StandingsCalculator`).
- `data/` (Kotlin): موجودیت‌های Room، DAO، `LeagueRepository` و `BackupCodec` (پشتیبان JSON).
- `ui/` (Kotlin): صفحه‌ها (اصلی، ساخت لیگ ۵‌مرحله‌ای، فهرست لیگ‌ها، صفحه‌ی لیگ، تنظیمات).

## قوانین مهم
- پینگ‌پنگ: بهترین از ۳ گیم، هر گیم تا ۱۱ با اختلاف ۲؛ گیم سوم فقط در ۱–۱ فعال است.
- والیبال: بهترین از ۳ ست؛ ۲۵ امتیاز و ست سوم ۱۵ (قابل تنظیم)، اختلاف ۲.
- فوتبال: بر اساس گل؛ در حذفی، تساوی فقط با پنالتی (بدون تساوی) تعیین تکلیف می‌شود.
- ویرایش/حذف نتیجه در حذفی، نتایج وابسته‌ی مراحل بعد را پس از تأیید شما پاک می‌کند.

## اجرا در Android Studio
1. پوشه را باز کنید (JDK 17). Gradle Wrapper را یک‌بار بسازید: `gradle wrapper --gradle-version 8.7`
2. اجرای تست‌ها: `./gradlew testDebugUnitTest`
3. ساخت APK: `./gradlew assembleDebug` ← `app/build/outputs/apk/debug/app-debug.apk`
4. تست Room روی دستگاه/شبیه‌ساز: `./gradlew connectedDebugAndroidTest`

## بارگذاری روی GitHub و دریافت APK
1. مخزن جدید بسازید و محتوای پوشه را Push کنید (پوشه‌ی `.github` باید در ریشه باشد).
2. تب **Actions** ← گردش‌کار «Build Android APK» (با هر Push یا اجرای دستی `Run workflow`).
3. پس از موفقیت، از پایین صفحه‌ی اجرا، Artifact با نام **SchoolLeague-debug-apk** را دانلود کنید.
4. اگر تست یا Build شکست بخورد، گردش‌کار Failed می‌شود.

## انتشار نسخه‌ی Release (بدون قرار دادن کلید در مخزن)
کلید امضا را هرگز Commit نکنید. فایل `.jks` را Base64 کنید و در **Settings ← Secrets and variables ← Actions** این Secretها را بسازید: `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`. در گردش‌کار، کلید را در مرحله‌ی Build از Secret به فایل موقت decode کنید و `signingConfigs` را از متغیرهای محیطی بخوانید.

## فونت
فونت‌های سیستمی در تنظیمات قابل انتخاب‌اند. برای فونت فارسی، فایل مجاز (مثلاً وزیرمتن با مجوز OFL) را با نام `vazirmatn.ttf` در `app/src/main/res/font/` بگذارید؛ خودکار در فهرست ظاهر می‌شود.

## محدودیت‌های شناخته‌شده
- گل‌زنان فوتبال ثبت نمی‌شوند، پس آمار گل‌زنان نمایش داده نمی‌شود.
- افزودن/حذف شرکت‌کننده فقط پیش از ثبت اولین نتیجه ممکن است.
