package ir.schoolleague

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import ir.schoolleague.data.*
import kotlinx.coroutines.runBlocking
import org.junit.*
import org.junit.runner.RunWith

/** Run on a device/emulator: ./gradlew connectedDebugAndroidTest */
@RunWith(AndroidJUnit4::class)
class RepositoryInstrumentedTest {
    private lateinit var db: AppDatabase
    private lateinit var repo: LeagueRepository

    @Before fun setUp() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(ctx, AppDatabase::class.java).allowMainThreadQueries().build()
        repo = LeagueRepository(db)
    }
    @After fun tearDown() { db.close() }

    @Test fun knockoutAdvanceEditAndDelete() = runBlocking {
        val id = repo.createLeague("تست", Sport.PINGPONG, Format.KNOCKOUT, listOf("الف", "ب", "ج", "د"),
            LeagueRepository.defaultSettings(0, Sport.PINGPONG), false)
        val m = repo.dao.getMatches(id)
        val r0 = m.filter { it.round == 0 }
        assertNull(repo.saveSetResult(r0[0].id, listOf(intArrayOf(11, 7), intArrayOf(11, 9))))
        assertNull(repo.saveSetResult(r0[1].id, listOf(intArrayOf(11, 7), intArrayOf(11, 9))))
        val final1 = repo.dao.getMatches(id).first { it.round == 1 }
        Assert.assertNotNull(final1.aId); Assert.assertNotNull(final1.bId)
        assertNotNull(repo.saveSetResult(r0[0].id, listOf(intArrayOf(11, 7), intArrayOf(11, 9), intArrayOf(11, 1))))
        repo.deleteResult(r0[0].id)
        Assert.assertNull(repo.dao.getMatches(id).first { it.round == 1 }.aId)
    }

    @Test fun backupRestoreKeepsData() = runBlocking {
        val id = repo.createLeague("لیگ", Sport.FOOTBALL, Format.ROUND_ROBIN, listOf("الف", "ب", "ج"),
            LeagueRepository.defaultSettings(0, Sport.FOOTBALL), false)
        val first = repo.dao.getMatches(id).first()
        repo.saveFootballResult(first.id, 2, 1, null, null, false)
        val json = repo.exportJson()
        repo.deleteLeague(id)
        Assert.assertEquals(0, repo.dao.allLeagues().size)
        repo.importJson(json)
        Assert.assertEquals(1, repo.dao.allLeagues().size)
        Assert.assertTrue(repo.dao.getMatches(id).first { it.id == first.id }.played)
    }
    private fun assertNull(x: Any?) = Assert.assertNull(x)
    private fun assertNotNull(x: Any?) = Assert.assertNotNull(x)
}
