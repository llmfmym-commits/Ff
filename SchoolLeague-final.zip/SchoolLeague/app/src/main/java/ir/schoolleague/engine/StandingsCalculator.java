package ir.schoolleague.engine;

import java.util.*;

/** Computes the table from recorded results only (nothing is invented). */
public final class StandingsCalculator {
    public static final class Result {
        public final int a, b;        // participant ids
        public final int forA, forB;  // goals (football) or sets/games won
        public final int ptsA, ptsB;  // rally points inside sets (0 for football)
        public Result(int a, int b, int forA, int forB, int ptsA, int ptsB) {
            this.a = a; this.b = b; this.forA = forA; this.forB = forB; this.ptsA = ptsA; this.ptsB = ptsB;
        }
    }
    public static final class Row {
        public final int id;
        public int played, wins, draws, losses, scored, conceded, ptsFor, ptsAgainst, points;
        Row(int id) { this.id = id; }
        public int diff() { return scored - conceded; }
        public int ptsDiff() { return ptsFor - ptsAgainst; }
        public double winRate() { return played == 0 ? 0 : 100.0 * wins / played; }
    }

    private StandingsCalculator() {}

    public static List<Row> compute(List<Integer> ids, List<Result> results,
                                    int winPts, int drawPts, int losePts) {
        Map<Integer, Row> map = new LinkedHashMap<>();
        for (int id : ids) map.put(id, new Row(id));
        for (Result r : results) {
            Row x = map.get(r.a), y = map.get(r.b);
            if (x == null || y == null) continue;
            x.played++; y.played++;
            x.scored += r.forA; x.conceded += r.forB; y.scored += r.forB; y.conceded += r.forA;
            x.ptsFor += r.ptsA; x.ptsAgainst += r.ptsB; y.ptsFor += r.ptsB; y.ptsAgainst += r.ptsA;
            if (r.forA > r.forB) { x.wins++; y.losses++; x.points += winPts; y.points += losePts; }
            else if (r.forB > r.forA) { y.wins++; x.losses++; y.points += winPts; x.points += losePts; }
            else { x.draws++; y.draws++; x.points += drawPts; y.points += drawPts; }
        }
        List<Row> rows = new ArrayList<>(map.values());
        rows.sort((p, q) -> {
            if (p.points != q.points) return q.points - p.points;
            if (p.diff() != q.diff()) return q.diff() - p.diff();
            if (p.scored != q.scored) return q.scored - p.scored;
            if (p.ptsDiff() != q.ptsDiff()) return q.ptsDiff() - p.ptsDiff();
            return Integer.compare(p.id, q.id);
        });
        return rows;
    }
}
