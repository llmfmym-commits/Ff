package ir.schoolleague.data

object Sport { const val PINGPONG = "PINGPONG"; const val FOOTBALL = "FOOTBALL"; const val VOLLEYBALL = "VOLLEYBALL" }
object Format { const val KNOCKOUT = "KNOCKOUT"; const val ROUND_ROBIN = "ROUND_ROBIN" }
object Status { const val ACTIVE = "ACTIVE"; const val FINISHED = "FINISHED" }
