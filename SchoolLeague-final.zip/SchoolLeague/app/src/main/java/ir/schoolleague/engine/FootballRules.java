package ir.schoolleague.engine;

/** Football scoring rules and knockout tie resolution. */
public final class FootballRules {
    private FootballRules() {}

    public static String validateScore(int a, int b) {
        if (a < 0 || b < 0) return "تعداد گل نمی‌تواند منفی باشد.";
        return null;
    }

    /** League: 1/2 winner, 0 draw. */
    public static int leagueWinner(int a, int b) { return a > b ? 1 : (b > a ? 2 : 0); }

    /**
     * Knockout: regular score, optional penalties (null = none). A draw without a
     * penalty decision is invalid. Returns winner 1/2 or 0 if invalid.
     */
    public static int knockoutWinner(int a, int b, Integer penA, Integer penB) {
        if (a != b) return a > b ? 1 : 2;
        if (penA == null || penB == null || penA < 0 || penB < 0 || penA.equals(penB)) return 0;
        return penA > penB ? 1 : 2;
    }
}
