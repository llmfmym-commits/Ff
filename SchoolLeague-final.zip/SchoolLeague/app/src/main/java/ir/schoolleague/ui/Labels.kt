package ir.schoolleague.ui

import ir.schoolleague.data.Format
import ir.schoolleague.data.Sport

object Labels {
    fun sport(s: String) = when (s) { Sport.FOOTBALL -> "فوتبال"; Sport.VOLLEYBALL -> "والیبال"; else -> "پینگ‌پنگ" }
    fun emoji(s: String) = when (s) { Sport.FOOTBALL -> "⚽"; Sport.VOLLEYBALL -> "🏐"; else -> "🏓" }
    fun format(f: String) = if (f == Format.KNOCKOUT) "حذفی" else "لیگ جدولی"
    fun noun(s: String) = if (s == Sport.PINGPONG) "بازیکن" else "تیم"
    fun unit(s: String) = if (s == Sport.PINGPONG) "گیم" else "ست"
    fun roundTitle(format: String, round: Int, rounds: Int): String {
        if (format != Format.KNOCKOUT) return "دور ${Ui.fa(round + 1)}"
        return when (rounds - round) { 1 -> "فینال"; 2 -> "نیمه‌نهایی"; 3 -> "یک‌چهارم نهایی"; 4 -> "یک‌هشتم نهایی"; else -> "دور ${Ui.fa(round + 1)}" }
    }
}
