package ir.schoolleague.engine;

import java.util.ArrayList;
import java.util.List;

/** Round-robin (circle method). Odd counts give one bye per round (skipped). */
public final class ScheduleGenerator {
    public static final class Pairing {
        public final int round, a, b;
        Pairing(int round, int a, int b) { this.round = round; this.a = a; this.b = b; }
    }

    private ScheduleGenerator() {}

    public static int roundsFor(int n, boolean doubleRound) {
        int single = (n % 2 == 0) ? n - 1 : n;
        return doubleRound ? single * 2 : single;
    }

    public static int matchesFor(int n, boolean doubleRound) {
        int m = n * (n - 1) / 2;
        return doubleRound ? m * 2 : m;
    }

    public static List<Pairing> roundRobin(int n, boolean doubleRound) {
        if (n < 2) throw new IllegalArgumentException("حداقل دو شرکت‌کننده لازم است.");
        int size = (n % 2 == 0) ? n : n + 1; // dummy index n = bye
        int[] arr = new int[size];
        for (int i = 0; i < size; i++) arr[i] = i;
        List<Pairing> out = new ArrayList<>();
        int rounds = size - 1;
        for (int r = 0; r < rounds; r++) {
            for (int i = 0; i < size / 2; i++) {
                int x = arr[i], y = arr[size - 1 - i];
                if (x >= n || y >= n) continue; // bye
                // alternate home/away for the fixed first slot
                if (i == 0 && r % 2 == 1) { int t = x; x = y; y = t; }
                out.add(new Pairing(r + 1, x, y));
            }
            int last = arr[size - 1];
            System.arraycopy(arr, 1, arr, 2, size - 2);
            arr[1] = last;
        }
        if (doubleRound) {
            int base = out.size();
            for (int i = 0; i < base; i++) {
                Pairing p = out.get(i);
                out.add(new Pairing(p.round + rounds, p.b, p.a));
            }
        }
        return out;
    }
}
