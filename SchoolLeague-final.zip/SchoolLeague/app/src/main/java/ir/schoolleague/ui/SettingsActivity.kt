package ir.schoolleague.ui

import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.SeekBar
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SettingsActivity : BaseActivity() {
    private val exportLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) doExport(uri)
    }
    private val importLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) readThenConfirm(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val r = buildScreen("تنظیمات")
        section(r, "تم برنامه") { c ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            listOf("LIGHT" to "روشن", "DARK" to "تاریک", "SYSTEM" to "سیستم").forEach { (k, t) ->
                val sel = Prefs.theme(this) == k
                row.addView(Ui.button(this, t, sel) { Prefs.setTheme(this, k); recreate() }, Ui.lp(0, Ui.WRAP, 1f, this, 2, 0, 2, 0))
            }
            c.addView(row)
        }
        section(r, "فونت") { c ->
            Prefs.fonts(this).forEach { (k, t) ->
                c.addView(Ui.button(this, t, Prefs.fontKey(this) == k) { Prefs.setFontKey(this, k); recreate() }, Ui.lp(c = this, b = 6))
            }
            c.addView(Ui.tv(this, "برای افزودن فونت فارسی، فایل vazirmatn.ttf را در app/src/main/res/font قرار دهید تا خودکار در این فهرست بیاید.", 12f, false, Ui.sub(this)))
        }
        section(r, "اندازه‌ی متن") { c ->
            val label = Ui.tv(this, "${Ui.fa((Prefs.textScale(this) * 100).toInt())}٪", 14f, true)
            val sb = SeekBar(this).apply { max = 50; progress = ((Prefs.textScale(this@SettingsActivity) - 0.8f) * 100).toInt().coerceIn(0, 50) }
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { label.text = "${Ui.fa(80 + p)}٪" }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { Prefs.setTextScale(this@SettingsActivity, 0.8f + (s?.progress ?: 20) / 100f); recreate() }
            })
            sb.contentDescription = "اندازه‌ی متن"
            c.addView(label); c.addView(sb)
        }
        section(r, "رنگ اصلی") { c ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            listOf(0xFF10B981, 0xFF1D4ED8, 0xFF7C3AED, 0xFFEA580C, 0xFFE11D48, 0xFF0D9488).forEach { cl ->
                val col = cl.toInt()
                val sel = Prefs.primary(this) == col
                row.addView(View(this).apply {
                    background = Ui.rounded(col, dp(24), if (sel) Ui.ink(this@SettingsActivity) else Color.TRANSPARENT, dp(3))
                    contentDescription = "رنگ"; isClickable = true
                    setOnClickListener { Prefs.setPrimary(this@SettingsActivity, col); recreate() }
                }, Ui.lp(dp(44), dp(44), 0f, this, 6, 0, 6, 0))
            }
            c.addView(row)
        }
        section(r, "پشتیبان‌گیری") { c ->
            c.addView(Ui.button(this, "ساخت نسخه‌ی پشتیبان (JSON)") { exportLauncher.launch("school-league-backup.json") }, Ui.lp(c = this, b = 8))
            c.addView(Ui.button(this, "بازیابی از نسخه‌ی پشتیبان", false) { importLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) })
        }
        section(r, "تنظیمات عمومی") { c ->
            c.addView(Ui.button(this, "بازنشانی ظاهر به حالت پیش‌فرض", false) {
                Ui.confirm(this, "بازنشانی", "تم، فونت، اندازه‌ی متن و رنگ به حالت پیش‌فرض برمی‌گردند. داده‌های لیگ‌ها حفظ می‌شوند.") { Prefs.resetAll(this); recreate() }
            })
        }
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "?" }
        r.addView(Ui.tv(this, "نسخه‌ی برنامه: ${Ui.fa(ver ?: "")}", 13f, false, Ui.sub(this)).apply { gravity = Gravity.CENTER; setPadding(0, dp(12), 0, 0) })
    }

    private fun section(r: LinearLayout, title: String, build: (LinearLayout) -> Unit) {
        val c = Ui.card(this)
        c.addView(Ui.tv(this, title, 16f, true).apply { setPadding(0, 0, 0, dp(8)) })
        build(c); r.addView(c)
    }

    private fun doExport(uri: Uri) {
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val text = repo.exportJson()
                    contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) } ?: throw IllegalStateException()
                }
                Ui.toast(this@SettingsActivity, "نسخه‌ی پشتیبان با موفقیت ذخیره شد.")
            } catch (e: Exception) { Ui.toast(this@SettingsActivity, "ذخیره‌ی پشتیبان ناموفق بود.") }
        }
    }

    private fun readThenConfirm(uri: Uri) {
        lifecycleScope.launch {
            val text = try {
                withContext(Dispatchers.IO) { contentResolver.openInputStream(uri)?.use { String(it.readBytes(), Charsets.UTF_8) } }
            } catch (e: Exception) { null }
            if (text == null) { Ui.toast(this@SettingsActivity, "خواندن فایل ناموفق بود."); return@launch }
            Ui.confirm(this@SettingsActivity, "بازیابی اطلاعات", "همه‌ی لیگ‌های فعلی با اطلاعات فایل پشتیبان جایگزین می‌شوند. ادامه می‌دهید؟", "بازیابی") {
                lifecycleScope.launch {
                    try { repo.importJson(text); Ui.toast(this@SettingsActivity, "اطلاعات با موفقیت بازیابی شد.") }
                    catch (e: IllegalArgumentException) { Ui.toast(this@SettingsActivity, e.message ?: "فایل نامعتبر است.") }
                    catch (e: Exception) { Ui.toast(this@SettingsActivity, "بازیابی ناموفق بود؛ اطلاعات قبلی تغییر نکرد.") }
                }
            }
        }
    }
}
