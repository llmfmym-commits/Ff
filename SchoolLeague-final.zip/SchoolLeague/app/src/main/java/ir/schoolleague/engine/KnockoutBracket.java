package ir.schoolleague.engine;

import java.util.ArrayList;
import java.util.List;

/**
 * Single-elimination bracket. Participants are seeds 0..n-1.
 * Slot values: >=0 participant seed, BYE = no opponent, TBD = decided by earlier match.
 * Match (round r, index i) feeds (r+1, i/2), slot i%2 (0 = A, 1 = B).
 */
public final class KnockoutBracket {
    public static final int BYE = -1;
    public static final int TBD = -2;

    public static final class Node {
        public final int round, index;
        public int a, b;
        Node(int round, int index, int a, int b) { this.round = round; this.index = index; this.a = a; this.b = b; }
        public boolean isBye() { return round == 0 && (a == BYE || b == BYE); }
    }

    public final int participants, size, rounds;
    private final List<List<Node>> grid = new ArrayList<>();

    public KnockoutBracket(int n) {
        if (n < 2) throw new IllegalArgumentException("حداقل دو شرکت‌کننده لازم است.");
        participants = n;
        int s = 1, r = 0;
        while (s < n) { s <<= 1; r++; }
        size = s; rounds = r;
        List<Integer> order = seedOrder(size);
        List<Node> first = new ArrayList<>();
        for (int i = 0; i < size / 2; i++) {
            int sa = order.get(2 * i), sb = order.get(2 * i + 1);
            first.add(new Node(0, i, sa < n ? sa : BYE, sb < n ? sb : BYE));
        }
        grid.add(first);
        for (int rr = 1; rr < rounds; rr++) {
            List<Node> list = new ArrayList<>();
            for (int i = 0; i < size / (1 << (rr + 1)); i++) list.add(new Node(rr, i, TBD, TBD));
            grid.add(list);
        }
        // byes advance automatically
        for (Node nd : first) {
            if (nd.isBye()) advance(nd, nd.a == BYE ? nd.b : nd.a);
        }
    }

    /** Standard seeding so seed 1 and 2 meet only in the final; top seeds get byes. */
    static List<Integer> seedOrder(int size) {
        List<Integer> cur = new ArrayList<>();
        cur.add(0);
        while (cur.size() < size) {
            List<Integer> next = new ArrayList<>();
            int m = cur.size() * 2;
            for (int s : cur) { next.add(s); next.add(m - 1 - s); }
            cur = next;
        }
        return cur;
    }

    public List<Node> round(int r) { return grid.get(r); }
    public Node node(int r, int i) { return grid.get(r).get(i); }

    /** Next match fed by this one, or null for the final. */
    public Node next(Node nd) { return nd.round + 1 >= rounds ? null : node(nd.round + 1, nd.index / 2); }

    /** Place the winner of nd into the next match. */
    public void advance(Node nd, int winner) {
        Node nx = next(nd);
        if (nx == null) return;
        if (nd.index % 2 == 0) nx.a = winner; else nx.b = winner;
    }

    /** Clear a slot downstream (used when a result is edited/deleted). */
    public void clearFrom(Node nd) {
        Node nx = next(nd);
        if (nx == null) return;
        if (nd.index % 2 == 0) nx.a = TBD; else nx.b = TBD;
    }

    public boolean isPlayable(Node nd) { return nd.a >= 0 && nd.b >= 0; }

    public int totalRealMatches() { return participants - 1; }
}
