package ir.schoolleague.engine;

import java.util.List;

/** Generic best-of-N rules: each set to N points, win by margin; configurable. */
public class SetMatchRules {
    protected final int setsToWin;
    protected final int pointsPerSet;
    protected final int deciderPoints;
    protected final int winBy;

    public SetMatchRules(int setsToWin, int pointsPerSet, int deciderPoints, int winBy) {
        if (setsToWin < 1 || pointsPerSet < 1 || deciderPoints < 1 || winBy < 1)
            throw new IllegalArgumentException("invalid rule config");
        this.setsToWin = setsToWin; this.pointsPerSet = pointsPerSet;
        this.deciderPoints = deciderPoints; this.winBy = winBy;
    }

    public int maxSets() { return 2 * setsToWin - 1; }

    /** Target for set index (0-based): the last possible set uses deciderPoints. */
    public int targetFor(int setIndex) {
        return setIndex == maxSets() - 1 ? deciderPoints : pointsPerSet;
    }

    /** Returns null if the single set score is valid, otherwise a Persian error. */
    public String validateSet(int a, int b, int target) {
        if (a < 0 || b < 0) return "امتیاز نمی‌تواند منفی باشد.";
        if (a == b) return "نتیجه مساوی در یک گیم/ست مجاز نیست.";
        int hi = Math.max(a, b), lo = Math.min(a, b);
        if (hi < target) return "برنده باید حداقل " + target + " امتیاز داشته باشد.";
        if (hi - lo < winBy) return "اختلاف امتیاز باید حداقل " + winBy + " باشد.";
        if (hi > target && hi - lo != winBy)
            return "پس از رسیدن به " + target + "، بازی باید دقیقاً با اختلاف " + winBy + " تمام شود.";
        return null;
    }

    /** Evaluate a finished match. Each element is {pointsA, pointsB}. */
    public MatchOutcome evaluate(List<int[]> sets) {
        int sa = 0, sb = 0, pa = 0, pb = 0;
        for (int i = 0; i < sets.size(); i++) {
            if (sa == setsToWin || sb == setsToWin)
                return MatchOutcome.invalid("مسابقه پایان یافته و ثبت گیم/ست بیشتر مجاز نیست.");
            int[] s = sets.get(i);
            if (s == null || s.length != 2) return MatchOutcome.invalid("ساختار نتیجه نامعتبر است.");
            String err = validateSet(s[0], s[1], targetFor(i));
            if (err != null) return MatchOutcome.invalid(err);
            pa += s[0]; pb += s[1];
            if (s[0] > s[1]) sa++; else sb++;
        }
        if (sa < setsToWin && sb < setsToWin)
            return MatchOutcome.invalid("هنوز برنده‌ای مشخص نشده؛ نتیجه ناقص است.");
        return MatchOutcome.ok(sa > sb ? 1 : 2, sa, sb, pa, pb);
    }

    /** Whether the next set can be entered given sets so far (assumed valid). */
    public boolean isNextSetEnabled(List<int[]> sets) {
        int sa = 0, sb = 0;
        for (int[] s : sets) { if (s[0] > s[1]) sa++; else sb++; }
        return sa < setsToWin && sb < setsToWin && sets.size() < maxSets();
    }
}
