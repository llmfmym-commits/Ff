package ir.schoolleague.ui

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import ir.schoolleague.data.Sport
import ir.schoolleague.data.Status
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

class MainActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val r = buildScreen("لیگ‌های ورزشی مدرسه", back = false)
        addHeaderAction("⚙", "تنظیمات") { startActivity(Intent(this, SettingsActivity::class.java)) }

        val counts = Ui.tv(this, "", 14f, false, Ui.sub(this)).apply { setPadding(dp(4), 0, dp(4), dp(12)) }
        r.addView(counts)
        val items = listOf(
            Triple("➕", "ساخت لیگ ورزشی", "پینگ‌پنگ، فوتبال یا والیبال؛ حذفی یا جدولی") to Prefs.primary(this),
            Triple("🏐", "لیگ‌های والیبال", "مسابقات سه‌ست") to 0xFF2563EB.toInt(),
            Triple("⚽", "لیگ‌های فوتبال", "نتیجه بر اساس گل") to 0xFFEA580C.toInt(),
            Triple("🏓", "لیگ‌های پینگ‌پنگ", "بهترین از ۳ گیم تا ۱۱") to 0xFF7C3AED.toInt()
        )
        items.forEachIndexed { i, (t, color) ->
            val card = Ui.card(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; minimumHeight = dp(92) }
            val icon = Ui.tv(this, t.first, 28f, false, Color.WHITE).apply {
                gravity = Gravity.CENTER; background = Ui.rounded(color, dp(18))
            }
            card.addView(icon, Ui.lp(dp(60), dp(60), 0f, this, 0, 0, 0, 0))
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, dp(14), 0) }
            col.addView(Ui.tv(this, t.second, 17f, true))
            col.addView(Ui.tv(this, t.third, 13f, false, Ui.sub(this)))
            card.addView(col, Ui.lp(0, Ui.WRAP, 1f))
            card.addView(Ui.tv(this, "‹", 24f, true, color))
            card.contentDescription = t.second
            card.isClickable = true; card.isFocusable = true
            card.setOnClickListener {
                when (i) {
                    0 -> startActivity(Intent(this, CreateLeagueActivity::class.java))
                    else -> startActivity(Intent(this, LeagueListActivity::class.java)
                        .putExtra(LeagueListActivity.EXTRA_SPORT, when (i) { 1 -> Sport.VOLLEYBALL; 2 -> Sport.FOOTBALL; else -> Sport.PINGPONG }))
                }
            }
            r.addView(card)
            Ui.fadeIn(card, i)
        }
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                combine(repo.dao.countByStatus(Status.ACTIVE), repo.dao.countByStatus(Status.FINISHED)) { a, f -> a to f }
                    .collect { counts.text = "لیگ در حال برگزاری: ${Ui.fa(it.first)}   •   لیگ پایان‌یافته: ${Ui.fa(it.second)}" }
            }
        }
    }
}
