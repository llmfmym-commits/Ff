package ir.schoolleague.engine;

/** Result of evaluating a set/game based match. */
public final class MatchOutcome {
    public final boolean valid;
    public final String error;
    /** 1 = first side won, 2 = second side won, 0 = none. */
    public final int winner;
    public final int setsA, setsB, pointsA, pointsB;

    private MatchOutcome(boolean valid, String error, int winner,
                         int setsA, int setsB, int pointsA, int pointsB) {
        this.valid = valid; this.error = error; this.winner = winner;
        this.setsA = setsA; this.setsB = setsB;
        this.pointsA = pointsA; this.pointsB = pointsB;
    }
    public static MatchOutcome invalid(String error) {
        return new MatchOutcome(false, error, 0, 0, 0, 0, 0);
    }
    public static MatchOutcome ok(int winner, int sa, int sb, int pa, int pb) {
        return new MatchOutcome(true, null, winner, sa, sb, pa, pb);
    }
}
