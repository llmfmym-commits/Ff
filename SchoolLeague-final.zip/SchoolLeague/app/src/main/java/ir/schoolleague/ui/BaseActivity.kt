package ir.schoolleague.ui

import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import ir.schoolleague.data.AppDatabase
import ir.schoolleague.data.LeagueRepository

abstract class BaseActivity : AppCompatActivity() {
    val repo by lazy { LeagueRepository(AppDatabase.get(applicationContext)) }
    protected lateinit var body: LinearLayout
    protected lateinit var titleView: TextView
    private lateinit var headerRow: LinearLayout

    protected fun dp(v: Int) = Ui.dp(this, v)

    protected fun buildScreen(title: String, back: Boolean = true, extraTop: View? = null): LinearLayout {
        val frame = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.bg(this@BaseActivity))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Prefs.primary(this@BaseActivity))
            setPadding(dp(8), dp(10), dp(8), dp(10))
        }
        if (back) headerRow.addView(Ui.tv(this, "→", 24f, true, Color.WHITE).apply {
            contentDescription = "بازگشت"; gravity = Gravity.CENTER
            minWidth = dp(48); minHeight = dp(48)
            setOnClickListener { onBackPressedDispatcher.onBackPressed() }
        })
        titleView = Ui.tv(this, title, 19f, true, Color.WHITE).apply { setPadding(dp(8), 0, dp(8), 0); maxLines = 1 }
        headerRow.addView(titleView, Ui.lp(0, Ui.WRAP, 1f))
        frame.addView(headerRow, Ui.lp())
        if (extraTop != null) frame.addView(extraTop, Ui.lp())
        val sv = ScrollView(this).apply { isFillViewport = true }
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(24)) }
        sv.addView(body, Ui.lp())
        frame.addView(sv, Ui.lp(Ui.MATCH, 0, 1f))
        setContentView(frame)
        window.statusBarColor = Prefs.primary(this)
        return body
    }

    protected fun addHeaderAction(label: String, desc: String, onClick: (View) -> Unit) {
        headerRow.addView(Ui.tv(this, label, 22f, true, Color.WHITE).apply {
            contentDescription = desc; gravity = Gravity.CENTER
            minWidth = dp(48); minHeight = dp(48)
            setOnClickListener { onClick(it) }
        })
    }
}
