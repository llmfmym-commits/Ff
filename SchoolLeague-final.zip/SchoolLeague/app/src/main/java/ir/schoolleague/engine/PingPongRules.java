package ir.schoolleague.engine;

/** Table tennis: best of 3 games to 11, win by 2. Never a single 21-point game. */
public final class PingPongRules extends SetMatchRules {
    public static final int DEFAULT_GAME_POINTS = 11;
    public PingPongRules() { this(DEFAULT_GAME_POINTS); }
    public PingPongRules(int gamePoints) { super(2, gamePoints, gamePoints, 2); }
}
