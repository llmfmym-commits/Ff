package ir.schoolleague.ui

import android.content.Context
import android.graphics.Typeface
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.res.ResourcesCompat

/** Synchronous appearance settings (read before the first view is created). */
object Prefs {
    val DEFAULT_PRIMARY = 0xFF10B981.toInt()
    private fun sp(c: Context) = c.getSharedPreferences("ui", Context.MODE_PRIVATE)

    fun theme(c: Context): String = sp(c).getString("theme", "SYSTEM") ?: "SYSTEM"
    fun setTheme(c: Context, v: String) { sp(c).edit().putString("theme", v).apply(); applyNightMode(c) }
    fun applyNightMode(c: Context) = AppCompatDelegate.setDefaultNightMode(when (theme(c)) {
        "LIGHT" -> AppCompatDelegate.MODE_NIGHT_NO
        "DARK" -> AppCompatDelegate.MODE_NIGHT_YES
        else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
    })

    fun textScale(c: Context): Float = sp(c).getFloat("scale", 1.0f)
    fun setTextScale(c: Context, v: Float) = sp(c).edit().putFloat("scale", v).apply()

    fun primary(c: Context): Int = sp(c).getInt("primary", DEFAULT_PRIMARY)
    fun setPrimary(c: Context, v: Int) = sp(c).edit().putInt("primary", v).apply()

    fun fontKey(c: Context): String = sp(c).getString("font", "DEFAULT") ?: "DEFAULT"
    fun setFontKey(c: Context, v: String) = sp(c).edit().putString("font", v).apply()

    /** Font files placed in res/font (e.g. vazirmatn.ttf) are offered automatically. */
    fun bundledFontId(c: Context): Int = c.resources.getIdentifier("vazirmatn", "font", c.packageName)

    fun fonts(c: Context): List<Pair<String, String>> {
        val l = mutableListOf("DEFAULT" to "پیش‌فرض سیستم", "SERIF" to "سریف", "CONDENSED" to "فشرده", "LIGHT" to "نازک")
        if (bundledFontId(c) != 0) l.add(0, "VAZIR" to "وزیرمتن")
        return l
    }

    fun typeface(c: Context): Typeface = when (fontKey(c)) {
        "SERIF" -> Typeface.SERIF
        "CONDENSED" -> Typeface.create("sans-serif-condensed", Typeface.NORMAL)
        "LIGHT" -> Typeface.create("sans-serif-light", Typeface.NORMAL)
        "VAZIR" -> bundledFontId(c).let { if (it != 0) ResourcesCompat.getFont(c, it) ?: Typeface.DEFAULT else Typeface.DEFAULT }
        else -> Typeface.DEFAULT
    }

    fun resetAll(c: Context) { sp(c).edit().clear().apply(); applyNightMode(c) }
}
