package ir.schoolleague.data

import android.content.Context
import androidx.room.*

@Database(
    entities = [League::class, Participant::class, MatchEntity::class, GameScore::class,
        LeagueSettings::class],
    version = 1, exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): LeagueDao

    companion object {
        @Volatile private var inst: AppDatabase? = null
        fun get(ctx: Context): AppDatabase = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDatabase::class.java, "league.db")
                .build().also { inst = it }
        }
    }
}
