package ir.schoolleague.ui

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.widget.SwitchCompat
import androidx.lifecycle.lifecycleScope
import ir.schoolleague.data.Format
import ir.schoolleague.data.LeagueRepository
import ir.schoolleague.data.LeagueSettings
import ir.schoolleague.data.Sport
import kotlinx.coroutines.launch

class CreateLeagueActivity : BaseActivity() {
    companion object { const val EXTRA_SPORT = "sport" }

    private var step = 1
    private var sport: String? = null
    private var format: String? = null
    private var count = 4
    private val names = mutableListOf<String>()
    private var leagueName = ""
    private var st: LeagueSettings = LeagueRepository.defaultSettings(0, Sport.PINGPONG)
    private var shuffle = false
    private var showAdvanced = false
    private val fields = mutableListOf<EditText>()
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = buildScreen("ساخت لیگ ورزشی")
        intent.getStringExtra(EXTRA_SPORT)?.let { chooseSport(it); step = 2 }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (step > 1) { syncNames(); step--; render() } else finish()
            }
        })
        render()
    }

    private fun chooseSport(s: String) {
        sport = s; st = LeagueRepository.defaultSettings(0, s)
    }

    private fun syncNames() {
        if (fields.isNotEmpty()) {
            names.clear(); names.addAll(fields.map { it.text.toString() })
        }
        fields.clear()
    }

    private fun render() {
        root.removeAllViews()
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 5; progress = step }
        root.addView(Ui.tv(this, "مرحله ${Ui.fa(step)} از ${Ui.fa(5)}", 13f, false, Ui.sub(this)))
        root.addView(bar, Ui.lp(c = this, t = 6, b = 14))
        when (step) {
            1 -> stepSport()
            2 -> stepFormat()
            3 -> stepParticipants()
            4 -> stepSettings()
            else -> stepConfirm()
        }
    }

    private fun title(t: String) = root.addView(Ui.tv(this, t, 19f, true).apply { setPadding(0, 0, 0, dp(10)) })

    private fun choice(emoji: String, t: String, sub: String, selected: Boolean, onClick: () -> Unit): View {
        val card = Ui.card(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = Ui.rounded(Ui.surface(this@CreateLeagueActivity), dp(16),
                if (selected) Prefs.primary(this@CreateLeagueActivity) else Color.TRANSPARENT, dp(2))
            isClickable = true; isFocusable = true; minimumHeight = dp(72)
            setOnClickListener { onClick() }
        }
        card.addView(Ui.tv(this, emoji, 26f))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        col.addView(Ui.tv(this, t, 16f, true)); col.addView(Ui.tv(this, sub, 12f, false, Ui.sub(this)))
        card.addView(col, Ui.lp(0, Ui.WRAP, 1f))
        return card
    }

    private fun stepSport() {
        title("ورزش را انتخاب کنید")
        listOf(Sport.PINGPONG to "بهترین از ۳ گیم", Sport.FOOTBALL to "بر اساس تعداد گل", Sport.VOLLEYBALL to "بهترین از ۳ ست").forEach { (s, d) ->
            root.addView(choice(Labels.emoji(s), Labels.sport(s), d, sport == s) { chooseSport(s); step = 2; render() })
        }
    }

    private fun stepFormat() {
        title("قالب مسابقات")
        root.addView(choice("🏆", "حذفی", "برنده صعود می‌کند و بازنده حذف می‌شود؛ در تعداد فرد، استراحت (Bye)", format == Format.KNOCKOUT) { format = Format.KNOCKOUT; step = 3; render() })
        root.addView(choice("📊", "لیگ جدولی", "هر شرکت‌کننده با همه بازی می‌کند و جدول رده‌بندی ساخته می‌شود", format == Format.ROUND_ROBIN) { format = Format.ROUND_ROBIN; step = 3; render() })
    }

    private fun stepParticipants() {
        val noun = Labels.noun(sport!!)
        title("تعداد و نام ${noun}ها")
        val countRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val countTv = Ui.tv(this, "${Ui.fa(count)} $noun", 17f, true).apply { gravity = Gravity.CENTER }
        fun change(d: Int) {
            val n = count + d
            if (n < 2 || n > 32) { Ui.toast(this, "تعداد باید بین ۲ تا ۳۲ باشد."); return }
            syncNames(); count = n; render()
        }
        countRow.addView(Ui.button(this, "−", false) { change(-1) }, Ui.lp(dp(64), Ui.WRAP))
        countRow.addView(countTv, Ui.lp(0, Ui.WRAP, 1f))
        countRow.addView(Ui.button(this, "+", false) { change(1) }, Ui.lp(dp(64), Ui.WRAP))
        root.addView(countRow, Ui.lp(c = this, b = 12))
        while (names.size < count) names.add("")
        while (names.size > count) names.removeAt(names.size - 1)
        fields.clear()
        for (i in 0 until count) {
            val e = Ui.edit(this, "نام $noun ${Ui.fa(i + 1)}", false, names[i])
            e.contentDescription = "نام $noun ${Ui.fa(i + 1)}"
            fields.add(e); root.addView(e, Ui.lp(c = this, b = 8))
        }
        root.addView(Ui.button(this, "ادامه") {
            syncNames()
            val err = validateNames()
            if (err != null) { Ui.toast(this, err); fieldsRebind() } else { step = 4; render() }
        }, Ui.lp(c = this, t = 8))
    }

    private fun fieldsRebind() { render() }

    private fun validateNames(): String? {
        val t = names.map { it.trim() }
        if (t.size < 2) return "حداقل دو شرکت‌کننده لازم است."
        if (t.any { it.isEmpty() }) return "نام هیچ شرکت‌کننده‌ای نباید خالی باشد."
        if (t.map { it.lowercase() }.toSet().size != t.size) return "نام شرکت‌کنندگان تکراری است."
        return null
    }

    private fun stepSettings() {
        title("تنظیمات لیگ")
        val nameEt = Ui.edit(this, "مثلاً مسابقات ${Labels.sport(sport!!)} پایه دهم", false, leagueName)
        root.addView(Ui.tv(this, "نام لیگ", 13f, false, Ui.sub(this)))
        root.addView(nameEt, Ui.lp(c = this, b = 12))
        val adv = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = if (showAdvanced) View.VISIBLE else View.GONE }
        val winEt = Ui.edit(this, "", true, st.winPoints.toString())
        val drawEt = Ui.edit(this, "", true, st.drawPoints.toString())
        val loseEt = Ui.edit(this, "", true, st.losePoints.toString())
        val gameEt = Ui.edit(this, "", true, st.gamePoints.toString())
        val decEt = Ui.edit(this, "", true, st.deciderPoints.toString())
        fun addField(parent: LinearLayout, label: String, e: EditText) {
            parent.addView(Ui.tv(this, label, 13f, false, Ui.sub(this)))
            parent.addView(e, Ui.lp(c = this, b = 8))
        }
        addField(adv, "امتیاز برد در جدول", winEt)
        if (sport == Sport.FOOTBALL) addField(adv, "امتیاز مساوی", drawEt)
        addField(adv, "امتیاز باخت", loseEt)
        if (sport != Sport.FOOTBALL) addField(adv, if (sport == Sport.PINGPONG) "امتیاز هر گیم" else "امتیاز هر ست", gameEt)
        if (sport == Sport.VOLLEYBALL) addField(adv, "امتیاز ست تعیین‌کننده (سوم)", decEt)
        val dbl = SwitchCompat(this).apply { text = "رفت و برگشت"; isChecked = st.doubleRound; setTextColor(Ui.ink(this@CreateLeagueActivity)) }
        if (format == Format.ROUND_ROBIN) adv.addView(dbl, Ui.lp(c = this, b = 8))
        val shuf = SwitchCompat(this).apply { text = "قرعه‌کشی تصادفی ترتیب"; isChecked = shuffle; setTextColor(Ui.ink(this@CreateLeagueActivity)) }
        adv.addView(shuf, Ui.lp(c = this, b = 8))
        root.addView(Ui.button(this, if (showAdvanced) "پنهان‌کردن تنظیمات پیشرفته" else "تنظیمات پیشرفته", false) {
            showAdvanced = !showAdvanced; collect(nameEt, winEt, drawEt, loseEt, gameEt, decEt, dbl, shuf); render()
        }, Ui.lp(c = this, b = 8))
        root.addView(adv)
        root.addView(Ui.button(this, "ادامه") {
            collect(nameEt, winEt, drawEt, loseEt, gameEt, decEt, dbl, shuf)
            val err = validateSettings()
            if (err != null) Ui.toast(this, err) else { step = 5; render() }
        }, Ui.lp(c = this, t = 8))
    }

    private fun collect(nameEt: EditText, w: EditText, d: EditText, l: EditText, g: EditText, dec: EditText, dbl: SwitchCompat, shuf: SwitchCompat) {
        leagueName = nameEt.text.toString()
        st = st.copy(
            winPoints = Ui.parseInt(w.text.toString()) ?: -1, drawPoints = Ui.parseInt(d.text.toString()) ?: -1,
            losePoints = Ui.parseInt(l.text.toString()) ?: -1, gamePoints = Ui.parseInt(g.text.toString()) ?: -1,
            deciderPoints = Ui.parseInt(dec.text.toString()) ?: -1, doubleRound = dbl.isChecked)
        shuffle = shuf.isChecked
    }

    private fun validateSettings(): String? {
        if (leagueName.isBlank()) return "نام لیگ را وارد کنید."
        if (st.winPoints < 0 || st.drawPoints < 0 || st.losePoints < 0) return "امتیازهای جدول باید عدد صحیح و غیرمنفی باشند."
        if (sport != Sport.FOOTBALL && (st.gamePoints !in 1..99 || st.deciderPoints !in 1..99)) return "امتیاز هر گیم/ست باید بین ۱ تا ۹۹ باشد."
        return null
    }

    private fun stepConfirm() {
        title("بررسی و ساخت لیگ")
        val c = Ui.card(this)
        c.addView(Ui.tv(this, leagueName.trim(), 18f, true))
        c.addView(Ui.tv(this, "${Labels.emoji(sport!!)} ${Labels.sport(sport!!)}  •  ${Labels.format(format!!)}", 13f, false, Ui.sub(this)))
        root.addView(c)
        val list = Ui.card(this)
        list.addView(Ui.tv(this, "${Labels.noun(sport!!)}ها (${Ui.fa(names.size)})", 14f, true))
        names.forEachIndexed { i, n -> list.addView(Ui.tv(this, "${Ui.fa(i + 1)}. ${n.trim()}", 14f).apply { setPadding(0, dp(4), 0, 0) }) }
        root.addView(list)
        val progress = ProgressBar(this).apply { visibility = View.GONE }
        root.addView(progress, Ui.lp(Ui.WRAP, Ui.WRAP).apply { gravity = Gravity.CENTER })
        val create = Ui.button(this, "ساخت لیگ") {}
        create.setOnClickListener {
            create.isEnabled = false; progress.visibility = View.VISIBLE
            lifecycleScope.launch {
                try {
                    val id = repo.createLeague(leagueName, sport!!, format!!, names, st, shuffle)
                    startActivity(Intent(this@CreateLeagueActivity, LeagueActivity::class.java).putExtra(LeagueActivity.EXTRA_ID, id))
                    finish()
                } catch (e: Exception) {
                    create.isEnabled = true; progress.visibility = View.GONE
                    Ui.toast(this@CreateLeagueActivity, e.message ?: "ساخت لیگ ناموفق بود.")
                }
            }
        }
        root.addView(create, Ui.lp(c = this, t = 8))
        root.addView(Ui.button(this, "ویرایش فهرست اسامی", false) { step = 3; render() }, Ui.lp(c = this, t = 8))
    }
}
