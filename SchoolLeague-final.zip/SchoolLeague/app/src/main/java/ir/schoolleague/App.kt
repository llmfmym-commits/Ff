package ir.schoolleague

import android.app.Application
import ir.schoolleague.ui.Prefs

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.applyNightMode(this)
    }
}
