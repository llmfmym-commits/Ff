package ir.schoolleague.ui

import android.content.DialogInterface
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TableLayout
import android.widget.TableRow
import android.widget.TextView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import ir.schoolleague.data.*
import ir.schoolleague.engine.StandingsCalculator
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

class LeagueActivity : BaseActivity() {
    companion object { const val EXTRA_ID = "leagueId" }

    private data class Raw(val league: League?, val ps: List<Participant>, val ms: List<MatchEntity>, val gs: List<GameScore>)
    private data class State(val league: League, val ps: List<Participant>, val ms: List<MatchEntity>,
                             val gs: List<GameScore>, val st: LeagueSettings) {
        val knockout get() = league.format == Format.KNOCKOUT
        fun name(id: Long?): String = if (id == null) "—" else ps.firstOrNull { it.id == id }?.name ?: "—"
        fun gamesOf(mid: Long) = gs.filter { it.matchId == mid }.sortedBy { it.gameNo }
    }

    private var state: State? = null
    private var tab = 0
    private var filter = 0
    private var leagueId = -1L
    private var gen = 0
    private lateinit var tabsRow: LinearLayout
    private val tabNames get() = listOf("مسابقات", if (state?.knockout == true) "نمودار" else "جدول", "شرکت‌کنندگان", "آمار")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        leagueId = intent.getLongExtra(EXTRA_ID, -1)
        tabsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(8), dp(8), dp(8), dp(8)) }
        val tabScroll = HorizontalScrollView(this).apply { addView(tabsRow); setBackgroundColor(Ui.surface(this@LeagueActivity)) }
        buildScreen("", true, tabScroll)
        addHeaderAction("⋮", "گزینه‌های لیگ") { showMenu(it) }
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                combine(repo.dao.observeLeague(leagueId), repo.dao.observeParticipants(leagueId),
                    repo.dao.observeMatches(leagueId), repo.dao.observeLeagueGames(leagueId)) { l, p, m, g -> Raw(l, p, m, g) }
                    .collect { raw ->
                        val l = raw.league
                        if (l == null) { finish(); return@collect }
                        val st = repo.dao.getSettings(leagueId) ?: LeagueRepository.defaultSettings(leagueId, l.sport)
                        state = State(l, raw.ps, raw.ms, raw.gs, st)
                        titleView.text = l.name
                        render()
                    }
            }
        }
    }

    // ---------- chrome ----------
    private fun renderTabs() {
        tabsRow.removeAllViews()
        tabNames.forEachIndexed { i, t ->
            val sel = i == tab
            tabsRow.addView(Ui.tv(this, t, 14f, true, if (sel) Color.WHITE else Prefs.primary(this)).apply {
                gravity = Gravity.CENTER; minHeight = dp(44)
                setPadding(dp(16), dp(6), dp(16), dp(6))
                background = if (sel) Ui.rounded(Prefs.primary(this@LeagueActivity), dp(22))
                else Ui.rounded(Color.TRANSPARENT, dp(22), Prefs.primary(this@LeagueActivity), dp(1))
                setOnClickListener { tab = i; render() }
            }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, this, 4, 0, 4, 0))
        }
    }

    private fun render() {
        val s = state ?: return
        gen++
        renderTabs()
        body.removeAllViews()
        val head = Ui.tv(this, "${Labels.emoji(s.league.sport)} ${Labels.sport(s.league.sport)} • ${Labels.format(s.league.format)} • " +
            if (s.league.status == Status.ACTIVE) "در حال برگزاری" else "پایان‌یافته", 13f, false, Ui.sub(this))
        body.addView(head, Ui.lp(c = this, b = 10))
        when (tab) {
            0 -> renderMatches(s)
            1 -> if (s.knockout) renderBracket(s) else body.addView(tableView(standingsTable(s, false)))
            2 -> renderParticipants(s)
            else -> renderStats(s)
        }
    }

    private fun showMenu(anchor: View) {
        val s = state ?: return
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, "ویرایش نام لیگ")
        pm.menu.add(0, 2, 1, "تنظیمات لیگ")
        pm.menu.add(0, 3, 2, if (s.league.status == Status.ACTIVE) "پایان دادن به لیگ" else "بازگشایی لیگ")
        pm.menu.add(0, 4, 3, "حذف لیگ")
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> Ui.prompt(this, "نام لیگ", s.league.name) { n ->
                    if (n.isBlank()) Ui.toast(this, "نام لیگ نباید خالی باشد.") else lifecycleScope.launch { repo.renameLeague(leagueId, n) } }
                2 -> showLeagueSettings(s)
                3 -> {
                    val finish = s.league.status == Status.ACTIVE
                    val pending = s.ms.count { !it.played && !it.isBye }
                    val msg = (if (finish && pending > 0) "هنوز ${Ui.fa(pending)} مسابقه ثبت نشده است. " else "") +
                        (if (finish) "لیگ به بخش پایان‌یافته منتقل می‌شود و سوابق آن قابل مشاهده می‌ماند." else "لیگ دوباره در حال برگزاری می‌شود.")
                    Ui.confirm(this, if (finish) "پایان لیگ" else "بازگشایی لیگ", msg) { lifecycleScope.launch { repo.setFinished(leagueId, finish) } }
                }
                4 -> Ui.confirm(this, "حذف لیگ", "لیگ و همه‌ی نتایج آن برای همیشه حذف می‌شود.", "حذف") {
                    lifecycleScope.launch { repo.deleteLeague(leagueId) } }
            }
            true
        }
        pm.show()
    }

    private fun showLeagueSettings(s: State) {
        val c = this
        val box = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val locked = s.ms.any { it.played && !it.isBye }
        fun field(label: String, v: Int, enabled: Boolean = true): EditText {
            box.addView(Ui.tv(c, label, 13f, false, Ui.sub(c)))
            return Ui.edit(c, "", true, v.toString()).also { it.isEnabled = enabled; box.addView(it, Ui.lp(c = c, b = 8)) }
        }
        val win = field("امتیاز برد", s.st.winPoints)
        val draw = if (s.league.sport == Sport.FOOTBALL) field("امتیاز مساوی", s.st.drawPoints) else null
        val lose = field("امتیاز باخت", s.st.losePoints)
        val game = if (s.league.sport != Sport.FOOTBALL) field("امتیاز هر گیم/ست" + if (locked) " (پس از ثبت نتیجه قفل است)" else "", s.st.gamePoints, !locked) else null
        val dec = if (s.league.sport == Sport.VOLLEYBALL) field("امتیاز ست تعیین‌کننده" + if (locked) " (قفل)" else "", s.st.deciderPoints, !locked) else null
        val dlg = MaterialAlertDialogBuilder(c).setTitle("تنظیمات لیگ").setView(box)
            .setPositiveButton("ذخیره", null).setNegativeButton("انصراف", null).create()
        dlg.show()
        dlg.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
            val w = Ui.parseInt(win.text.toString()); val l = Ui.parseInt(lose.text.toString())
            val d = draw?.let { Ui.parseInt(it.text.toString()) } ?: s.st.drawPoints
            val g = game?.let { Ui.parseInt(it.text.toString()) } ?: s.st.gamePoints
            val dc = dec?.let { Ui.parseInt(it.text.toString()) } ?: s.st.deciderPoints
            if (w == null || l == null || w < 0 || l < 0 || d < 0) { Ui.toast(c, "امتیازها باید عدد غیرمنفی باشند."); return@setOnClickListener }
            if (g !in 1..99 || dc !in 1..99) { Ui.toast(c, "امتیاز هر گیم/ست باید بین ۱ تا ۹۹ باشد."); return@setOnClickListener }
            lifecycleScope.launch { repo.saveSettings(s.st.copy(winPoints = w, losePoints = l, drawPoints = d, gamePoints = g, deciderPoints = dc)); dlg.dismiss() }
        }
    }

    // ---------- matches ----------
    private fun renderMatches(s: State) {
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("همه", "انجام‌شده", "باقی‌مانده").forEachIndexed { i, t ->
            chips.addView(Ui.tv(this, t, 13f, true, if (filter == i) Color.WHITE else Prefs.primary(this)).apply {
                gravity = Gravity.CENTER; minHeight = dp(40); setPadding(dp(14), dp(4), dp(14), dp(4))
                background = if (filter == i) Ui.rounded(Prefs.primary(this@LeagueActivity), dp(20))
                else Ui.rounded(Color.TRANSPARENT, dp(20), Prefs.primary(this@LeagueActivity), dp(1))
                setOnClickListener { filter = i; render() }
            }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, this, 0, 0, 6, 0))
        }
        body.addView(chips, Ui.lp(c = this, b = 8))
        val real = s.ms.filter { !it.isBye }
        body.addView(Ui.tv(this, "انجام‌شده: ${Ui.fa(real.count { it.played })} از ${Ui.fa(real.size)}  •  باقی‌مانده: ${Ui.fa(real.count { !it.played })}", 13f, false, Ui.sub(this)),
            Ui.lp(c = this, b = 8))
        val rounds = (s.ms.maxOfOrNull { it.round } ?: -1) + 1
        var shown = 0
        for (r in 0 until rounds) {
            val list = s.ms.filter { it.round == r && (filter == 0 || (filter == 1 && it.played) || (filter == 2 && !it.played)) }
            if (list.isEmpty()) continue
            body.addView(Ui.tv(this, Labels.roundTitle(s.league.format, r, rounds), 16f, true).apply { setPadding(dp(4), dp(8), dp(4), dp(6)) })
            list.forEach { body.addView(matchCard(s, it)); shown++ }
        }
        if (shown == 0) body.addView(Ui.tv(this, "مسابقه‌ای برای نمایش وجود ندارد.", 14f, false, Ui.sub(this)))
    }

    private fun scoreText(s: State, m: MatchEntity): String {
        if (!m.played) return "—"
        return "${Ui.fa(m.scoreA)} - ${Ui.fa(m.scoreB)}"
    }

    private fun detailText(s: State, m: MatchEntity): String {
        if (!m.played) return ""
        if (s.league.sport == Sport.FOOTBALL) {
            var t = ""
            if (m.extraTime) t += "وقت اضافه"
            if (m.penA != null && m.penB != null) t += (if (t.isEmpty()) "" else " • ") + "پنالتی ${Ui.fa(m.penA)} - ${Ui.fa(m.penB)}"
            return t
        }
        return s.gamesOf(m.id).joinToString("  ،  ") { "${Ui.fa(it.pointsA)}-${Ui.fa(it.pointsB)}" }
    }

    private fun matchCard(s: State, m: MatchEntity): View {
        val card = Ui.card(this)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        fun nm(id: Long?) = if (id == null) "در انتظار نتیجه‌ی مسابقه‌ی قبلی" else s.name(id)
        row.addView(Ui.tv(this, nm(m.aId), 15f, m.winnerId != null && m.winnerId == m.aId), Ui.lp(0, Ui.WRAP, 1f))
        row.addView(Ui.tv(this, scoreText(s, m), 17f, true, Prefs.primary(this)).apply { gravity = Gravity.CENTER; setPadding(dp(10), 0, dp(10), 0) })
        row.addView(Ui.tv(this, nm(m.bId), 15f, m.winnerId != null && m.winnerId == m.bId).apply { gravity = Gravity.END; textAlignment = View.TEXT_ALIGNMENT_VIEW_END }, Ui.lp(0, Ui.WRAP, 1f))
        card.addView(row)
        val d = detailText(s, m)
        if (d.isNotEmpty()) card.addView(Ui.tv(this, d, 12f, false, Ui.sub(this)).apply { gravity = Gravity.CENTER }, Ui.lp())
        if (m.isBye) {
            card.addView(Ui.tv(this, "استراحت — بدون بازی صعود کرد", 12f, false, Ui.sub(this)).apply { gravity = Gravity.CENTER })
        } else if (m.aId != null && m.bId != null) {
            card.addView(Ui.button(this, if (m.played) "ویرایش نتیجه" else "ثبت نتیجه", m.played.not()) { openResult(s, m) }, Ui.lp(c = this, t = 8))
        }
        return card
    }

    // ---------- result dialogs ----------
    private fun openResult(s: State, m: MatchEntity) {
        if (s.league.sport == Sport.FOOTBALL) footballDialog(s, m) else setDialog(s, m)
    }

    private fun guardDependents(s: State, m: MatchEntity, action: () -> Unit) {
        lifecycleScope.launch {
            if (m.played && repo.hasDependentResults(m.id))
                Ui.confirm(this@LeagueActivity, "تغییر نتیجه", "نتیجه‌ی مرحله‌ی بعد به این مسابقه وابسته است. اگر برنده تغییر کند یا نتیجه حذف شود، نتایج وابسته پاک می‌شوند. ادامه می‌دهید؟", "ادامه") { action() }
            else action()
        }
    }

    private fun setDialog(s: State, m: MatchEntity) {
        val c = this
        val rules = LeagueRepository.rulesFor(s.league.sport, s.st)!!
        val unit = Labels.unit(s.league.sport)
        val box = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val head = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        head.addView(Ui.tv(c, "", 13f), Ui.lp(dp(64), Ui.WRAP))
        head.addView(Ui.tv(c, s.name(m.aId), 14f, true).apply { gravity = Gravity.CENTER }, Ui.lp(0, Ui.WRAP, 1f))
        head.addView(Ui.tv(c, s.name(m.bId), 14f, true).apply { gravity = Gravity.CENTER }, Ui.lp(0, Ui.WRAP, 1f))
        box.addView(head, Ui.lp(c = c, b = 6))
        val existing = s.gamesOf(m.id)
        val aEts = ArrayList<EditText>(); val bEts = ArrayList<EditText>()
        for (i in 0 until rules.maxSets()) {
            val row = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            row.addView(Ui.tv(c, "$unit ${Ui.fa(i + 1)}", 13f, true), Ui.lp(dp(64), Ui.WRAP))
            val ea = Ui.edit(c, "", true, existing.getOrNull(i)?.pointsA?.toString() ?: "").apply { gravity = Gravity.CENTER; contentDescription = "$unit ${i + 1} امتیاز اول" }
            val eb = Ui.edit(c, "", true, existing.getOrNull(i)?.pointsB?.toString() ?: "").apply { gravity = Gravity.CENTER; contentDescription = "$unit ${i + 1} امتیاز دوم" }
            aEts.add(ea); bEts.add(eb)
            row.addView(ea, Ui.lp(0, Ui.WRAP, 1f, c, 2, 2, 2, 2)); row.addView(eb, Ui.lp(0, Ui.WRAP, 1f, c, 2, 2, 2, 2))
            box.addView(row)
        }
        val err = Ui.tv(c, "", 13f, false, Ui.ERROR); box.addView(err)
        var busy = false
        fun update() {
            if (busy) return
            busy = true
            val prev = ArrayList<IntArray>(); var open = true
            for (i in aEts.indices) {
                val en = open
                aEts[i].isEnabled = en; bEts[i].isEnabled = en
                if (!en) { if (aEts[i].text.isNotEmpty()) aEts[i].setText(""); if (bEts[i].text.isNotEmpty()) bEts[i].setText("") }
                if (en) {
                    val a = Ui.parseInt(aEts[i].text.toString()); val b = Ui.parseInt(bEts[i].text.toString())
                    if (a != null && b != null && rules.validateSet(a, b, rules.targetFor(i)) == null) { prev.add(intArrayOf(a, b)); open = rules.isNextSetEnabled(prev) }
                    else open = false
                }
            }
            busy = false
        }
        val watcher = object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}
            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}
            override fun afterTextChanged(p0: Editable?) { update() }
        }
        aEts.forEach { it.addTextChangedListener(watcher) }; bEts.forEach { it.addTextChangedListener(watcher) }
        update()
        val builder = MaterialAlertDialogBuilder(c).setTitle("ثبت نتیجه").setView(box)
            .setPositiveButton("ذخیره", null).setNegativeButton("انصراف", null)
        if (m.played) builder.setNeutralButton("حذف نتیجه", null)
        val dlg = builder.create(); dlg.show()
        dlg.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
            val games = ArrayList<IntArray>()
            for (i in aEts.indices) {
                if (!aEts[i].isEnabled) continue
                val at = aEts[i].text.toString(); val bt = bEts[i].text.toString()
                if (at.isBlank() && bt.isBlank()) continue
                val a = Ui.parseInt(at); val b = Ui.parseInt(bt)
                if (a == null || b == null) { err.text = "امتیازها را به‌صورت عدد کامل وارد کنید."; return@setOnClickListener }
                games.add(intArrayOf(a, b))
            }
            guardDependents(s, m) {
                lifecycleScope.launch {
                    val e = repo.saveSetResult(m.id, games)
                    if (e != null) err.text = e else dlg.dismiss()
                }
            }
        }
        if (m.played) dlg.getButton(DialogInterface.BUTTON_NEUTRAL).setOnClickListener {
            guardDependents(s, m) {
                Ui.confirm(c, "حذف نتیجه", "نتیجه‌ی این مسابقه حذف می‌شود و جدول و آمار دوباره محاسبه می‌شود.", "حذف") {
                    lifecycleScope.launch { repo.deleteResult(m.id); dlg.dismiss() }
                }
            }
        }
    }

    private fun footballDialog(s: State, m: MatchEntity) {
        val c = this
        val knock = s.knockout
        val box = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        fun row(label: String, v: Int?): EditText {
            val r = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            r.addView(Ui.tv(c, label, 14f, true), Ui.lp(0, Ui.WRAP, 1f))
            val e = Ui.edit(c, "", true, v?.toString() ?: "").apply { gravity = Gravity.CENTER; contentDescription = "گل $label" }
            r.addView(e, Ui.lp(dp(90), Ui.WRAP)); box.addView(r, Ui.lp(c = c, b = 6)); return e
        }
        val ga = row(s.name(m.aId), if (m.played) m.scoreA else null)
        val gb = row(s.name(m.bId), if (m.played) m.scoreB else null)
        val extra = CheckBox(c).apply { text = "وقت اضافه بازی شد"; isChecked = m.extraTime; setTextColor(Ui.ink(c)); visibility = View.GONE }
        val penBox = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        box.addView(extra)
        box.addView(penBox)
        penBox.addView(Ui.tv(c, "ضربات پنالتی", 13f, true, Ui.sub(c)))
        val pRow = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
        val pa = Ui.edit(c, s.name(m.aId), true, m.penA?.toString() ?: "").apply { gravity = Gravity.CENTER }
        val pb = Ui.edit(c, s.name(m.bId), true, m.penB?.toString() ?: "").apply { gravity = Gravity.CENTER }
        pRow.addView(pa, Ui.lp(0, Ui.WRAP, 1f, c, 2, 2, 2, 2)); pRow.addView(pb, Ui.lp(0, Ui.WRAP, 1f, c, 2, 2, 2, 2))
        penBox.addView(pRow)
        val err = Ui.tv(c, "", 13f, false, Ui.ERROR); box.addView(err)
        fun update() {
            val a = Ui.parseInt(ga.text.toString()); val b = Ui.parseInt(gb.text.toString())
            val draw = knock && a != null && b != null && a == b
            extra.visibility = if (draw) View.VISIBLE else View.GONE
            penBox.visibility = if (draw) View.VISIBLE else View.GONE
        }
        val w = object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}
            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}
            override fun afterTextChanged(p0: Editable?) { update() }
        }
        ga.addTextChangedListener(w); gb.addTextChangedListener(w); update()
        val builder = MaterialAlertDialogBuilder(c).setTitle("ثبت نتیجه").setView(box)
            .setPositiveButton("ذخیره", null).setNegativeButton("انصراف", null)
        if (m.played) builder.setNeutralButton("حذف نتیجه", null)
        val dlg = builder.create(); dlg.show()
        dlg.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
            val a = Ui.parseInt(ga.text.toString()); val b = Ui.parseInt(gb.text.toString())
            if (a == null || b == null) { err.text = "تعداد گل هر دو تیم را وارد کنید."; return@setOnClickListener }
            val penA = Ui.parseInt(pa.text.toString()); val penB = Ui.parseInt(pb.text.toString())
            guardDependents(s, m) {
                lifecycleScope.launch {
                    val e = repo.saveFootballResult(m.id, a, b, penA, penB, extra.isChecked && extra.visibility == View.VISIBLE)
                    if (e != null) err.text = e else dlg.dismiss()
                }
            }
        }
        if (m.played) dlg.getButton(DialogInterface.BUTTON_NEUTRAL).setOnClickListener {
            guardDependents(s, m) {
                Ui.confirm(c, "حذف نتیجه", "نتیجه‌ی این مسابقه حذف می‌شود و جدول و آمار دوباره محاسبه می‌شود.", "حذف") {
                    lifecycleScope.launch { repo.deleteResult(m.id); dlg.dismiss() }
                }
            }
        }
    }

    // ---------- tables ----------
    private fun standings(s: State): List<StandingsCalculator.Row> {
        val results = s.ms.filter { it.played && !it.isBye && it.aId != null && it.bId != null }.map { m ->
            val g = s.gamesOf(m.id)
            StandingsCalculator.Result(m.aId!!.toInt(), m.bId!!.toInt(), m.scoreA, m.scoreB, g.sumOf { it.pointsA }, g.sumOf { it.pointsB })
        }
        return StandingsCalculator.compute(s.ps.map { it.id.toInt() }, results, s.st.winPoints, s.st.drawPoints, s.st.losePoints)
    }

    /** headers + rows for the sport; `stats` selects the statistics layout. */
    private fun standingsTable(s: State, stats: Boolean): Pair<List<String>, List<List<String>>> {
        val rows = standings(s)
        val f = { x: Int -> Ui.fa(x) }
        val nm = { r: StandingsCalculator.Row -> s.name(r.id.toLong()) }
        return when (s.league.sport) {
            Sport.FOOTBALL -> listOf("رتبه", "تیم", "بازی", "برد", "مساوی", "باخت", "گل زده", "گل خورده", "تفاضل", "امتیاز") to
                rows.mapIndexed { i, r -> listOf(f(i + 1), nm(r), f(r.played), f(r.wins), f(r.draws), f(r.losses), f(r.scored), f(r.conceded), f(r.diff()), f(r.points)) }
            Sport.VOLLEYBALL -> if (stats)
                listOf("رتبه", "تیم", "بازی", "برد", "باخت", "ست برده", "ست باخته", "امتیاز کسب‌شده", "امتیاز واگذارشده", "درصد برد") to
                    rows.mapIndexed { i, r -> listOf(f(i + 1), nm(r), f(r.played), f(r.wins), f(r.losses), f(r.scored), f(r.conceded), f(r.ptsFor), f(r.ptsAgainst), Ui.fa("%.0f".format(r.winRate())) + "٪") }
            else listOf("رتبه", "تیم", "بازی", "برد", "باخت", "ست برده", "ست باخته", "تفاضل امتیاز", "امتیاز") to
                rows.mapIndexed { i, r -> listOf(f(i + 1), nm(r), f(r.played), f(r.wins), f(r.losses), f(r.scored), f(r.conceded), f(r.ptsDiff()), f(r.points)) }
            else -> if (stats)
                listOf("رتبه", "بازیکن", "مسابقه", "برد", "باخت", "گیم برده", "گیم باخته", "درصد برد") to
                    rows.mapIndexed { i, r -> listOf(f(i + 1), nm(r), f(r.played), f(r.wins), f(r.losses), f(r.scored), f(r.conceded), Ui.fa("%.0f".format(r.winRate())) + "٪") }
            else listOf("رتبه", "بازیکن", "مسابقه", "برد", "باخت", "گیم برده", "گیم باخته", "تفاضل امتیاز", "امتیاز") to
                rows.mapIndexed { i, r -> listOf(f(i + 1), nm(r), f(r.played), f(r.wins), f(r.losses), f(r.scored), f(r.conceded), f(r.ptsDiff()), f(r.points)) }
        }
    }

    private fun tableView(t: Pair<List<String>, List<List<String>>>): View {
        val tl = TableLayout(this).apply { layoutDirection = View.LAYOUT_DIRECTION_RTL }
        fun cell(text: String, header: Boolean, name: Boolean) = Ui.tv(this, text, 13f, header, if (header) Color.WHITE else Ui.ink(this)).apply {
            setPadding(dp(10), dp(10), dp(10), dp(10)); gravity = if (name) Gravity.START or Gravity.CENTER_VERTICAL else Gravity.CENTER
            if (name) minWidth = dp(96)
        }
        val hr = TableRow(this).apply { setBackgroundColor(Prefs.primary(this@LeagueActivity)) }
        t.first.forEachIndexed { i, h -> hr.addView(cell(h, true, i == 1)) }
        tl.addView(hr)
        t.second.forEachIndexed { ri, r ->
            val tr = TableRow(this).apply { setBackgroundColor(if (ri % 2 == 0) Ui.surface(this@LeagueActivity) else Ui.bg(this@LeagueActivity)) }
            r.forEachIndexed { i, v -> tr.addView(cell(v, false, i == 1)) }
            tl.addView(tr)
        }
        return HorizontalScrollView(this).apply { addView(tl); background = Ui.rounded(Ui.surface(this@LeagueActivity), dp(12)) }
    }

    // ---------- bracket ----------
    private fun renderBracket(s: State) {
        val rounds = (s.ms.maxOfOrNull { it.round } ?: -1) + 1
        val slotH = dp(112); val n0 = s.ms.count { it.round == 0 }
        val h = n0 * slotH
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(dp(4), dp(4), dp(4), dp(4)) }
        for (r in 0 until rounds) {
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.addView(Ui.tv(this, Labels.roundTitle(s.league.format, r, rounds), 14f, true, Prefs.primary(this)).apply { gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(8)) }, Ui.lp())
            val list = s.ms.filter { it.round == r }
            val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            list.forEach { m ->
                val fr = FrameLayout(this)
                fr.addView(bracketCard(s, m), FrameLayout.LayoutParams(dp(164), Ui.WRAP, Gravity.CENTER))
                wrap.addView(fr, Ui.lp(Ui.WRAP, h / list.size))
            }
            col.addView(wrap)
            row.addView(col, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, this, 0, 0, 10, 0))
        }
        val finalMatch = s.ms.firstOrNull { it.round == rounds - 1 }
        val champ = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        champ.addView(Ui.tv(this, "قهرمان", 14f, true, Prefs.primary(this)).apply { setPadding(0, 0, 0, dp(8)) })
        val fr = FrameLayout(this)
        val box = Ui.card(this).apply { gravity = Gravity.CENTER_HORIZONTAL }
        box.addView(Ui.tv(this, "🏆", 30f).apply { gravity = Gravity.CENTER })
        box.addView(Ui.tv(this, if (finalMatch?.played == true) s.name(finalMatch.winnerId) else "مشخص نشده", 15f, true).apply { gravity = Gravity.CENTER })
        fr.addView(box, FrameLayout.LayoutParams(dp(140), Ui.WRAP, Gravity.CENTER))
        champ.addView(fr, Ui.lp(Ui.WRAP, h))
        row.addView(champ)
        body.addView(HorizontalScrollView(this).apply { addView(row) })
        body.addView(Ui.tv(this, "برای ثبت یا ویرایش نتیجه، روی مسابقه بزنید. مسیر صعود هر شرکت‌کننده با پررنگ‌شدن نام برنده دیده می‌شود.", 12f, false, Ui.sub(this)), Ui.lp(c = this, t = 8))
    }

    private fun bracketCard(s: State, m: MatchEntity): View {
        val card = Ui.card(this).apply { setPadding(dp(10), dp(8), dp(10), dp(8)); layoutParams = null }
        fun line(id: Long?, score: Int, win: Boolean): View {
            val l = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            l.addView(Ui.tv(this, if (id == null) (if (m.isBye) "استراحت" else "؟") else s.name(id), 13f, win, if (id == null) Ui.sub(this) else Ui.ink(this)).apply { maxLines = 1 }, Ui.lp(0, Ui.WRAP, 1f))
            if (m.played && !m.isBye) l.addView(Ui.tv(this, Ui.fa(score), 13f, true, Prefs.primary(this)))
            return l
        }
        card.addView(line(m.aId, m.scoreA, m.played && m.winnerId == m.aId))
        card.addView(View(this).apply { setBackgroundColor(Ui.line(this@LeagueActivity)) }, Ui.lp(Ui.MATCH, 1, 0f, this, 0, 4, 0, 4))
        card.addView(line(m.bId, m.scoreB, m.played && m.winnerId == m.bId))
        if (!m.isBye && m.aId != null && m.bId != null) {
            card.isClickable = true; card.isFocusable = true
            card.setOnClickListener { openResult(s, m) }
        }
        return card
    }

    // ---------- participants ----------
    private fun renderParticipants(s: State) {
        val noun = Labels.noun(s.league.sport)
        val g = gen
        lifecycleScope.launch {
            val editable = repo.canEditStructure(leagueId)
            if (g != gen) return@launch
            s.ps.forEachIndexed { i, p ->
                val card = Ui.card(this@LeagueActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                card.addView(Ui.tv(this@LeagueActivity, "${Ui.fa(i + 1)}. ${p.name}", 15f, true), Ui.lp(0, Ui.WRAP, 1f))
                card.addView(Ui.tv(this@LeagueActivity, "✏", 20f).apply {
                    contentDescription = "ویرایش نام"; gravity = Gravity.CENTER; minWidth = dp(48); minHeight = dp(48)
                    setOnClickListener { Ui.prompt(this@LeagueActivity, "ویرایش نام", p.name) { n ->
                        lifecycleScope.launch { repo.renameParticipant(p, n)?.let { Ui.toast(this@LeagueActivity, it) } } } }
                })
                if (editable) card.addView(Ui.tv(this@LeagueActivity, "🗑", 20f).apply {
                    contentDescription = "حذف"; gravity = Gravity.CENTER; minWidth = dp(48); minHeight = dp(48)
                    setOnClickListener { Ui.confirm(this@LeagueActivity, "حذف $noun", "برنامه‌ی مسابقات دوباره ساخته می‌شود.", "حذف") {
                        lifecycleScope.launch { repo.removeParticipant(p)?.let { Ui.toast(this@LeagueActivity, it) } } } }
                })
                body.addView(card)
            }
            if (editable) body.addView(Ui.button(this@LeagueActivity, "افزودن $noun") {
                Ui.prompt(this@LeagueActivity, "نام $noun جدید", "") { n ->
                    lifecycleScope.launch { repo.addParticipant(leagueId, n)?.let { Ui.toast(this@LeagueActivity, it) } } }
            }, Ui.lp(c = this@LeagueActivity, t = 4))
            else body.addView(Ui.tv(this@LeagueActivity, "پس از ثبت نتیجه، فقط ویرایش نام ممکن است (افزودن/حذف، برنامه را بر هم می‌زند).", 12f, false, Ui.sub(this@LeagueActivity)))
        }
    }

    // ---------- stats ----------
    private fun renderStats(s: State) {
        val real = s.ms.filter { !it.isBye }
        val done = real.count { it.played }
        val sum = Ui.card(this)
        sum.addView(Ui.tv(this, "خلاصه‌ی لیگ", 16f, true))
        sum.addView(Ui.tv(this, "کل مسابقات: ${Ui.fa(real.size)}  •  انجام‌شده: ${Ui.fa(done)}  •  باقی‌مانده: ${Ui.fa(real.size - done)}", 13f, false, Ui.sub(this)).apply { setPadding(0, dp(4), 0, 0) })
        val rows = standings(s).filter { it.played > 0 }
        if (s.league.sport == Sport.FOOTBALL && rows.isNotEmpty()) {
            val atk = rows.maxByOrNull { it.scored }!!; val def = rows.minByOrNull { it.conceded }!!
            sum.addView(Ui.tv(this, "بهترین خط حمله: ${s.name(atk.id.toLong())} (${Ui.fa(atk.scored)} گل)", 13f).apply { setPadding(0, dp(6), 0, 0) })
            sum.addView(Ui.tv(this, "بهترین خط دفاع: ${s.name(def.id.toLong())} (${Ui.fa(def.conceded)} گل خورده)", 13f))
            sum.addView(Ui.tv(this, "گل‌زنان در مسابقه‌ها ثبت نمی‌شوند؛ بنابراین آمار گل‌زنان نمایش داده نمی‌شود.", 12f, false, Ui.sub(this)).apply { setPadding(0, dp(6), 0, 0) })
        }
        if (rows.isEmpty()) sum.addView(Ui.tv(this, "هنوز نتیجه‌ای ثبت نشده است؛ آمار از نتایج واقعی محاسبه می‌شود.", 12f, false, Ui.sub(this)).apply { setPadding(0, dp(6), 0, 0) })
        body.addView(sum)
        body.addView(tableView(standingsTable(s, true)))
    }
}
