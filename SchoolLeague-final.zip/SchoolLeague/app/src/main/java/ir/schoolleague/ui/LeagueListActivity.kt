package ir.schoolleague.ui

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import ir.schoolleague.data.League
import ir.schoolleague.data.Sport
import ir.schoolleague.data.Status
import kotlinx.coroutines.launch

class LeagueListActivity : BaseActivity() {
    companion object { const val EXTRA_SPORT = "sport" }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sport = intent.getStringExtra(EXTRA_SPORT) ?: Sport.PINGPONG
        val r = buildScreen("لیگ‌های ${Labels.sport(sport)}")
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                repo.dao.observeBySport(sport).collect { leagues ->
                    val counts = leagues.associate { it.id to repo.dao.countParticipants(it.id) }
                    r.removeAllViews()
                    section(r, "در حال برگزاری", leagues.filter { it.status == Status.ACTIVE }, counts)
                    section(r, "پایان‌یافته", leagues.filter { it.status == Status.FINISHED }, counts)
                    r.addView(Ui.button(this@LeagueListActivity, "ساخت لیگ جدید ${Labels.emoji(sport)}") {
                        startActivity(Intent(this@LeagueListActivity, CreateLeagueActivity::class.java)
                            .putExtra(CreateLeagueActivity.EXTRA_SPORT, sport))
                    }, Ui.lp(c = this@LeagueListActivity, t = 8))
                }
            }
        }
    }

    private fun section(r: LinearLayout, title: String, list: List<League>, counts: Map<Long, Int>) {
        r.addView(Ui.tv(this, "$title (${Ui.fa(list.size)})", 16f, true).apply { setPadding(dp(4), dp(8), dp(4), dp(8)) })
        if (list.isEmpty()) {
            r.addView(Ui.tv(this, "لیگی در این بخش وجود ندارد.", 13f, false, Ui.sub(this)).apply { setPadding(dp(4), 0, dp(4), dp(12)) })
            return
        }
        list.forEach { l ->
            val card = Ui.card(this).apply { isClickable = true; isFocusable = true }
            card.addView(Ui.tv(this, l.name, 17f, true))
            val n = counts[l.id] ?: 0
            card.addView(Ui.tv(this, "${Labels.emoji(l.sport)} ${Labels.sport(l.sport)}  •  ${Labels.format(l.format)}  •  " +
                "${Ui.fa(n)} ${Labels.noun(l.sport)}  •  " + (if (l.status == Status.ACTIVE) "در حال برگزاری" else "پایان‌یافته"),
                13f, false, Ui.sub(this)).apply { setPadding(0, dp(4), 0, 0) })
            card.setOnClickListener {
                startActivity(Intent(this, LeagueActivity::class.java).putExtra(LeagueActivity.EXTRA_ID, l.id))
            }
            r.addView(card)
        }
    }
}
