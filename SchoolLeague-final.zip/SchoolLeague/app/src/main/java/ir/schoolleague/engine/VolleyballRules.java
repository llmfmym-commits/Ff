package ir.schoolleague.engine;

/** Volleyball: best of 3 sets, 25 points (15 in decider), win by 2; configurable. */
public final class VolleyballRules extends SetMatchRules {
    public VolleyballRules() { this(25, 15); }
    public VolleyballRules(int setPoints, int deciderPoints) { super(2, setPoints, deciderPoints, 2); }
}
