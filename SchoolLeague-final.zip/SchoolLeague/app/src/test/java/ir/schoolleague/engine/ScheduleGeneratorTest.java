package ir.schoolleague.engine;

import static org.junit.Assert.*;
import java.util.*;
import org.junit.Test;

public class ScheduleGeneratorTest {
    @Test public void evenCountAllPairsOnce() {
        List<ScheduleGenerator.Pairing> l = ScheduleGenerator.roundRobin(6, false);
        assertEquals(15, l.size());
        assertEquals(15, pairs(l).size());
    }
    @Test public void oddCountHasByePerRound() {
        List<ScheduleGenerator.Pairing> l = ScheduleGenerator.roundRobin(5, false);
        assertEquals(10, l.size());
        assertEquals(10, pairs(l).size());
        assertEquals(5, ScheduleGenerator.roundsFor(5, false));
        Map<Integer,Set<Integer>> busy = new HashMap<>();
        for (ScheduleGenerator.Pairing p : l) {
            Set<Integer> s = busy.computeIfAbsent(p.round, k -> new HashSet<>());
            assertTrue(s.add(p.a)); assertTrue(s.add(p.b)); // nobody plays twice per round
        }
    }
    @Test public void doubleRound() {
        assertEquals(12, ScheduleGenerator.roundRobin(4, true).size());
        assertEquals(12, ScheduleGenerator.matchesFor(4, true));
    }
    private Set<String> pairs(List<ScheduleGenerator.Pairing> l) {
        Set<String> s = new HashSet<>();
        for (ScheduleGenerator.Pairing p : l) s.add(Math.min(p.a, p.b) + "-" + Math.max(p.a, p.b));
        return s;
    }
}
