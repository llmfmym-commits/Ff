package ir.schoolleague.engine;

import static org.junit.Assert.*;
import java.util.*;
import org.junit.Test;

public class PingPongRulesTest {
    private final PingPongRules r = new PingPongRules();
    private static List<int[]> g(int[]... x) { return new ArrayList<>(Arrays.asList(x)); }

    @Test public void twoZeroNoThirdGame() {
        MatchOutcome o = r.evaluate(g(new int[]{11,7}, new int[]{11,9}));
        assertTrue(o.valid); assertEquals(1, o.winner); assertEquals(2, o.setsA); assertEquals(0, o.setsB);
    }
    @Test public void twoOneWithThirdGame() {
        MatchOutcome o = r.evaluate(g(new int[]{11,8}, new int[]{9,11}, new int[]{11,6}));
        assertTrue(o.valid); assertEquals(1, o.winner); assertEquals(2, o.setsA); assertEquals(1, o.setsB);
    }
    @Test public void thirdGameRejectedAfterWinner() {
        assertFalse(r.evaluate(g(new int[]{11,7}, new int[]{11,9}, new int[]{11,5})).valid);
    }
    @Test public void thirdGameEnabledOnlyAtOneOne() {
        assertFalse(r.isNextSetEnabled(g(new int[]{11,7}, new int[]{11,9})));
        assertTrue(r.isNextSetEnabled(g(new int[]{11,7}, new int[]{9,11})));
    }
    @Test public void deuceGames() {
        assertTrue(r.evaluate(g(new int[]{13,11}, new int[]{12,10})).valid);
        assertNull(r.validateSet(12, 10, 11));
        assertNotNull(r.validateSet(13, 10, 11)); // overshoot without deuce
        assertNotNull(r.validateSet(11, 10, 11)); // margin of 1
    }
    @Test public void rejectsInvalid() {
        assertNotNull(r.validateSet(-1, 11, 11));
        assertNotNull(r.validateSet(11, 11, 11));
        assertNotNull(r.validateSet(10, 8, 11));
        assertFalse(r.evaluate(g(new int[]{11,7})).valid);       // no winner yet
        assertFalse(r.evaluate(g(new int[]{11,7}, new int[]{9,11})).valid); // 1-1 incomplete
        assertFalse(r.evaluate(g(new int[]{21,5}, new int[]{21,5})).valid); // 21-pt style
    }
}
