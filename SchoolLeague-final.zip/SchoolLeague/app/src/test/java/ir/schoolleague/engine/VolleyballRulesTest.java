package ir.schoolleague.engine;

import static org.junit.Assert.*;
import java.util.*;
import org.junit.Test;

public class VolleyballRulesTest {
    private final VolleyballRules r = new VolleyballRules();
    private static List<int[]> g(int[]... x) { return new ArrayList<>(Arrays.asList(x)); }

    @Test public void twoSetsWin() {
        MatchOutcome o = r.evaluate(g(new int[]{25,20}, new int[]{25,23}));
        assertTrue(o.valid); assertEquals(1, o.winner);
    }
    @Test public void decidingSetToFifteen() {
        MatchOutcome o = r.evaluate(g(new int[]{25,20}, new int[]{22,25}, new int[]{15,13}));
        assertTrue(o.valid); assertEquals(1, o.winner); assertEquals(2, o.setsA);
    }
    @Test public void decidingSetCannotUseTwentyFive() {
        assertFalse(r.evaluate(g(new int[]{25,20}, new int[]{22,25}, new int[]{25,10})).valid);
    }
    @Test public void extendedSetAndInvalid() {
        assertNull(r.validateSet(27, 25, 25));
        assertNotNull(r.validateSet(25, 24, 25));
        assertFalse(r.evaluate(g(new int[]{25,20}, new int[]{25,23}, new int[]{15,5})).valid);
    }
}
