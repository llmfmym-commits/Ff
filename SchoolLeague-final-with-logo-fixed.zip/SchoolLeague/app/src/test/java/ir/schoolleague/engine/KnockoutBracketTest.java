package ir.schoolleague.engine;

import static org.junit.Assert.*;
import org.junit.Test;

public class KnockoutBracketTest {
    @Test public void fiveParticipantsHaveThreeByes() {
        KnockoutBracket k = new KnockoutBracket(5);
        assertEquals(8, k.size); assertEquals(3, k.rounds);
        int byes = 0;
        for (KnockoutBracket.Node n : k.round(0)) if (n.isBye()) byes++;
        assertEquals(3, byes);
        // seeds 0..2 receive byes and already sit in round 2 slots
        int placed = 0;
        for (KnockoutBracket.Node n : k.round(1)) {
            if (n.a >= 0) placed++;
            if (n.b >= 0) placed++;
        }
        assertEquals(3, placed);
    }
    @Test public void advanceAndClear() {
        KnockoutBracket k = new KnockoutBracket(4);
        KnockoutBracket.Node m = k.node(0, 0);
        assertTrue(k.isPlayable(m));
        k.advance(m, m.a);
        assertEquals(m.a, k.node(1, 0).a);
        k.clearFrom(m);
        assertEquals(KnockoutBracket.TBD, k.node(1, 0).a);
        assertFalse(k.isPlayable(k.node(1, 0)));
    }
    @Test public void topSeedsMeetOnlyInFinal() {
        KnockoutBracket k = new KnockoutBracket(8);
        assertEquals(0, k.node(0,0).a);
        assertEquals(1, k.node(0,2).a); // seed 2 sits in the other half
        assertEquals(1, k.round(2).size());
    }
}
