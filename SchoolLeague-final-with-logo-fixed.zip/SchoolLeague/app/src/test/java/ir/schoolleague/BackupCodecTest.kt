package ir.schoolleague

import ir.schoolleague.data.*
import org.junit.Assert.*
import org.junit.Test

class BackupCodecTest {
    private val base = BackupData(
        listOf(League(1, "لیگ پایه دهم", Sport.PINGPONG, Format.KNOCKOUT)),
        listOf(Participant(1, 1, "علی", 0), Participant(2, 1, "رضا", 1)),
        listOf(MatchEntity(1, 1, 0, 0, 1, 2, true, 1, 2, 1, null, null, false, false)),
        listOf(GameScore(1, 1, 1, 11, 8), GameScore(2, 1, 2, 9, 11), GameScore(3, 1, 3, 11, 6)),
        listOf(LeagueSettings(1))
    )
    private fun sample() = base

    @Test fun roundTripKeepsEverything() {
        val back = BackupCodec.decode(BackupCodec.encode(sample()))
        assertEquals(sample(), back)
    }
    @Test fun nullableFieldsSurvive() {
        val d = sample().copy(matches = listOf(MatchEntity(1, 1, 1, 0, null, null)))
        assertEquals(d, BackupCodec.decode(BackupCodec.encode(d)))
    }
    @Test fun cardsAndDateSurvive() {
        val d = sample().copy(matches = listOf(MatchEntity(1, 1, 0, 0, 1, 2, true, 1, 2, 1, null, null, false, false, 2, 1, 0, 1, "۱۴۰۵/۰۷/۲۶")))
        assertEquals(d, BackupCodec.decode(BackupCodec.encode(d)))
    }
    @Test fun scheduleStatusAndLogsSurvive() {
        val m = MatchEntity(1, 1, 0, 0, 1, 2, status = MatchStatus.POSTPONED, planDate = "۱۴۰۵/۰۷/۲۶", planTime = "16:30", venue = "سالن ۱")
        val d = sample().copy(matches = listOf(m), logs = listOf(ChangeLog(1, 1, 1, 1700000000000L, "علی - رضا: ثبت نتیجه 2-1")))
        assertEquals(d, BackupCodec.decode(BackupCodec.encode(d)))
    }
    @Test fun teamsAndPlayersSurvive() {
        val d = sample().copy(
            participants = listOf(Participant(1, 1, "علی", 0, "آقای احمدی", "/data/x.png"), Participant(2, 1, "رضا", 1)),
            players = listOf(Player(1, 1, "حسین", 10, "مهاجم", true), Player(2, 1, "مهدی", null, null, false)))
        assertEquals(d, BackupCodec.decode(BackupCodec.encode(d)))
    }
    @Test(expected = IllegalArgumentException::class) fun rejectsPlayerOfUnknownTeam() {
        BackupCodec.decode(BackupCodec.encode(sample().copy(players = listOf(Player(1, 99, "x")))))
    }
    @Test(expected = IllegalArgumentException::class) fun rejectsGarbage() { BackupCodec.decode("not json") }
    @Test(expected = IllegalArgumentException::class) fun rejectsForeignJson() { BackupCodec.decode("{\"app\":\"X\"}") }
    @Test(expected = IllegalArgumentException::class) fun rejectsBrokenReferences() {
        val bad = sample().copy(participants = listOf(Participant(1, 99, "x", 0)))
        BackupCodec.decode(BackupCodec.encode(bad))
    }
}
