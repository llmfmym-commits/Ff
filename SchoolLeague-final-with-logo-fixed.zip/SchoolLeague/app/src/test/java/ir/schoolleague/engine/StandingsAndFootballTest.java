package ir.schoolleague.engine;

import static org.junit.Assert.*;
import java.util.*;
import org.junit.Test;

public class StandingsAndFootballTest {
    @Test public void footballTable() {
        List<StandingsCalculator.Result> r = Arrays.asList(
            new StandingsCalculator.Result(1, 2, 3, 1, 0, 0),
            new StandingsCalculator.Result(2, 3, 2, 2, 0, 0),
            new StandingsCalculator.Result(1, 3, 0, 1, 0, 0));
        List<StandingsCalculator.Row> t = StandingsCalculator.compute(Arrays.asList(1,2,3), r, 3, 1, 0);
        assertEquals(3, t.get(0).id); assertEquals(4, t.get(0).points);
        assertEquals(1, t.get(1).id); assertEquals(3, t.get(1).points);
        assertEquals(2, t.get(2).id); assertEquals(1, t.get(2).points);
        assertEquals(1, t.get(2).draws); assertEquals(-2, t.get(2).diff()); // scored 3, conceded 5
    }
    @Test public void emptyResultsInventNothing() {
        List<StandingsCalculator.Row> t = StandingsCalculator.compute(Arrays.asList(1,2), new ArrayList<>(), 3, 1, 0);
        for (StandingsCalculator.Row x : t) { assertEquals(0, x.played); assertEquals(0, x.points); }
    }
    @Test public void knockoutDrawNeedsPenalties() {
        assertEquals(0, FootballRules.knockoutWinner(1, 1, null, null));
        assertEquals(0, FootballRules.knockoutWinner(1, 1, 4, 4));
        assertEquals(2, FootballRules.knockoutWinner(1, 1, 3, 5));
        assertEquals(1, FootballRules.knockoutWinner(2, 0, null, null));
        assertEquals(0, FootballRules.leagueWinner(2, 2));
    }
}
