package ir.schoolleague

import ir.schoolleague.ui.Jalali
import org.junit.Assert.*
import org.junit.Test

class JalaliTest {
    @Test fun convertsBothWays() {
        assertEquals(Triple(2026, 10, 18), Jalali.toGregorian(1405, 7, 26))
        assertEquals(Triple(2026, 3, 21), Jalali.toGregorian(1405, 1, 1))
        assertEquals(Triple(1405, 7, 26), Jalali.convert(2026, 10, 18))
    }
    @Test fun leapYearsAndMonthLengths() {
        assertTrue(Jalali.isLeap(1403)); assertFalse(Jalali.isLeap(1404))
        assertEquals(30, Jalali.monthLength(1403, 12)); assertEquals(29, Jalali.monthLength(1404, 12))
        assertEquals(31, Jalali.monthLength(1405, 6)); assertEquals(30, Jalali.monthLength(1405, 7))
    }
    @Test fun parsesDatesWithAnyDigits() {
        assertEquals(14050726, Jalali.parseKey("۱۴۰۵/۰۷/۲۶"))
        assertEquals(14050726, Jalali.parseKey("1405-7-26"))
        assertNull(Jalali.parseKey("hello")); assertNull(Jalali.parseKey("1405/13/01")); assertNull(Jalali.parseKey(null))
    }
    @Test fun weekdayIsSaturdayBased() {
        assertEquals(1, Jalali.weekdayIndex(1405, 7, 26))   // 2026-10-18 is a Sunday
        assertEquals(0, Jalali.weekdayIndex(1405, 1, 1))    // 2026-03-21 is a Saturday
    }
}
