package ir.schoolleague.ui

import android.content.DialogInterface
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TableLayout
import android.widget.TableRow
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import ir.schoolleague.data.*
import ir.schoolleague.engine.StandingsCalculator
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

class LeagueActivity : BaseActivity() {
    companion object { const val EXTRA_ID = "leagueId" }

    private data class Raw(val league: League?, val ps: List<Participant>, val ms: List<MatchEntity>, val gs: List<GameScore>)
    private data class State(val league: League, val ps: List<Participant>, val ms: List<MatchEntity>,
                             val gs: List<GameScore>, val st: LeagueSettings) {
        val knockout get() = league.format == Format.KNOCKOUT
        fun name(id: Long?): String = if (id == null) "—" else ps.firstOrNull { it.id == id }?.name ?: "—"
        fun gamesOf(mid: Long) = gs.filter { it.matchId == mid }.sortedBy { it.gameNo }
    }

    private var state: State? = null
    private var tab = 0          // 0 table/bracket, 1 results, 2 stats, 3 participants (from menu)
    private var filter = 0
    private var leagueId = -1L
    private var gen = 0
    private lateinit var tabsRow: LinearLayout
    private val tabNames get() = listOf(if (state?.knockout == true) "نمودار" else "جدول", "نتایج", "آمار")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        leagueId = intent.getLongExtra(EXTRA_ID, -1)
        tabsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; background = Ui.headerBg(this@LeagueActivity)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        buildScreen("", true, tabsRow)
        addHeaderAction("⋮", "گزینه‌های لیگ") { showMenu(it) }
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                combine(repo.dao.observeLeague(leagueId), repo.dao.observeParticipants(leagueId),
                    repo.dao.observeMatches(leagueId), repo.dao.observeLeagueGames(leagueId)) { l, p, m, g -> Raw(l, p, m, g) }
                    .collect { raw ->
                        val l = raw.league
                        if (l == null) { finish(); return@collect }
                        val st = repo.dao.getSettings(leagueId) ?: LeagueRepository.defaultSettings(leagueId, l.sport)
                        if (state == null) setHeaderBadge(Labels.emoji(l.sport))
                        state = State(l, raw.ps, raw.ms, raw.gs, st)
                        titleView.text = l.name
                        render()
                    }
            }
        }
    }

    // ---------- chrome ----------
    private fun renderTabs() {
        tabsRow.removeAllViews()
        tabNames.forEachIndexed { i, t ->
            val sel = i == tab
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; isClickable = true; isFocusable = true; setOnClickListener { tab = i; render() } }
            col.addView(Ui.tv(this, t, 15f, true, if (sel) Color.WHITE else 0xB3FFFFFF.toInt()).apply {
                gravity = Gravity.CENTER; minHeight = dp(46)
            }, Ui.lp())
            col.addView(View(this).apply { setBackgroundColor(if (sel) Color.WHITE else Color.TRANSPARENT) }, Ui.lp(Ui.MATCH, dp(3), 0f, this, 12, 0, 12, 0))
            tabsRow.addView(col, Ui.lp(0, Ui.WRAP, 1f))
        }
    }

    private fun render() {
        val s = state ?: return
        gen++
        renderTabs()
        body.removeAllViews()
        overlay.removeAllViews()
        val status = if (s.league.status == Status.ACTIVE) "در حال برگزاری" else "پایان‌یافته"
        body.addView(Ui.tv(this, "${Labels.format(s.league.format)} • $status", 12f, false, Ui.sub(this)), Ui.lp(c = this, b = 8))
        when (tab) {
            0 -> { if (s.knockout) renderBracket(s) else renderTable(s) ; addFab { chooseMatch(s) } }
            1 -> { renderMatches(s); addFab { chooseMatch(s) } }
            2 -> renderStats(s)
            3 -> renderParticipants(s)
            else -> renderHistory(s)
        }
    }

    private fun chooseMatch(s: State) {
        val open = s.ms.filter { !it.played && !it.isBye && it.aId != null && it.bId != null && it.status != MatchStatus.CANCELLED }
        if (open.isEmpty()) { Ui.toast(this, "همه‌ی مسابقه‌های قابل ثبت، نتیجه دارند."); return }
        val rounds = (s.ms.maxOfOrNull { it.round } ?: -1) + 1
        MaterialAlertDialogBuilder(this).setTitle("کدام مسابقه؟")
            .setItems(open.map { "${s.name(it.aId)} - ${s.name(it.bId)}  (${Labels.roundTitle(s.league.format, it.round, rounds)})" }.toTypedArray()) { _, i ->
                openResult(open[i])
            }.show()
    }

    private fun openResult(m: MatchEntity) {
        startActivity(Intent(this, MatchActivity::class.java).putExtra(MatchActivity.EXTRA_ID, m.id))
    }

    private fun showMenu(anchor: View) {
        val s = state ?: return
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 5, 0, "شرکت‌کنندگان")
        pm.menu.add(0, 1, 1, "ویرایش نام لیگ")
        pm.menu.add(0, 2, 2, "تنظیمات لیگ")
        pm.menu.add(0, 3, 3, if (s.league.status == Status.ACTIVE) "پایان دادن به لیگ" else "بازگشایی لیگ")
        pm.menu.add(0, 6, 3, "تاریخچه‌ی تغییرات")
        pm.menu.add(0, 4, 4, "حذف لیگ")
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                5 -> { tab = 3; render() }
                6 -> { tab = 4; render() }
                1 -> Ui.prompt(this, "نام لیگ", s.league.name) { n ->
                    if (n.isBlank()) Ui.toast(this, "نام لیگ نباید خالی باشد.") else lifecycleScope.launch { repo.renameLeague(leagueId, n) } }
                2 -> showLeagueSettings(s)
                3 -> {
                    val finish = s.league.status == Status.ACTIVE
                    val pending = s.ms.count { !it.played && !it.isBye }
                    val msg = (if (finish && pending > 0) "هنوز ${Ui.fa(pending)} مسابقه ثبت نشده است. " else "") +
                        (if (finish) "لیگ به بخش پایان‌یافته منتقل می‌شود و سوابق آن قابل مشاهده می‌ماند." else "لیگ دوباره در حال برگزاری می‌شود.")
                    Ui.confirm(this, if (finish) "پایان لیگ" else "بازگشایی لیگ", msg) { lifecycleScope.launch { repo.setFinished(leagueId, finish) } }
                }
                4 -> Ui.confirm(this, "حذف لیگ", "لیگ و همه‌ی نتایج آن برای همیشه حذف می‌شود.", "حذف") {
                    lifecycleScope.launch { repo.deleteLeague(leagueId) } }
            }
            true
        }
        pm.show()
    }

    private fun showLeagueSettings(s: State) {
        val c = this
        val box = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val locked = s.ms.any { it.played && !it.isBye }
        fun field(label: String, v: Int, enabled: Boolean = true): EditText {
            box.addView(Ui.tv(c, label, 13f, false, Ui.sub(c)))
            return Ui.edit(c, "", true, v.toString()).also { it.isEnabled = enabled; box.addView(it, Ui.lp(c = c, b = 8)) }
        }
        val win = field("امتیاز برد", s.st.winPoints)
        val draw = if (s.league.sport == Sport.FOOTBALL) field("امتیاز مساوی", s.st.drawPoints) else null
        val lose = field("امتیاز باخت", s.st.losePoints)
        val game = if (s.league.sport != Sport.FOOTBALL) field("امتیاز هر گیم/ست" + if (locked) " (پس از ثبت نتیجه قفل است)" else "", s.st.gamePoints, !locked) else null
        val dec = if (s.league.sport == Sport.VOLLEYBALL) field("امتیاز ست تعیین‌کننده" + if (locked) " (قفل)" else "", s.st.deciderPoints, !locked) else null
        val dlg = MaterialAlertDialogBuilder(c).setTitle("تنظیمات لیگ").setView(box)
            .setPositiveButton("ذخیره", null).setNegativeButton("انصراف", null).create()
        dlg.show()
        dlg.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
            val w = Ui.parseInt(win.text.toString()); val l = Ui.parseInt(lose.text.toString())
            val d = draw?.let { Ui.parseInt(it.text.toString()) } ?: s.st.drawPoints
            val g = game?.let { Ui.parseInt(it.text.toString()) } ?: s.st.gamePoints
            val dc = dec?.let { Ui.parseInt(it.text.toString()) } ?: s.st.deciderPoints
            if (w == null || l == null || w < 0 || l < 0 || d < 0) { Ui.toast(c, "امتیازها باید عدد غیرمنفی باشند."); return@setOnClickListener }
            if (g !in 1..99 || dc !in 1..99) { Ui.toast(c, "امتیاز هر گیم/ست باید بین ۱ تا ۹۹ باشد."); return@setOnClickListener }
            lifecycleScope.launch { repo.saveSettings(s.st.copy(winPoints = w, losePoints = l, drawPoints = d, gamePoints = g, deciderPoints = dc)); dlg.dismiss() }
        }
    }

    // ---------- results tab ----------
    private fun renderMatches(s: State) {
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("همه", "انجام‌شده", "باقی‌مانده", "تعویق/لغو").forEachIndexed { i, t ->
            chips.addView(Ui.tv(this, t, 13f, true, if (filter == i) Color.WHITE else Prefs.primary(this)).apply {
                gravity = Gravity.CENTER; minHeight = dp(40); setPadding(dp(14), dp(4), dp(14), dp(4))
                background = if (filter == i) Ui.rounded(Prefs.primary(this@LeagueActivity), dp(20))
                else Ui.rounded(Color.TRANSPARENT, dp(20), Prefs.primary(this@LeagueActivity), dp(1))
                setOnClickListener { filter = i; render() }
            }, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, this, 0, 0, 6, 0))
        }
        body.addView(HorizontalScrollView(this).apply { addView(chips) }, Ui.lp(c = this, b = 8))
        val real = s.ms.filter { !it.isBye && it.status != MatchStatus.CANCELLED }
        body.addView(Ui.tv(this, "انجام‌شده: ${Ui.fa(real.count { it.played })} از ${Ui.fa(real.size)}  •  باقی‌مانده: ${Ui.fa(real.count { !it.played })}", 13f, false, Ui.sub(this)),
            Ui.lp(c = this, b = 8))
        val rounds = (s.ms.maxOfOrNull { it.round } ?: -1) + 1
        var shown = 0
        for (r in 0 until rounds) {
            val list = s.ms.filter { it.round == r && (filter == 0 || (filter == 1 && it.played) || (filter == 2 && !it.played && it.status != MatchStatus.CANCELLED) ||
                (filter == 3 && (it.status == MatchStatus.POSTPONED || it.status == MatchStatus.CANCELLED))) }
            if (list.isEmpty()) continue
            body.addView(Ui.tv(this, Labels.roundTitle(s.league.format, r, rounds), 16f, true).apply { setPadding(dp(4), dp(8), dp(4), dp(6)) })
            list.forEach { body.addView(matchCard(s, it)); shown++ }
        }
        if (shown == 0) body.addView(Ui.tv(this, "مسابقه‌ای برای نمایش وجود ندارد.", 14f, false, Ui.sub(this)))
        body.addView(View(this), Ui.lp(Ui.MATCH, dp(72)))
    }

    private fun detailText(s: State, m: MatchEntity): String {
        if (!m.played) return ""
        if (s.league.sport == Sport.FOOTBALL) {
            var t = ""
            if (m.extraTime) t += "وقت اضافه"
            if (m.penA != null && m.penB != null) t += (if (t.isEmpty()) "" else " • ") + "پنالتی ${Ui.fa(m.penA)} - ${Ui.fa(m.penB)}"
            return t
        }
        return s.gamesOf(m.id).joinToString("  ،  ") { "${Ui.fa(it.pointsA)}-${Ui.fa(it.pointsB)}" }
    }

    private fun matchCard(s: State, m: MatchEntity): View {
        val card = Ui.card(this)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        fun nm(id: Long?) = if (id == null) "در انتظار نتیجه‌ی مسابقه‌ی قبلی" else s.name(id)
        row.addView(Ui.tv(this, nm(m.aId), 15f, m.winnerId != null && m.winnerId == m.aId), Ui.lp(0, Ui.WRAP, 1f))
        row.addView(Ui.tv(this, if (m.played) "${Ui.fa(m.scoreA)} - ${Ui.fa(m.scoreB)}" else "—", 17f, true, Prefs.primary(this)).apply { gravity = Gravity.CENTER; setPadding(dp(10), 0, dp(10), 0) })
        row.addView(Ui.tv(this, nm(m.bId), 15f, m.winnerId != null && m.winnerId == m.bId).apply { textAlignment = View.TEXT_ALIGNMENT_VIEW_END }, Ui.lp(0, Ui.WRAP, 1f))
        card.addView(row)
        val d = detailText(s, m)
        if (d.isNotEmpty()) card.addView(Ui.tv(this, d, 12f, false, Ui.sub(this)).apply { gravity = Gravity.CENTER }, Ui.lp())
        val plan = listOfNotNull(m.planDate?.let { "📅 $it" }, m.planTime?.let { "⏰ $it" }, m.venue?.let { "📍 $it" }).joinToString("   ")
        if (plan.isNotEmpty() && !m.isBye) card.addView(Ui.tv(this, Ui.fa(plan), 12f, false, Ui.sub(this)).apply { gravity = Gravity.CENTER; setPadding(0, dp(4), 0, 0) }, Ui.lp())
        if (!m.played && !m.isBye && m.status != MatchStatus.SCHEDULED) {
            val warn = if (m.status == MatchStatus.CANCELLED) Ui.ERROR else 0xFFEA580C.toInt()
            card.addView(Ui.tv(this, "● ${MatchStatus.label(m.status)}", 12f, true, warn).apply { gravity = Gravity.CENTER; setPadding(0, dp(4), 0, 0) }, Ui.lp())
        }
        if (m.isBye) {
            card.addView(Ui.tv(this, "استراحت — بدون بازی صعود کرد", 12f, false, Ui.sub(this)).apply { gravity = Gravity.CENTER })
        } else if (m.aId != null && m.bId != null) {
            card.addView(Ui.button(this, if (m.played) "ویرایش نتیجه" else "ثبت نتیجه و برنامه", !m.played) { openResult(m) }, Ui.lp(c = this, t = 8))
        }
        return card
    }

    // ---------- table ----------
    private fun standings(s: State): List<StandingsCalculator.Row> {
        val results = s.ms.filter { it.played && !it.isBye && it.aId != null && it.bId != null }.map { m ->
            val g = s.gamesOf(m.id)
            StandingsCalculator.Result(m.aId!!.toInt(), m.bId!!.toInt(), m.scoreA, m.scoreB, g.sumOf { it.pointsA }, g.sumOf { it.pointsB })
        }
        return StandingsCalculator.compute(s.ps.map { it.id.toInt() }, results, s.st.winPoints, s.st.drawPoints, s.st.losePoints)
    }

    /** compact = the table of the mockup; otherwise the wide statistics table. */
    private fun standingsTable(s: State, compact: Boolean): Pair<List<String>, List<List<String>>> {
        val rows = standings(s)
        val f = { x: Int -> Ui.fa(x) }
        val nm = { r: StandingsCalculator.Row -> s.name(r.id.toLong()) }
        val pct = { r: StandingsCalculator.Row -> Ui.fa("%.0f".format(r.winRate())) + "٪" }
        return when (s.league.sport) {
            Sport.FOOTBALL ->
                if (compact) listOf("رتبه", "تیم", "بازی", "برد", "مساوی", "باخت", "امتیاز") to
                    rows.mapIndexed { i, r -> listOf(f(i + 1), nm(r), f(r.played), f(r.wins), f(r.draws), f(r.losses), f(r.points)) }
                else listOf("رتبه", "تیم", "بازی", "برد", "مساوی", "باخت", "گل زده", "گل خورده", "تفاضل", "امتیاز") to
                    rows.mapIndexed { i, r -> listOf(f(i + 1), nm(r), f(r.played), f(r.wins), f(r.draws), f(r.losses), f(r.scored), f(r.conceded), f(r.diff()), f(r.points)) }
            Sport.VOLLEYBALL ->
                if (compact) listOf("رتبه", "تیم", "بازی", "برد", "باخت", "ست گرفته", "امتیاز") to
                    rows.mapIndexed { i, r -> listOf(f(i + 1), nm(r), f(r.played), f(r.wins), f(r.losses), f(r.scored), f(r.points)) }
                else listOf("رتبه", "تیم", "بازی", "برد", "باخت", "ست برده", "ست باخته", "امتیاز کسب‌شده", "امتیاز واگذارشده", "درصد برد") to
                    rows.mapIndexed { i, r -> listOf(f(i + 1), nm(r), f(r.played), f(r.wins), f(r.losses), f(r.scored), f(r.conceded), f(r.ptsFor), f(r.ptsAgainst), pct(r)) }
            else ->
                if (compact) listOf("رتبه", "بازیکن", "بازی", "برد", "باخت", "گیم گرفته", "امتیاز") to
                    rows.mapIndexed { i, r -> listOf(f(i + 1), nm(r), f(r.played), f(r.wins), f(r.losses), f(r.scored), f(r.points)) }
                else listOf("رتبه", "بازیکن", "مسابقه", "برد", "باخت", "گیم برده", "گیم باخته", "درصد برد") to
                    rows.mapIndexed { i, r -> listOf(f(i + 1), nm(r), f(r.played), f(r.wins), f(r.losses), f(r.scored), f(r.conceded), pct(r)) }
        }
    }

    private fun tableView(t: Pair<List<String>, List<List<String>>>): View {
        val tl = TableLayout(this).apply { layoutDirection = View.LAYOUT_DIRECTION_RTL; isStretchAllColumns = true }
        fun cell(text: String, header: Boolean, name: Boolean) = Ui.tv(this, text, if (header) 12f else 13f, header,
            if (header) Ui.sub(this) else Ui.ink(this)).apply {
            setPadding(dp(8), dp(12), dp(8), dp(12)); gravity = if (name) Gravity.START or Gravity.CENTER_VERTICAL else Gravity.CENTER
            if (name) minWidth = dp(76)
        }
        val hr = TableRow(this).apply { setBackgroundColor(Ui.soft(this@LeagueActivity)) }
        t.first.forEachIndexed { i, h -> hr.addView(cell(h, true, i == 1)) }
        tl.addView(hr)
        t.second.forEachIndexed { ri, r ->
            val tr = TableRow(this).apply { gravity = Gravity.CENTER_VERTICAL }
            r.forEachIndexed { i, v ->
                if (i == 0 && ri < 3 && Ui.rankColor(ri + 1) != null)
                    tr.addView(FrameLayout(this).apply { addView(Ui.badge(this@LeagueActivity, v, Ui.rankColor(ri + 1)!!, 26, Color.WHITE, 12f), FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER)) })
                else tr.addView(cell(v, false, i == 1))
            }
            tl.addView(tr)
            tl.addView(View(this).apply { setBackgroundColor(Ui.line(this@LeagueActivity)) }, TableLayout.LayoutParams(Ui.MATCH, 1))
        }
        return HorizontalScrollView(this).apply {
            isFillViewport = true; addView(tl)
            background = Ui.glass(this@LeagueActivity, dp(16))
        }
    }

    private fun renderTable(s: State) {
        body.addView(tableView(standingsTable(s, true)))
        Widgets.rulesCard(this, s.league.sport, s.st)?.let { body.addView(it) }
        body.addView(View(this), Ui.lp(Ui.MATCH, dp(72)))
    }

    // ---------- bracket ----------
    private fun renderBracket(s: State) {
        val rounds = (s.ms.maxOfOrNull { it.round } ?: -1) + 1
        val slotH = dp(112); val n0 = s.ms.count { it.round == 0 }
        val h = n0 * slotH
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(dp(4), dp(4), dp(4), dp(4)) }
        for (r in 0 until rounds) {
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.addView(Ui.tv(this, Labels.roundTitle(s.league.format, r, rounds), 14f, true, Prefs.primary(this)).apply { gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(8)) }, Ui.lp())
            val list = s.ms.filter { it.round == r }
            val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            list.forEach { m ->
                val fr = FrameLayout(this)
                fr.addView(bracketCard(s, m), FrameLayout.LayoutParams(dp(164), Ui.WRAP, Gravity.CENTER))
                wrap.addView(fr, Ui.lp(Ui.WRAP, h / list.size))
            }
            col.addView(wrap)
            row.addView(col, Ui.lp(Ui.WRAP, Ui.WRAP, 0f, this, 0, 0, 10, 0))
        }
        val finalMatch = s.ms.firstOrNull { it.round == rounds - 1 }
        val champ = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        champ.addView(Ui.tv(this, "قهرمان", 14f, true, Prefs.primary(this)).apply { setPadding(0, 0, 0, dp(8)) })
        val fr = FrameLayout(this)
        val box = Ui.card(this).apply { gravity = Gravity.CENTER_HORIZONTAL }
        box.addView(Ui.tv(this, "🏆", 30f).apply { gravity = Gravity.CENTER })
        box.addView(Ui.tv(this, if (finalMatch?.played == true) s.name(finalMatch.winnerId) else "مشخص نشده", 15f, true).apply { gravity = Gravity.CENTER })
        fr.addView(box, FrameLayout.LayoutParams(dp(140), Ui.WRAP, Gravity.CENTER))
        champ.addView(fr, Ui.lp(Ui.WRAP, h))
        row.addView(champ)
        body.addView(HorizontalScrollView(this).apply { addView(row) })
        body.addView(Ui.tv(this, "برای ثبت یا ویرایش نتیجه، روی مسابقه بزنید.", 12f, false, Ui.sub(this)), Ui.lp(c = this, t = 8))
        body.addView(View(this), Ui.lp(Ui.MATCH, dp(72)))
    }

    private fun bracketCard(s: State, m: MatchEntity): View {
        val card = Ui.card(this).apply { setPadding(dp(10), dp(8), dp(10), dp(8)) }
        fun line(id: Long?, score: Int, win: Boolean): View {
            val l = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            l.addView(Ui.tv(this, if (id == null) (if (m.isBye) "استراحت" else "؟") else s.name(id), 13f, win, if (id == null) Ui.sub(this) else Ui.ink(this)).apply { maxLines = 1 }, Ui.lp(0, Ui.WRAP, 1f))
            if (m.played && !m.isBye) l.addView(Ui.tv(this, Ui.fa(score), 13f, true, Prefs.primary(this)))
            return l
        }
        card.addView(line(m.aId, m.scoreA, m.played && m.winnerId == m.aId))
        card.addView(View(this).apply { setBackgroundColor(Ui.line(this@LeagueActivity)) }, Ui.lp(Ui.MATCH, 1, 0f, this, 0, 4, 0, 4))
        card.addView(line(m.bId, m.scoreB, m.played && m.winnerId == m.bId))
        if (!m.isBye && m.aId != null && m.bId != null) {
            card.isClickable = true; card.isFocusable = true
            card.setOnClickListener { openResult(m) }
        }
        return card
    }

    // ---------- participants (from the ⋮ menu) ----------
    private fun renderParticipants(s: State) {
        val noun = Labels.noun(s.league.sport)
        val g = gen
        lifecycleScope.launch {
            val editable = repo.canEditStructure(leagueId)
            if (g != gen) return@launch
            s.ps.forEachIndexed { i, p ->
                val card = Ui.card(this@LeagueActivity).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    isClickable = true; isFocusable = true; contentDescription = p.name
                    setOnClickListener { startActivity(Intent(this@LeagueActivity, TeamActivity::class.java).putExtra(TeamActivity.EXTRA_ID, p.id)) }
                }
                card.addView(Ui.avatar(this@LeagueActivity, p.logoPath, p.name, 36))
                card.addView(Ui.tv(this@LeagueActivity, "${Ui.fa(i + 1)}. ${p.name}", 15f, true).apply { setPadding(dp(10), 0, 0, 0) }, Ui.lp(0, Ui.WRAP, 1f))
                card.addView(Ui.tv(this@LeagueActivity, "✏", 20f).apply {
                    contentDescription = "ویرایش نام"; gravity = Gravity.CENTER; minWidth = dp(48); minHeight = dp(48)
                    setOnClickListener { Ui.prompt(this@LeagueActivity, "ویرایش نام", p.name) { n ->
                        lifecycleScope.launch { repo.renameParticipant(p, n)?.let { Ui.toast(this@LeagueActivity, it) } } } }
                })
                if (editable) card.addView(Ui.tv(this@LeagueActivity, "🗑", 20f).apply {
                    contentDescription = "حذف"; gravity = Gravity.CENTER; minWidth = dp(48); minHeight = dp(48)
                    setOnClickListener { Ui.confirm(this@LeagueActivity, "حذف $noun", "برنامه‌ی مسابقات دوباره ساخته می‌شود.", "حذف") {
                        lifecycleScope.launch { repo.removeParticipant(p)?.let { Ui.toast(this@LeagueActivity, it) } } } }
                })
                body.addView(card)
            }
            if (editable) body.addView(Ui.button(this@LeagueActivity, "افزودن $noun") {
                Ui.prompt(this@LeagueActivity, "نام $noun جدید", "") { n ->
                    lifecycleScope.launch { repo.addParticipant(leagueId, n)?.let { Ui.toast(this@LeagueActivity, it) } } }
            }, Ui.lp(c = this@LeagueActivity, t = 4))
            else body.addView(Ui.tv(this@LeagueActivity, "پس از ثبت نتیجه، فقط ویرایش نام ممکن است (افزودن/حذف، برنامه را بر هم می‌زند).", 12f, false, Ui.sub(this@LeagueActivity)))
        }
    }

    // ---------- change history (from the ⋮ menu) ----------
    private fun renderHistory(s: State) {
        val g = gen
        lifecycleScope.launch {
            val logs = repo.dao.getLogs(leagueId)
            if (g != gen) return@launch
            body.addView(Ui.tv(this@LeagueActivity, "تاریخچه‌ی تغییرات", 17f, true), Ui.lp(c = this@LeagueActivity, b = 8))
            if (logs.isEmpty()) {
                body.addView(Ui.tv(this@LeagueActivity, "هنوز تغییری ثبت نشده است.", 13f, false, Ui.sub(this@LeagueActivity)))
                return@launch
            }
            logs.forEach { l ->
                val c = Ui.card(this@LeagueActivity)
                c.addView(Ui.tv(this@LeagueActivity, Jalali.stamp(l.at), 11f, false, Ui.sub(this@LeagueActivity)))
                c.addView(Ui.tv(this@LeagueActivity, l.text, 14f).apply { setPadding(0, dp(3), 0, 0) })
                body.addView(c)
            }
        }
    }

    // ---------- stats ----------
    private fun renderStats(s: State) {
        val real = s.ms.filter { !it.isBye && it.status != MatchStatus.CANCELLED }
        val done = real.count { it.played }
        val sum = Ui.card(this)
        sum.addView(Ui.tv(this, "خلاصه‌ی لیگ", 16f, true))
        sum.addView(Ui.tv(this, "کل مسابقات: ${Ui.fa(real.size)}  •  انجام‌شده: ${Ui.fa(done)}  •  باقی‌مانده: ${Ui.fa(real.size - done)}", 13f, false, Ui.sub(this)).apply { setPadding(0, dp(4), 0, 0) })
        val rows = standings(s).filter { it.played > 0 }
        if (s.league.sport == Sport.FOOTBALL && rows.isNotEmpty()) {
            val atk = rows.maxByOrNull { it.scored }!!; val def = rows.minByOrNull { it.conceded }!!
            sum.addView(Ui.tv(this, "بهترین خط حمله: ${s.name(atk.id.toLong())} (${Ui.fa(atk.scored)} گل)", 13f).apply { setPadding(0, dp(6), 0, 0) })
            sum.addView(Ui.tv(this, "بهترین خط دفاع: ${s.name(def.id.toLong())} (${Ui.fa(def.conceded)} گل خورده)", 13f))
            val yc = s.ms.sumOf { it.yellowA + it.yellowB }; val rc = s.ms.sumOf { it.redA + it.redB }
            sum.addView(Ui.tv(this, "کارت زرد: ${Ui.fa(yc)}  •  کارت قرمز: ${Ui.fa(rc)}", 13f).apply { setPadding(0, dp(4), 0, 0) })
            sum.addView(Ui.tv(this, "گل‌زنان ثبت نمی‌شوند؛ بنابراین آمار گل‌زنان نمایش داده نمی‌شود.", 12f, false, Ui.sub(this)).apply { setPadding(0, dp(6), 0, 0) })
        }
        if (rows.isEmpty()) sum.addView(Ui.tv(this, "هنوز نتیجه‌ای ثبت نشده است؛ آمار از نتایج واقعی محاسبه می‌شود.", 12f, false, Ui.sub(this)).apply { setPadding(0, dp(6), 0, 0) })
        body.addView(sum)
        body.addView(tableView(standingsTable(s, false)))
    }
}
