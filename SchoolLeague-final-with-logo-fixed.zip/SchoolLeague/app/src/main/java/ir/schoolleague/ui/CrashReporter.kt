package ir.schoolleague.ui

import android.app.Application
import android.content.Context
import java.io.File

/** Saves the last crash stack trace locally so it can be shown (and copied) on the next launch. No network. */
object CrashReporter {
    private fun file(c: Context) = File(c.filesDir, "last_crash.txt")

    fun install(app: Application) {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { file(app).writeText(android.util.Log.getStackTraceString(e).take(6000)) } catch (ex: Throwable) { }
            previous?.uncaughtException(t, e)
        }
    }

    fun pending(c: Context): String? = file(c).takeIf { it.exists() }?.readText()
    fun clear(c: Context) { file(c).delete() }
}
