package ir.schoolleague.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.result.contract.ActivityResultContracts
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import ir.schoolleague.data.AppDatabase
import ir.schoolleague.data.LeagueRepository

abstract class BaseActivity : AppCompatActivity() {
    val repo by lazy { LeagueRepository(AppDatabase.get(applicationContext)) }
    protected lateinit var body: LinearLayout
    protected lateinit var titleView: TextView
    protected lateinit var overlay: FrameLayout
    private lateinit var headerRow: LinearLayout
    private var imageCallback: ((Uri) -> Unit)? = null
    private val imageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) imageCallback?.invoke(uri)
    }

    /** Opens the system image picker (no storage permission needed). */
    protected fun pickImage(onPicked: (Uri) -> Unit) { imageCallback = onPicked; imageLauncher.launch("image/*") }

    protected fun dp(v: Int) = Ui.dp(this, v)

    /**
     * Blue header (LTR: back arrow on the left, title and badge on the right), optional [extraTop]
     * (tabs), scrolling body, floating overlay, and optional bottom navigation (0 home, 1 leagues, 2 stats, 3 settings).
     */
    protected fun buildScreen(title: String, back: Boolean = true, extraTop: View? = null,
                              nav: Int = -1, titleAtStart: Boolean = false): LinearLayout {
        val frame = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.appBackground(this@BaseActivity)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            background = Ui.headerBg(this@BaseActivity)
            setPadding(dp(8), dp(10), dp(12), dp(10))
        }
        if (back) headerRow.addView(Ui.tv(this, "←", 24f, true, Color.WHITE).apply {
            contentDescription = "بازگشت"; gravity = Gravity.CENTER
            minWidth = dp(48); minHeight = dp(48)
            setOnClickListener { onBackPressedDispatcher.onBackPressed() }
        })
        titleView = Ui.tv(this, title, 19f, true, Color.WHITE).apply {
            setPadding(dp(8), 0, dp(8), 0); maxLines = 1
            textAlignment = if (titleAtStart) View.TEXT_ALIGNMENT_VIEW_START else View.TEXT_ALIGNMENT_VIEW_END
        }
        headerRow.addView(titleView, Ui.lp(0, Ui.WRAP, 1f))
        frame.addView(headerRow, Ui.lp())
        if (extraTop != null) frame.addView(extraTop, Ui.lp())

        val content = FrameLayout(this)
        if (Prefs.navy(this)) { content.background = Ui.sheet(this); content.clipToOutline = true }
        val sv = ScrollView(this).apply { isFillViewport = true }
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(24)) }
        sv.addView(body, FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        content.addView(sv, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        overlay = FrameLayout(this)
        content.addView(overlay, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        frame.addView(content, Ui.lp(Ui.MATCH, 0, 1f))
        if (nav >= 0) frame.addView(buildNav(nav), Ui.lp())
        setContentView(frame)
        window.statusBarColor = if (Prefs.navy(this)) 0xFF050E24.toInt() else Prefs.primary(this)
        return body
    }

    /** Action placed before the title (left side of the header). */
    protected fun addHeaderAction(label: String, desc: String, onClick: (View) -> Unit) {
        val v = Ui.tv(this, label, 22f, true, Color.WHITE).apply {
            contentDescription = desc; gravity = Gravity.CENTER
            minWidth = dp(48); minHeight = dp(48)
            setOnClickListener { onClick(it) }
        }
        headerRow.addView(v, headerRow.indexOfChild(titleView))
    }

    /** Round sport icon at the far right of the header. */
    protected fun setHeaderBadge(emoji: String) {
        headerRow.addView(Ui.badge(this, emoji, 0x33FFFFFF, 40, Color.WHITE, 20f))
    }

    protected fun addFab(onClick: () -> Unit) {
        val fab = Ui.badge(this, "+", Prefs.primary(this), 56, Color.WHITE, 28f).apply {
            contentDescription = "ثبت نتیجه‌ی جدید"; elevation = dp(6).toFloat()
            isClickable = true; isFocusable = true
            setOnClickListener { onClick() }
        }
        overlay.addView(fab, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.BOTTOM or Gravity.START).apply {
            setMargins(dp(20), 0, dp(20), dp(20))
        })
    }

    private fun buildNav(sel: Int): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = Ui.glass(this@BaseActivity, 0)
            elevation = if (Prefs.glass(this@BaseActivity)) 0f else dp(8).toFloat()
            setPadding(0, dp(6), 0, dp(6))
        }
        listOf("🏠" to "خانه", "🏆" to "لیگ‌ها", "📅" to "تقویم", "👥" to "تیم‌ها", "⋯" to "بیشتر").forEachIndexed { i, (icon, label) ->
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; minimumHeight = dp(52)
                isClickable = true; isFocusable = true; contentDescription = label
                setOnClickListener { goTo(i, sel) }
            }
            col.addView(Ui.tv(this, icon, 20f).apply { gravity = Gravity.CENTER; alpha = if (i == sel) 1f else 0.55f })
            col.addView(Ui.tv(this, label, 11f, i == sel, if (i == sel) Prefs.primary(this) else Ui.sub(this)).apply { gravity = Gravity.CENTER })
            bar.addView(col, Ui.lp(0, Ui.WRAP, 1f))
        }
        return bar
    }

    private fun goTo(i: Int, sel: Int) {
        if (i == sel) return
        val cls = when (i) {
            0 -> MainActivity::class.java
            1 -> LeagueListActivity::class.java
            2 -> CalendarActivity::class.java
            3 -> TeamsActivity::class.java
            else -> MoreActivity::class.java
        }
        val it = Intent(this, cls)
        if (i == 0) it.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        startActivity(it)
        if (this !is MainActivity && i != 0) finish()
    }
}
