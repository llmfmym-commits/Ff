package ir.schoolleague.ui

import android.app.TimePickerDialog
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import ir.schoolleague.data.*
import kotlinx.coroutines.launch

/** "ثبت نتیجه" screen: scoreboard card + match details (football) or set details (volleyball / ping-pong). */
class MatchActivity : BaseActivity() {
    companion object { const val EXTRA_ID = "matchId" }

    private val colorA = 0xFFE53935.toInt()
    private val colorB = 0xFF1E63D6.toInt()
    private lateinit var scoreTv: TextView
    private lateinit var statusTv: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val r = buildScreen("ثبت نتیجه")
        val mid = intent.getLongExtra(EXTRA_ID, -1)
        lifecycleScope.launch {
            val m = repo.dao.getMatch(mid) ?: run { finish(); return@launch }
            val league = repo.dao.getLeague(m.leagueId) ?: run { finish(); return@launch }
            val ps = repo.dao.getParticipants(m.leagueId)
            val st = repo.dao.getSettings(m.leagueId) ?: LeagueRepository.defaultSettings(m.leagueId, league.sport)
            val games = repo.dao.getGames(mid).sortedBy { it.gameNo }
            titleView.text = "ثبت نتیجه - ${Labels.sport(league.sport)}"
            val nameA = ps.firstOrNull { it.id == m.aId }?.name ?: "؟"
            val nameB = ps.firstOrNull { it.id == m.bId }?.name ?: "؟"
            scoreboard(r, nameA, nameB)
            scheduleCard(r, m)
            if (league.sport == Sport.FOOTBALL) footballForm(r, m, league, nameA, nameB)
            else setForm(r, m, league, st, nameA, nameB, games)
            historyCard(r, m)
        }
    }

    private fun teamCol(name: String, color: Int): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        col.addView(Ui.badge(this, name.trim().take(1), color, 56, Color.WHITE, 22f))
        col.addView(Ui.tv(this, name, 13f, true).apply { gravity = Gravity.CENTER; maxLines = 2; setPadding(0, dp(6), 0, 0) })
        return col
    }

    private fun scoreboard(r: LinearLayout, nameA: String, nameB: String) {
        val card = Ui.card(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        card.addView(teamCol(nameA, colorA), Ui.lp(0, Ui.WRAP, 1f))
        val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        scoreTv = Ui.tv(this, "۰ - ۰", 34f, true, Prefs.primary(this)).apply { gravity = Gravity.CENTER }
        statusTv = Ui.tv(this, "", 12f, false, Ui.sub(this)).apply { gravity = Gravity.CENTER }
        mid.addView(scoreTv); mid.addView(statusTv)
        card.addView(mid, Ui.lp(0, Ui.WRAP, 1.3f))
        card.addView(teamCol(nameB, colorB), Ui.lp(0, Ui.WRAP, 1f))
        r.addView(card)
    }

    private fun setScore(a: Int, b: Int) { scoreTv.text = "${Ui.fa(a)} - ${Ui.fa(b)}" }

    private fun title(r: LinearLayout, t: String) =
        r.addView(Ui.tv(this, t, 18f, true).apply { setPadding(dp(2), dp(6), dp(2), dp(8)) })

    private fun guard(m: MatchEntity, action: () -> Unit) {
        lifecycleScope.launch {
            if (m.played && repo.hasDependentResults(m.id))
                Ui.confirm(this@MatchActivity, "تغییر نتیجه", "نتیجه‌ی مرحله‌ی بعد به این مسابقه وابسته است. اگر برنده تغییر کند یا نتیجه حذف شود، نتایج وابسته پاک می‌شوند. ادامه می‌دهید؟", "ادامه") { action() }
            else action()
        }
    }

    private fun deleteButton(r: LinearLayout, m: MatchEntity) {
        if (!m.played) return
        r.addView(Ui.button(this, "حذف نتیجه", false) {
            guard(m) {
                Ui.confirm(this, "حذف نتیجه", "نتیجه‌ی این مسابقه حذف می‌شود و جدول و آمار دوباره محاسبه می‌شود.", "حذف") {
                    lifecycleScope.launch { repo.deleteResult(m.id); finish() }
                }
            }
        }, Ui.lp(c = this, t = 8))
    }

    private fun watcher(f: () -> Unit) = object : TextWatcher {
        override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}
        override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}
        override fun afterTextChanged(p0: Editable?) { f() }
    }

    private fun numEdit(v: Int?): EditText = Ui.edit(this, "۰", true, v?.toString() ?: "").apply { gravity = Gravity.CENTER }

    // ---------- schedule, status, history ----------
    private fun scheduleCard(r: LinearLayout, m: MatchEntity) {
        if (m.isBye) return
        title(r, "برنامه‌ی مسابقه")
        val card = Ui.card(this)
        r.addView(card)
        var date = m.planDate; var time = m.planTime; var venue = m.venue; var status = m.status
        fun row(icon: String, label: String, initial: String, onClick: (TextView) -> Unit): TextView {
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; minimumHeight = dp(48)
                isClickable = true; isFocusable = true; contentDescription = label
            }
            line.addView(Ui.tv(this, "$icon $label", 14f, false, Ui.sub(this)), Ui.lp(0, Ui.WRAP, 1f))
            val v = Ui.tv(this, Ui.fa(initial), 15f, true, Prefs.primary(this))
            line.addView(v)
            line.setOnClickListener { onClick(v) }
            card.addView(line)
            return v
        }
        row("📅", "تاریخ", date ?: "تعیین نشده") { v ->
            Ui.prompt(this, "تاریخ مسابقه", date ?: Jalali.today()) { n -> if (n.isNotBlank()) { date = n.trim(); v.text = Ui.fa(n.trim()) } }
        }
        row("⏰", "ساعت", time ?: "تعیین نشده") { v ->
            TimePickerDialog(this, { _, h, mi -> val t = "%02d:%02d".format(h, mi); time = t; v.text = Ui.fa(t) }, 16, 0, true).show()
        }
        row("📍", "سالن / زمین", venue ?: "تعیین نشده") { v ->
            Ui.prompt(this, "سالن یا زمین", venue ?: "") { n -> venue = n.trim().ifEmpty { null }; v.text = Ui.fa(venue ?: "تعیین نشده") }
        }
        val options = listOf(MatchStatus.SCHEDULED, MatchStatus.LIVE, MatchStatus.POSTPONED, MatchStatus.CANCELLED)
        row("🚦", "وضعیت", MatchStatus.label(status)) { v ->
            if (m.played) { Ui.toast(this, "برای تغییر وضعیت، ابتدا نتیجه را حذف کنید."); return@row }
            MaterialAlertDialogBuilder(this).setTitle("وضعیت مسابقه")
                .setItems(options.map { MatchStatus.label(it) }.toTypedArray()) { _, i -> status = options[i]; v.text = MatchStatus.label(status) }.show()
        }
        card.addView(Ui.button(this, "ذخیره‌ی برنامه", false) {
            lifecycleScope.launch {
                var e = repo.saveSchedule(m.id, date, time, venue)
                if (e == null && !m.played && status != m.status) e = repo.setMatchStatus(m.id, status)
                Ui.toast(this@MatchActivity, e ?: "برنامه ذخیره شد.")
            }
        }, Ui.lp(c = this, t = 8))
    }

    private fun historyCard(r: LinearLayout, m: MatchEntity) {
        lifecycleScope.launch {
            val logs = repo.dao.getLogsOfMatch(m.id)
            if (logs.isEmpty()) return@launch
            title(r, "تاریخچه‌ی تغییرات")
            val card = Ui.card(this@MatchActivity)
            r.addView(card)
            logs.forEach { l ->
                card.addView(Ui.tv(this@MatchActivity, Jalali.stamp(l.at), 11f, false, Ui.sub(this@MatchActivity)).apply { setPadding(0, dp(8), 0, 0) })
                card.addView(Ui.tv(this@MatchActivity, l.text, 13f))
            }
        }
    }

    // ---------- football ----------
    private fun footballForm(r: LinearLayout, m: MatchEntity, league: League, nameA: String, nameB: String) {
        val knock = league.format == Format.KNOCKOUT
        title(r, "جزئیات مسابقه")
        val card = Ui.card(this)
        r.addView(card)

        // date
        var date = m.dateText ?: m.planDate ?: Jalali.today()
        val dateTv = Ui.tv(this, date, 15f, true, Prefs.primary(this))
        val dateRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; minimumHeight = dp(48)
            isClickable = true; isFocusable = true; contentDescription = "تاریخ مسابقه"
            setOnClickListener { Ui.prompt(this@MatchActivity, "تاریخ مسابقه", date) { n -> if (n.isNotBlank()) { date = n.trim(); dateTv.text = date } } }
        }
        dateRow.addView(Ui.tv(this, "تاریخ مسابقه", 14f, false, Ui.sub(this)), Ui.lp(0, Ui.WRAP, 1f))
        dateRow.addView(dateTv); dateRow.addView(Ui.tv(this, "  📅", 18f))
        card.addView(dateRow)

        fun header() = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(10), 0, dp(4))
            addView(View(this@MatchActivity), Ui.lp(dp(88), 1))
            addView(Ui.tv(this@MatchActivity, nameA, 12f, true, colorA).apply { gravity = Gravity.CENTER; maxLines = 1 }, Ui.lp(0, Ui.WRAP, 1f))
            addView(Ui.tv(this@MatchActivity, nameB, 12f, true, colorB).apply { gravity = Gravity.CENTER; maxLines = 1 }, Ui.lp(0, Ui.WRAP, 1f))
        }
        card.addView(header())
        fun pair(label: String, a: Int?, b: Int?): Pair<EditText, EditText> {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            row.addView(Ui.tv(this, label, 14f, true), Ui.lp(dp(88), Ui.WRAP))
            val ea = numEdit(a); val eb = numEdit(b)
            row.addView(ea, Ui.lp(0, Ui.WRAP, 1f, this, 3, 3, 3, 3)); row.addView(eb, Ui.lp(0, Ui.WRAP, 1f, this, 3, 3, 3, 3))
            card.addView(row)
            return ea to eb
        }
        val goals = pair("گل", if (m.played) m.scoreA else null, if (m.played) m.scoreB else null)
        val yellow = pair("🟨 کارت زرد", m.yellowA, m.yellowB)
        val red = pair("🟥 کارت قرمز", m.redA, m.redB)

        val extra = CheckBox(this).apply { text = "وقت اضافه بازی شد"; isChecked = m.extraTime; setTextColor(Ui.ink(this@MatchActivity)); visibility = View.GONE }
        val penBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        penBox.addView(Ui.tv(this, "ضربات پنالتی", 13f, true, Ui.sub(this)))
        val pRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val pa = Ui.edit(this, nameA, true, m.penA?.toString() ?: "").apply { gravity = Gravity.CENTER }
        val pb = Ui.edit(this, nameB, true, m.penB?.toString() ?: "").apply { gravity = Gravity.CENTER }
        pRow.addView(pa, Ui.lp(0, Ui.WRAP, 1f, this, 2, 2, 2, 2)); pRow.addView(pb, Ui.lp(0, Ui.WRAP, 1f, this, 2, 2, 2, 2))
        penBox.addView(pRow)
        card.addView(extra); card.addView(penBox)

        val err = Ui.tv(this, "", 13f, false, Ui.ERROR)
        r.addView(err)
        fun update() {
            val a = Ui.parseInt(goals.first.text.toString()); val b = Ui.parseInt(goals.second.text.toString())
            setScore(a ?: 0, b ?: 0)
            statusTv.text = if (m.played) "نتیجه ثبت شده" else "در حال ثبت"
            val draw = knock && a != null && b != null && a == b
            extra.visibility = if (draw) View.VISIBLE else View.GONE
            penBox.visibility = if (draw) View.VISIBLE else View.GONE
        }
        goals.first.addTextChangedListener(watcher { update() }); goals.second.addTextChangedListener(watcher { update() })
        update()

        r.addView(Ui.button(this, "ثبت نتیجه") {
            val a = Ui.parseInt(goals.first.text.toString()); val b = Ui.parseInt(goals.second.text.toString())
            if (a == null || b == null) { err.text = "تعداد گل هر دو تیم را وارد کنید."; return@button }
            fun cnt(e: EditText): Int? = if (e.text.isBlank()) 0 else Ui.parseInt(e.text.toString())
            val yA = cnt(yellow.first); val yB = cnt(yellow.second); val rA = cnt(red.first); val rB = cnt(red.second)
            if (yA == null || yB == null || rA == null || rB == null) { err.text = "تعداد کارت‌ها را به‌صورت عدد وارد کنید."; return@button }
            val penA = Ui.parseInt(pa.text.toString()); val penB = Ui.parseInt(pb.text.toString())
            guard(m) {
                lifecycleScope.launch {
                    val e = repo.saveFootballResult(m.id, a, b, penA, penB, extra.isChecked && extra.visibility == View.VISIBLE, yA, yB, rA, rB, date)
                    if (e != null) err.text = e else { Ui.toast(this@MatchActivity, "نتیجه ذخیره شد."); finish() }
                }
            }
        }, Ui.lp(c = this, t = 8))
        deleteButton(r, m)
    }

    // ---------- volleyball / ping-pong ----------
    private fun setForm(r: LinearLayout, m: MatchEntity, league: League, st: LeagueSettings,
                        nameA: String, nameB: String, existing: List<GameScore>) {
        val rules = LeagueRepository.rulesFor(league.sport, st)!!
        val unit = Labels.unit(league.sport)
        title(r, "جزئیات ${unit}ها")
        val card = Ui.card(this)
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 0, 0, dp(6)) }
        head.addView(Ui.tv(this, unit, 12f, true, Ui.sub(this)), Ui.lp(dp(56), Ui.WRAP))
        head.addView(Ui.tv(this, "امتیاز $nameA", 12f, true, colorA).apply { gravity = Gravity.CENTER; maxLines = 1 }, Ui.lp(0, Ui.WRAP, 1f))
        head.addView(Ui.tv(this, "امتیاز $nameB", 12f, true, colorB).apply { gravity = Gravity.CENTER; maxLines = 1 }, Ui.lp(0, Ui.WRAP, 1f))
        card.addView(head)
        val aEts = ArrayList<EditText>(); val bEts = ArrayList<EditText>()
        for (i in 0 until rules.maxSets()) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            row.addView(Ui.tv(this, Ui.fa(i + 1), 15f, true).apply { gravity = Gravity.CENTER }, Ui.lp(dp(56), Ui.WRAP))
            val ea = numEdit(existing.getOrNull(i)?.pointsA).apply { contentDescription = "$unit ${i + 1} امتیاز اول" }
            val eb = numEdit(existing.getOrNull(i)?.pointsB).apply { contentDescription = "$unit ${i + 1} امتیاز دوم" }
            aEts.add(ea); bEts.add(eb)
            row.addView(ea, Ui.lp(0, Ui.WRAP, 1f, this, 3, 3, 3, 3)); row.addView(eb, Ui.lp(0, Ui.WRAP, 1f, this, 3, 3, 3, 3))
            card.addView(row)
        }
        r.addView(card)
        val err = Ui.tv(this, "", 13f, false, Ui.ERROR)
        r.addView(err)

        var busy = false
        fun update() {
            if (busy) return
            busy = true
            val prev = ArrayList<IntArray>(); var open = true
            for (i in aEts.indices) {
                aEts[i].isEnabled = open; bEts[i].isEnabled = open
                if (!open) { if (aEts[i].text.isNotEmpty()) aEts[i].setText(""); if (bEts[i].text.isNotEmpty()) bEts[i].setText("") }
                if (open) {
                    val a = Ui.parseInt(aEts[i].text.toString()); val b = Ui.parseInt(bEts[i].text.toString())
                    if (a != null && b != null && rules.validateSet(a, b, rules.targetFor(i)) == null) { prev.add(intArrayOf(a, b)); open = rules.isNextSetEnabled(prev) }
                    else open = false
                }
            }
            val sa = prev.count { it[0] > it[1] }; val sb = prev.count { it[1] > it[0] }
            setScore(sa, sb)
            statusTv.text = if (sa == rules.maxSets() / 2 + 1 || sb == rules.maxSets() / 2 + 1) "پایان مسابقه" else "در حال ثبت"
            busy = false
        }
        aEts.forEach { it.addTextChangedListener(watcher { update() }) }
        bEts.forEach { it.addTextChangedListener(watcher { update() }) }
        update()

        r.addView(Ui.button(this, "ثبت نتیجه") {
            val games = ArrayList<IntArray>()
            for (i in aEts.indices) {
                if (!aEts[i].isEnabled) continue
                val at = aEts[i].text.toString(); val bt = bEts[i].text.toString()
                if (at.isBlank() && bt.isBlank()) continue
                val a = Ui.parseInt(at); val b = Ui.parseInt(bt)
                if (a == null || b == null) { err.text = "امتیازها را به‌صورت عدد کامل وارد کنید."; return@button }
                games.add(intArrayOf(a, b))
            }
            guard(m) {
                lifecycleScope.launch {
                    val e = repo.saveSetResult(m.id, games)
                    if (e != null) err.text = e else { Ui.toast(this@MatchActivity, "نتیجه ذخیره شد."); finish() }
                }
            }
        }, Ui.lp(c = this, t = 8))
        deleteButton(r, m)
        Widgets.rulesCard(this, league.sport, st)?.let { r.addView(it) }
    }
}
