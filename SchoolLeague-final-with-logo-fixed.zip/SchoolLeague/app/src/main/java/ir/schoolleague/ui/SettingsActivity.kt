package ir.schoolleague.ui

import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.SeekBar
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SettingsActivity : BaseActivity() {
    private val exportLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) doExport(uri)
    }
    private val importLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) readThenConfirm(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val r = buildScreen("تنظیمات")
        val fontName = Prefs.fonts(this).firstOrNull { it.first == Prefs.fontKey(this) }?.second ?: "پیش‌فرض سیستم"
        val themeName = when (Prefs.theme(this)) { "LIGHT" -> "روشن"; "DARK" -> "تاریک"; else -> "مطابق سیستم" }
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "" } ?: ""

        val lookName = when (Prefs.look(this)) { "GLASS" -> "شیشه‌ای"; "CLASSIC" -> "ساده"; else -> "سرمه‌ای (مطابق طرح)" }
        val list = Ui.card(this).apply { setPadding(dp(4), dp(4), dp(4), dp(4)) }
        val rows = listOf(
            Triple("🔤", "انتخاب فونت", fontName) to { pickFont() },
            Triple("🌓", "تم برنامه", themeName) to { pickTheme() },
            Triple("🎨", "ظاهر برنامه", lookName) to { pickLook() },
            Triple("🏫", "اطلاعات مدرسه", Prefs.schoolName(this).ifEmpty { "نام و لوگوی مدرسه" }) to { schoolInfo() },
            Triple("🔠", "اندازه‌ی متن", "${Ui.fa((Prefs.textScale(this) * 100).toInt())}٪") to { pickTextSize() },
            Triple("🎨", "رنگ اصلی", "برای تغییر رنگ هدر و دکمه‌ها") to { pickColor() },
            Triple("💾", "پشتیبان‌گیری و بازیابی", "فایل JSON") to { pickBackup() },
            Triple("ℹ", "درباره‌ی برنامه", "نسخه ${Ui.fa(ver)}") to { about(ver) }
        )
        rows.forEachIndexed { i, (info, action) ->
            list.addView(row(info.first, info.second, info.third, action))
            if (i < rows.size - 1) list.addView(View(this).apply { setBackgroundColor(Ui.line(this@SettingsActivity)) }, Ui.lp(Ui.MATCH, 1))
        }
        r.addView(list)
        r.addView(Ui.button(this, "بازنشانی ظاهر به حالت پیش‌فرض", false) {
            Ui.confirm(this, "بازنشانی", "تم، فونت، اندازه‌ی متن و رنگ به حالت پیش‌فرض برمی‌گردند. داده‌های لیگ‌ها حفظ می‌شوند.") { Prefs.resetAll(this); recreate() }
        }, Ui.lp(c = this, t = 4, b = 10))
        r.addView(Ui.button(this, "خروج") { finishAffinity() })
    }

    private fun row(icon: String, title: String, sub: String, onClick: () -> Unit): View {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            minimumHeight = dp(64); setPadding(dp(12), dp(8), dp(12), dp(8))
            isClickable = true; isFocusable = true; contentDescription = title
            setOnClickListener { onClick() }
        }
        r.addView(Ui.badge(this, icon, Ui.line(this), 40, Ui.ink(this), 20f))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(8), 0) }
        col.addView(Ui.tv(this, title, 16f, true))
        col.addView(Ui.tv(this, sub, 12f, false, Ui.sub(this)))
        r.addView(col, Ui.lp(0, Ui.WRAP, 1f))
        r.addView(Ui.tv(this, "‹", 22f, true, Ui.sub(this)))
        return r
    }

    private fun pickFont() {
        val fonts = Prefs.fonts(this)
        MaterialAlertDialogBuilder(this).setTitle("انتخاب فونت")
            .setItems(fonts.map { it.second }.toTypedArray()) { _, i -> Prefs.setFontKey(this, fonts[i].first); recreate() }
            .show()
    }

    private fun pickTheme() {
        val keys = listOf("LIGHT", "DARK", "SYSTEM")
        MaterialAlertDialogBuilder(this).setTitle("تم برنامه")
            .setItems(arrayOf("روشن", "تاریک", "مطابق سیستم")) { _, i -> Prefs.setTheme(this, keys[i]); recreate() }
            .show()
    }

    private fun pickTextSize() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(12), dp(24), 0); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val label = Ui.tv(this, "", 16f, true)
        val sb = SeekBar(this).apply { max = 50; progress = ((Prefs.textScale(this@SettingsActivity) - 0.8f) * 100).toInt().coerceIn(0, 50); contentDescription = "اندازه‌ی متن" }
        label.text = "${Ui.fa(80 + sb.progress)}٪"
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { label.text = "${Ui.fa(80 + p)}٪" }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(label); box.addView(sb)
        MaterialAlertDialogBuilder(this).setTitle("اندازه‌ی متن").setView(box)
            .setPositiveButton("ذخیره") { _, _ -> Prefs.setTextScale(this, 0.8f + sb.progress / 100f); recreate() }
            .setNegativeButton("انصراف", null).show()
    }

    private fun pickColor() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(dp(16), dp(16), dp(16), dp(8)); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val dlg = MaterialAlertDialogBuilder(this).setTitle("رنگ اصلی").setView(box).setNegativeButton("بستن", null).create()
        listOf(0xFF0B4DB5, 0xFF16A34A, 0xFF7C3AED, 0xFFEA580C, 0xFFE11D48, 0xFF0D9488).forEach { cl ->
            val col = cl.toInt()
            box.addView(View(this).apply {
                background = Ui.rounded(col, dp(24), if (Prefs.primary(this@SettingsActivity) == col) Ui.ink(this@SettingsActivity) else Color.TRANSPARENT, dp(3))
                contentDescription = "رنگ"; isClickable = true
                setOnClickListener { Prefs.setPrimary(this@SettingsActivity, col); dlg.dismiss(); recreate() }
            }, Ui.lp(dp(40), dp(40), 0f, this, 4, 0, 4, 0))
        }
        dlg.show()
    }

    private fun pickLook() {
        val keys = listOf("NAVY", "GLASS", "CLASSIC")
        MaterialAlertDialogBuilder(this).setTitle("ظاهر برنامه")
            .setItems(arrayOf("سرمه‌ای (مطابق طرح)", "شیشه‌ای", "ساده")) { _, i -> Prefs.setLook(this, keys[i]); recreate() }.show()
    }

    private fun schoolInfo() {
        MaterialAlertDialogBuilder(this).setTitle("اطلاعات مدرسه")
            .setItems(arrayOf("ویرایش نام مدرسه", "انتخاب لوگوی مدرسه", "حذف لوگو")) { _, i ->
                when (i) {
                    0 -> Ui.prompt(this, "نام مدرسه", Prefs.schoolName(this)) { n -> Prefs.setSchoolName(this, n); recreate() }
                    1 -> pickImage { uri ->
                        lifecycleScope.launch {
                            val p = withContext(Dispatchers.IO) { Images.save(this@SettingsActivity, uri, "school") }
                            if (p != null) { Prefs.setSchoolLogo(this@SettingsActivity, p); recreate() }
                            else Ui.toast(this@SettingsActivity, "خواندن تصویر ناموفق بود.")
                        }
                    }
                    else -> { Prefs.setSchoolLogo(this, null); recreate() }
                }
            }.show()
    }

    private fun pickBackup() {
        MaterialAlertDialogBuilder(this).setTitle("پشتیبان‌گیری و بازیابی")
            .setItems(arrayOf("ساخت نسخه‌ی پشتیبان", "بازیابی از نسخه‌ی پشتیبان")) { _, i ->
                if (i == 0) exportLauncher.launch("school-league-backup.json")
                else importLauncher.launch(arrayOf("application/json", "text/plain", "*/*"))
            }.show()
    }

    private fun about(ver: String) {
        MaterialAlertDialogBuilder(this).setTitle("SchoolLeague")
            .setMessage("مدیریت لیگ‌های ورزشی مدرسه (پینگ‌پنگ، فوتبال، والیبال)\nنسخه ${Ui.fa(ver)}\nهمه‌ی اطلاعات روی همین دستگاه ذخیره می‌شود.")
            .setPositiveButton("باشه", null).show()
    }

    private fun doExport(uri: Uri) {
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val text = repo.exportJson()
                    contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) } ?: throw IllegalStateException()
                }
                Ui.toast(this@SettingsActivity, "نسخه‌ی پشتیبان با موفقیت ذخیره شد.")
            } catch (e: Exception) { Ui.toast(this@SettingsActivity, "ذخیره‌ی پشتیبان ناموفق بود.") }
        }
    }

    private fun readThenConfirm(uri: Uri) {
        lifecycleScope.launch {
            val text = try {
                withContext(Dispatchers.IO) { contentResolver.openInputStream(uri)?.use { String(it.readBytes(), Charsets.UTF_8) } }
            } catch (e: Exception) { null }
            if (text == null) { Ui.toast(this@SettingsActivity, "خواندن فایل ناموفق بود."); return@launch }
            Ui.confirm(this@SettingsActivity, "بازیابی اطلاعات", "همه‌ی لیگ‌های فعلی با اطلاعات فایل پشتیبان جایگزین می‌شوند. ادامه می‌دهید؟", "بازیابی") {
                lifecycleScope.launch {
                    try { repo.importJson(text); Ui.toast(this@SettingsActivity, "اطلاعات با موفقیت بازیابی شد.") }
                    catch (e: IllegalArgumentException) { Ui.toast(this@SettingsActivity, e.message ?: "فایل نامعتبر است.") }
                    catch (e: Exception) { Ui.toast(this@SettingsActivity, "بازیابی ناموفق بود؛ اطلاعات قبلی تغییر نکرد.") }
                }
            }
        }
    }
}
