package ir.schoolleague.ui

import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import ir.schoolleague.R

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c = this
        val root = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFF050E24.toInt(), 0xFF0B2A5B.toInt()))
            setPadding(Ui.dp(c, 32), Ui.dp(c, 32), Ui.dp(c, 32), Ui.dp(c, 40))
        }
        root.addView(View(c), Ui.lp(Ui.MATCH, 0, 1f))
        root.addView(ImageView(c).apply {
            setImageResource(R.drawable.logo)
            contentDescription = "SchoolLeague"
            adjustViewBounds = true
        }, Ui.lp(Ui.dp(c, 260), Ui.dp(c, 260)).apply { gravity = Gravity.CENTER_HORIZONTAL })
        root.addView(View(c), Ui.lp(Ui.MATCH, 0, 1f))
        root.addView(Ui.button(c, "شروع") {
            startActivity(Intent(c, MainActivity::class.java)); finish()
        }, Ui.lp())
        setContentView(root)
        window.statusBarColor = 0xFF050E24.toInt()
    }
}
