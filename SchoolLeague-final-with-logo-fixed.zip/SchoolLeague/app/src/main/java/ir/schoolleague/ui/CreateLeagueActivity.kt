package ir.schoolleague.ui

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioGroup
import androidx.appcompat.widget.AppCompatRadioButton
import androidx.appcompat.widget.SwitchCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import ir.schoolleague.data.Format
import ir.schoolleague.data.LeagueRepository
import ir.schoolleague.data.LeagueSettings
import ir.schoolleague.data.Sport
import kotlinx.coroutines.launch

/** Single-page "ساخت لیگ جدید" form (matches the supplied mockup). */
class CreateLeagueActivity : BaseActivity() {
    companion object { const val EXTRA_SPORT = "sport" }

    private var sport = Sport.FOOTBALL
    private var format = Format.KNOCKOUT
    private var leagueName = ""
    private val names = mutableListOf<String>()
    private var st: LeagueSettings = LeagueRepository.defaultSettings(0, Sport.FOOTBALL)
    private var shuffle = false
    private var showAdvanced = false
    private val fields = mutableListOf<EditText>()
    private var nameEt: EditText? = null
    private var winEt: EditText? = null
    private var drawEt: EditText? = null
    private var loseEt: EditText? = null
    private var gameEt: EditText? = null
    private var decEt: EditText? = null
    private var dbl: SwitchCompat? = null
    private var shuf: SwitchCompat? = null
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = buildScreen("ساخت لیگ جدید")
        intent.getStringExtra(EXTRA_SPORT)?.let { sport = it }
        st = LeagueRepository.defaultSettings(0, sport)
        for (i in 0 until 8) names.add(defaultName(i))
        render()
    }

    private fun defaultName(i: Int) = "${Labels.noun(sport)} ${Ui.fa(i + 1)}"

    private fun collectAll() {
        nameEt?.let { leagueName = it.text.toString() }
        if (fields.isNotEmpty()) { names.clear(); names.addAll(fields.map { it.text.toString() }) }
        if (winEt != null) {
            st = st.copy(
                winPoints = Ui.parseInt(winEt!!.text.toString()) ?: -1,
                drawPoints = Ui.parseInt(drawEt?.text?.toString() ?: st.drawPoints.toString()) ?: -1,
                losePoints = Ui.parseInt(loseEt!!.text.toString()) ?: -1,
                gamePoints = Ui.parseInt(gameEt?.text?.toString() ?: st.gamePoints.toString()) ?: -1,
                deciderPoints = Ui.parseInt(decEt?.text?.toString() ?: st.deciderPoints.toString()) ?: -1,
                doubleRound = dbl?.isChecked ?: st.doubleRound)
            shuffle = shuf?.isChecked ?: shuffle
        }
    }

    private fun setCount(n: Int) {
        collectAll()
        while (names.size < n) { var k = names.size; while (names.contains(defaultName(k))) k++; names.add(defaultName(k)) }
        while (names.size > n) names.removeAt(names.size - 1)
        render()
    }

    private fun label(t: String) = Ui.tv(this, t, 14f, true).apply { setPadding(dp(2), dp(10), dp(2), dp(6)) }

    private fun render() {
        root.removeAllViews()
        fields.clear(); winEt = null; drawEt = null; loseEt = null; gameEt = null; decEt = null; dbl = null; shuf = null
        val noun = Labels.noun(sport)

        // sport chips
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(Sport.FOOTBALL, Sport.VOLLEYBALL, Sport.PINGPONG).forEach { s ->
            val sel = s == sport
            chips.addView(Ui.tv(this, "${Labels.emoji(s)} ${Labels.sport(s)}", 14f, true, if (sel) Color.WHITE else Prefs.primary(this)).apply {
                gravity = Gravity.CENTER; minHeight = dp(44)
                background = if (sel) Ui.rounded(Prefs.primary(this@CreateLeagueActivity), dp(22))
                else Ui.rounded(Color.TRANSPARENT, dp(22), Prefs.primary(this@CreateLeagueActivity), dp(1))
                setOnClickListener {
                    if (s != sport) {
                        collectAll()
                        val wasDefault = names.withIndex().all { (i, n) -> n.trim() == defaultName(i) }
                        sport = s; st = LeagueRepository.defaultSettings(0, s)
                        if (wasDefault) { val n = names.size; names.clear(); for (i in 0 until n) names.add(defaultName(i)) }
                        render()
                    }
                }
            }, Ui.lp(0, Ui.WRAP, 1f, this, 3, 0, 3, 0))
        }
        root.addView(chips)

        root.addView(label("نام لیگ"))
        nameEt = Ui.edit(this, "مثلاً مسابقات ${Labels.sport(sport)} پایه دهم", false, leagueName)
        root.addView(nameEt)

        root.addView(label("تعداد ${noun}ها"))
        root.addView(Ui.tv(this, "${Ui.fa(names.size)} $noun  ⌄", 15f, true).apply {
            minHeight = dp(48); gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = Ui.rounded(Color.TRANSPARENT, dp(12), Ui.line(this@CreateLeagueActivity), dp(1))
            isClickable = true; isFocusable = true; contentDescription = "تعداد $noun"
            setOnClickListener {
                val opts = (2..32).map { "${Ui.fa(it)} $noun" }.toTypedArray()
                MaterialAlertDialogBuilder(this@CreateLeagueActivity).setTitle("تعداد ${noun}ها")
                    .setItems(opts) { _, i -> setCount(i + 2) }.show()
            }
        })

        root.addView(label("نوع مسابقات"))
        val rg = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        fun rb(t: String, f: String) = AppCompatRadioButton(this).apply {
            id = View.generateViewId(); text = t; isChecked = format == f
            setTextColor(Ui.ink(this@CreateLeagueActivity)); textSize = 15f
            buttonTintList = ColorStateList.valueOf(Prefs.primary(this@CreateLeagueActivity))
            setPadding(dp(6), dp(6), dp(18), dp(6))
            setOnClickListener { if (format != f) { collectAll(); format = f; render() } }
        }
        rg.addView(rb("حذفی", Format.KNOCKOUT)); rg.addView(rb("دوره‌ای", Format.ROUND_ROBIN))
        root.addView(rg)

        root.addView(label("نام ${noun}ها"))
        names.forEachIndexed { i, n ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = Ui.rounded(Ui.surface(this@CreateLeagueActivity), dp(12), Ui.line(this@CreateLeagueActivity), dp(1))
                setPadding(dp(8), 0, dp(2), 0)
            }
            val e = Ui.edit(this, "نام $noun ${Ui.fa(i + 1)}", false, n).apply { background = null; contentDescription = "نام $noun ${Ui.fa(i + 1)}" }
            fields.add(e)
            row.addView(e, Ui.lp(0, Ui.WRAP, 1f))
            row.addView(Ui.tv(this, "✕", 18f, true, Ui.sub(this)).apply {
                gravity = Gravity.CENTER; minWidth = dp(44); minHeight = dp(48); contentDescription = "حذف"
                setOnClickListener {
                    if (names.size <= 2) Ui.toast(this@CreateLeagueActivity, "حداقل دو شرکت‌کننده لازم است.")
                    else { collectAll(); names.removeAt(i); render() }
                }
            })
            row.addView(Ui.tv(this, "☰", 18f, true, Ui.sub(this)).apply {
                gravity = Gravity.CENTER; minWidth = dp(44); minHeight = dp(48); contentDescription = "جابه‌جایی به بالا"
                setOnClickListener {
                    if (i > 0) { collectAll(); val t = names[i]; names[i] = names[i - 1]; names[i - 1] = t; render() }
                }
            })
            root.addView(row, Ui.lp(c = this, b = 8))
        }

        // advanced settings
        root.addView(Ui.button(this, if (showAdvanced) "پنهان‌کردن تنظیمات پیشرفته" else "تنظیمات پیشرفته", false) {
            collectAll(); showAdvanced = !showAdvanced; render()
        }, Ui.lp(c = this, t = 6, b = 8))
        if (showAdvanced) {
            fun addField(parent: LinearLayout, lbl: String, v: Int): EditText {
                parent.addView(Ui.tv(this, lbl, 13f, false, Ui.sub(this)))
                return Ui.edit(this, "", true, v.toString()).also { parent.addView(it, Ui.lp(c = this, b = 8)) }
            }
            val adv = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            winEt = addField(adv, "امتیاز برد در جدول", st.winPoints)
            if (sport == Sport.FOOTBALL) drawEt = addField(adv, "امتیاز مساوی", st.drawPoints)
            loseEt = addField(adv, "امتیاز باخت", st.losePoints)
            if (sport != Sport.FOOTBALL) gameEt = addField(adv, if (sport == Sport.PINGPONG) "امتیاز هر گیم" else "امتیاز هر ست", st.gamePoints)
            if (sport == Sport.VOLLEYBALL) decEt = addField(adv, "امتیاز ست تعیین‌کننده (سوم)", st.deciderPoints)
            if (format == Format.ROUND_ROBIN) {
                dbl = SwitchCompat(this).apply { text = "رفت و برگشت"; isChecked = st.doubleRound; setTextColor(Ui.ink(this@CreateLeagueActivity)) }
                adv.addView(dbl, Ui.lp(c = this, b = 8))
            }
            shuf = SwitchCompat(this).apply { text = "قرعه‌کشی تصادفی ترتیب"; isChecked = shuffle; setTextColor(Ui.ink(this@CreateLeagueActivity)) }
            adv.addView(shuf, Ui.lp(c = this, b = 8))
            root.addView(adv)
        }

        val progress = ProgressBar(this).apply { visibility = View.GONE }
        root.addView(progress, Ui.lp(Ui.WRAP, Ui.WRAP).apply { gravity = Gravity.CENTER })
        val create = Ui.button(this, "ایجاد لیگ") {}
        create.setOnClickListener {
            collectAll()
            val err = validate()
            if (err != null) { Ui.toast(this, err); return@setOnClickListener }
            create.isEnabled = false; progress.visibility = View.VISIBLE
            lifecycleScope.launch {
                try {
                    val id = repo.createLeague(leagueName, sport, format, names, st, shuffle)
                    startActivity(Intent(this@CreateLeagueActivity, LeagueActivity::class.java).putExtra(LeagueActivity.EXTRA_ID, id))
                    finish()
                } catch (e: Exception) {
                    create.isEnabled = true; progress.visibility = View.GONE
                    Ui.toast(this@CreateLeagueActivity, e.message ?: "ساخت لیگ ناموفق بود.")
                }
            }
        }
        root.addView(create, Ui.lp(c = this, t = 10))
    }

    private fun validate(): String? {
        if (leagueName.isBlank()) return "نام لیگ را وارد کنید."
        val t = names.map { it.trim() }
        if (t.size < 2) return "حداقل دو شرکت‌کننده لازم است."
        if (t.any { it.isEmpty() }) return "نام هیچ شرکت‌کننده‌ای نباید خالی باشد."
        if (t.map { it.lowercase() }.toSet().size != t.size) return "نام شرکت‌کنندگان تکراری است."
        if (st.winPoints < 0 || st.drawPoints < 0 || st.losePoints < 0) return "امتیازهای جدول باید عدد صحیح و غیرمنفی باشند."
        if (sport != Sport.FOOTBALL && (st.gamePoints !in 1..99 || st.deciderPoints !in 1..99)) return "امتیاز هر گیم/ست باید بین ۱ تا ۹۹ باشد."
        return null
    }
}
