package ir.schoolleague.data

object Sport { const val PINGPONG = "PINGPONG"; const val FOOTBALL = "FOOTBALL"; const val VOLLEYBALL = "VOLLEYBALL" }
object Format { const val KNOCKOUT = "KNOCKOUT"; const val ROUND_ROBIN = "ROUND_ROBIN" }
object Status { const val ACTIVE = "ACTIVE"; const val FINISHED = "FINISHED" }

object MatchStatus {
    const val SCHEDULED = "SCHEDULED"; const val LIVE = "LIVE"; const val DONE = "DONE"
    const val POSTPONED = "POSTPONED"; const val CANCELLED = "CANCELLED"
    fun label(s: String) = when (s) {
        LIVE -> "در حال انجام"; DONE -> "انجام‌شده"; POSTPONED -> "تعویق‌شده"; CANCELLED -> "لغوشده"; else -> "برنامه‌ریزی‌شده"
    }
}
