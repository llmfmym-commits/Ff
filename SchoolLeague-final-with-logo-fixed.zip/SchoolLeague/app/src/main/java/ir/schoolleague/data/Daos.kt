package ir.schoolleague.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface LeagueDao {
    @Insert suspend fun insertLeague(l: League): Long
    @Update suspend fun updateLeague(l: League)
    @Query("DELETE FROM leagues WHERE id = :id") suspend fun deleteLeague(id: Long)
    @Query("SELECT * FROM leagues WHERE id = :id") suspend fun getLeague(id: Long): League?
    @Query("SELECT * FROM leagues WHERE id = :id") fun observeLeague(id: Long): Flow<League?>
    @Query("SELECT * FROM leagues WHERE sport = :sport ORDER BY createdAt DESC")
    fun observeBySport(sport: String): Flow<List<League>>
    @Query("SELECT * FROM leagues ORDER BY createdAt DESC") fun observeAll(): Flow<List<League>>
    @Query("SELECT COUNT(*) FROM leagues WHERE status = :status") fun countByStatus(status: String): Flow<Int>

    @Insert suspend fun insertParticipants(p: List<Participant>): List<Long>
    @Update suspend fun updateParticipant(p: Participant)
    @Query("DELETE FROM participants WHERE id = :id") suspend fun deleteParticipant(id: Long)
    @Query("SELECT * FROM participants WHERE leagueId = :lid ORDER BY seed")
    fun observeParticipants(lid: Long): Flow<List<Participant>>
    @Query("SELECT * FROM participants WHERE leagueId = :lid ORDER BY seed")
    suspend fun getParticipants(lid: Long): List<Participant>

    @Insert suspend fun insertMatches(m: List<MatchEntity>): List<Long>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertMatch(m: MatchEntity): Long
    @Query("SELECT * FROM matches WHERE leagueId = :lid ORDER BY round, indexInRound")
    fun observeMatches(lid: Long): Flow<List<MatchEntity>>
    @Query("SELECT * FROM matches WHERE leagueId = :lid ORDER BY round, indexInRound")
    suspend fun getMatches(lid: Long): List<MatchEntity>
    @Query("SELECT * FROM matches WHERE id = :id") suspend fun getMatch(id: Long): MatchEntity?
    @Update suspend fun updateMatch(m: MatchEntity)
    @Query("DELETE FROM matches WHERE leagueId = :lid") suspend fun deleteMatchesOf(lid: Long)
    @Query("SELECT COUNT(*) FROM participants WHERE leagueId = :lid") suspend fun countParticipants(lid: Long): Int

    @Insert suspend fun insertGames(g: List<GameScore>)
    @Query("DELETE FROM game_scores WHERE matchId = :mid") suspend fun deleteGames(mid: Long)
    @Query("SELECT * FROM game_scores WHERE matchId = :mid ORDER BY gameNo")
    suspend fun getGames(mid: Long): List<GameScore>
    @Query("SELECT g.* FROM game_scores g JOIN matches m ON g.matchId = m.id WHERE m.leagueId = :lid ORDER BY g.matchId, g.gameNo")
    fun observeLeagueGames(lid: Long): Flow<List<GameScore>>

    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveSettings(s: LeagueSettings)
    @Query("SELECT * FROM league_settings WHERE leagueId = :lid") suspend fun getSettings(lid: Long): LeagueSettings?


    @Query("SELECT * FROM participants WHERE id = :id") suspend fun getParticipant(id: Long): Participant?
    @Query("SELECT * FROM participants WHERE id = :id") fun observeParticipant(id: Long): Flow<Participant?>
    @Insert suspend fun insertPlayer(p: Player): Long
    @Insert suspend fun insertPlayers(p: List<Player>)
    @Update suspend fun updatePlayer(p: Player)
    @Query("DELETE FROM players WHERE id = :id") suspend fun deletePlayer(id: Long)
    @Query("UPDATE players SET isCaptain = 0 WHERE participantId = :pid") suspend fun clearCaptain(pid: Long)
    @Query("SELECT * FROM players WHERE participantId = :pid ORDER BY isCaptain DESC, number IS NULL, number, name")
    suspend fun getPlayers(pid: Long): List<Player>
    @Query("SELECT * FROM players WHERE participantId = :pid ORDER BY isCaptain DESC, number IS NULL, number, name")
    fun observePlayers(pid: Long): Flow<List<Player>>
    @Query("SELECT * FROM players") suspend fun allPlayers(): List<Player>

    @Insert suspend fun insertLog(l: ChangeLog): Long
    @Insert suspend fun insertLogs(l: List<ChangeLog>)
    @Query("SELECT * FROM change_log WHERE leagueId = :lid ORDER BY at DESC, id DESC LIMIT 200")
    suspend fun getLogs(lid: Long): List<ChangeLog>
    @Query("SELECT * FROM change_log WHERE matchId = :mid ORDER BY at DESC, id DESC LIMIT 50")
    suspend fun getLogsOfMatch(mid: Long): List<ChangeLog>
    @Query("SELECT * FROM change_log") suspend fun allLogs(): List<ChangeLog>

    @Query("SELECT * FROM leagues") suspend fun allLeagues(): List<League>
    @Query("SELECT * FROM participants") suspend fun allParticipants(): List<Participant>
    @Query("SELECT * FROM matches") suspend fun allMatches(): List<MatchEntity>
    @Query("SELECT * FROM game_scores") suspend fun allGames(): List<GameScore>
    @Query("SELECT * FROM league_settings") suspend fun allSettings(): List<LeagueSettings>
    @Query("DELETE FROM leagues") suspend fun clearAll()
}
