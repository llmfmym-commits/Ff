package ir.schoolleague.ui

import android.content.Context
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import ir.schoolleague.data.LeagueSettings
import ir.schoolleague.data.Sport

object Widgets {
    /** Light-blue "rules" card shown under tables and match details (volleyball / ping-pong). */
    fun rulesCard(c: Context, sport: String, st: LeagueSettings): View? {
        val lines: List<String>
        val title: String
        when (sport) {
            Sport.VOLLEYBALL -> {
                title = "قوانین والیبال 🏐"
                lines = listOf("۳ ست در هر مسابقه (برنده‌ی ۲ ست)",
                    "هر ست تا ${Ui.fa(st.gamePoints)} امتیاز (با اختلاف ۲ امتیاز)",
                    "ست سوم ${Ui.fa(st.deciderPoints)} امتیاز")
            }
            Sport.PINGPONG -> {
                title = "قوانین پینگ‌پنگ 🏓"
                lines = listOf("حداکثر ۳ گیم",
                    "هر گیم تا ${Ui.fa(st.gamePoints)} امتیاز (با اختلاف ۲ امتیاز)",
                    "اگر یک نفر دو گیم اول را ببرد، گیم سوم برگزار نمی‌شود.")
            }
            else -> return null
        }
        val card = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.glass(c, Ui.dp(c, 18))
            setPadding(Ui.dp(c, 14), Ui.dp(c, 12), Ui.dp(c, 14), Ui.dp(c, 12))
            layoutParams = Ui.lp(c = c, t = 12, b = 8)
        }
        card.addView(Ui.tv(c, title, 15f, true, Prefs.primary(c)).apply { gravity = Gravity.START })
        lines.forEach { card.addView(Ui.tv(c, "• $it", 13f).apply { setPadding(0, Ui.dp(c, 4), 0, 0) }) }
        return card
    }
}
