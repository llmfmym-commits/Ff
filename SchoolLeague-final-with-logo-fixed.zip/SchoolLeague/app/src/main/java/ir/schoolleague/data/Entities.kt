package ir.schoolleague.data

import androidx.room.*

@Entity(tableName = "leagues")
data class League(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val sport: String,   // PINGPONG | FOOTBALL | VOLLEYBALL
    val format: String,  // KNOCKOUT | ROUND_ROBIN
    val status: String = "ACTIVE", // ACTIVE | FINISHED
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "participants",
    foreignKeys = [ForeignKey(League::class, ["id"], ["leagueId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("leagueId")]
)
data class Participant(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val leagueId: Long,
    val name: String,
    val seed: Int,
    val coach: String? = null,
    val logoPath: String? = null
)

@Entity(
    tableName = "matches",
    foreignKeys = [ForeignKey(League::class, ["id"], ["leagueId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("leagueId")]
)
data class MatchEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val leagueId: Long,
    val round: Int,
    val indexInRound: Int,
    val aId: Long?,
    val bId: Long?,
    val played: Boolean = false,
    val winnerId: Long? = null,
    val scoreA: Int = 0,      // goals, or sets/games won
    val scoreB: Int = 0,
    val penA: Int? = null,
    val penB: Int? = null,
    val extraTime: Boolean = false,
    val isBye: Boolean = false,
    val yellowA: Int = 0,
    val yellowB: Int = 0,
    val redA: Int = 0,
    val redB: Int = 0,
    val dateText: String? = null,
    val status: String = "SCHEDULED",
    val planDate: String? = null,
    val planTime: String? = null,
    val venue: String? = null
)

@Entity(
    tableName = "game_scores",
    foreignKeys = [ForeignKey(MatchEntity::class, ["id"], ["matchId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("matchId")]
)
data class GameScore(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val matchId: Long,
    val gameNo: Int,
    val pointsA: Int,
    val pointsB: Int
)

@Entity(
    tableName = "league_settings",
    foreignKeys = [ForeignKey(League::class, ["id"], ["leagueId"], onDelete = ForeignKey.CASCADE)]
)
data class LeagueSettings(
    @PrimaryKey val leagueId: Long,
    val winPoints: Int = 3,
    val drawPoints: Int = 1,
    val losePoints: Int = 0,
    val gamePoints: Int = 11,     // ping-pong game / volleyball set target
    val deciderPoints: Int = 15,  // volleyball deciding set
    val doubleRound: Boolean = false
)

@Entity(
    tableName = "change_log",
    foreignKeys = [ForeignKey(League::class, ["id"], ["leagueId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("leagueId")]
)
data class ChangeLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val leagueId: Long,
    val matchId: Long? = null,
    val at: Long,
    val text: String
)

@Entity(
    tableName = "players",
    foreignKeys = [ForeignKey(Participant::class, ["id"], ["participantId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("participantId")]
)
data class Player(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val participantId: Long,
    val name: String,
    val number: Int? = null,
    val position: String? = null,
    val isCaptain: Boolean = false
)
