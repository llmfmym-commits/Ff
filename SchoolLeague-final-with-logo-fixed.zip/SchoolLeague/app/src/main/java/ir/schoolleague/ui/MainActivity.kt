package ir.schoolleague.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.PopupMenu
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import ir.schoolleague.data.League
import ir.schoolleague.data.MatchEntity
import ir.schoolleague.data.MatchStatus
import ir.schoolleague.data.Participant
import ir.schoolleague.data.Sport
import ir.schoolleague.data.Status
import kotlinx.coroutines.launch

/** Dashboard: school card, sport cards with league counts, today's / upcoming matches. */
class MainActivity : BaseActivity() {
    private lateinit var r: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        r = buildScreen("SchoolLeague", back = false, nav = 0, titleAtStart = true)
        addHeaderAction("☰", "منو") { anchor ->
            val pm = PopupMenu(this, anchor)
            pm.menu.add(0, 1, 0, "لیگ‌های من"); pm.menu.add(0, 2, 1, "تقویم"); pm.menu.add(0, 3, 2, "آمار کلی"); pm.menu.add(0, 4, 3, "تنظیمات")
            pm.setOnMenuItemClickListener {
                startActivity(Intent(this, when (it.itemId) {
                    1 -> LeagueListActivity::class.java; 2 -> CalendarActivity::class.java
                    3 -> StatsActivity::class.java; else -> SettingsActivity::class.java }))
                true
            }
            pm.show()
        }
        CrashReporter.pending(this)?.let { trace ->
            MaterialAlertDialogBuilder(this).setTitle("دفعه‌ی قبل برنامه ناگهان بسته شد")
                .setMessage(trace.take(1500))
                .setPositiveButton("کپی گزارش") { _, _ ->
                    (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("crash", trace))
                    CrashReporter.clear(this); Ui.toast(this, "گزارش کپی شد؛ آن را برای پشتیبان بفرستید.")
                }
                .setNegativeButton("بستن") { _, _ -> CrashReporter.clear(this) }
                .setCancelable(false).show()
        }
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                repo.dao.observeAll().collect { leagues -> render(leagues) }
            }
        }
    }

    private suspend fun render(leagues: List<League>) {
        val ps = repo.dao.allParticipants()
        val ms = repo.dao.allMatches().filter { !it.isBye }
        r.removeAllViews()
        schoolCard(leagues, ps.size, ms.size)
        r.addView(Ui.tv(this, "انتخاب ورزش", 18f, true).apply { setPadding(dp(2), dp(4), dp(2), dp(10)) })
        fun count(s: String) = leagues.count { it.sport == s }
        fun openList(s: String) = startActivity(Intent(this, LeagueListActivity::class.java).putExtra(LeagueListActivity.EXTRA_SPORT, s))
        val rows = listOf(
            listOf(Triple("⚽", "فوتبال", 0xFF1677FF.toInt()) to count(Sport.FOOTBALL),
                Triple("🏐", "والیبال", 0xFFF59E0B.toInt()) to count(Sport.VOLLEYBALL)),
            listOf(Triple("➕", "ساخت لیگ جدید", 0xFF16A34A.toInt()) to -1,
                Triple("🏓", "پینگ‌پنگ", 0xFF7C3AED.toInt()) to count(Sport.PINGPONG)))
        rows.forEach { pair ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEachIndexed { j, (info, n) ->
                val card = sportCard(info.first, info.second, if (n >= 0) "${Ui.fa(n)} لیگ" else "", info.third) {
                    when (info.second) {
                        "فوتبال" -> openList(Sport.FOOTBALL)
                        "والیبال" -> openList(Sport.VOLLEYBALL)
                        "پینگ‌پنگ" -> openList(Sport.PINGPONG)
                        else -> startActivity(Intent(this, CreateLeagueActivity::class.java))
                    }
                }
                row.addView(card, Ui.lp(0, Ui.WRAP, 1f, this, if (j == 0) 6 else 0, 0, if (j == 0) 0 else 6, 0))
            }
            r.addView(row, Ui.lp(c = this, b = 12))
        }
        todaySection(leagues, ps, ms)
    }

    private fun schoolCard(leagues: List<League>, teams: Int, matches: Int) {
        val name = Prefs.schoolName(this).ifEmpty { "مدرسه‌ی من" }
        val card = Ui.card(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            isClickable = true; isFocusable = true; contentDescription = "اطلاعات مدرسه"
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        }
        card.addView(Ui.avatar(this, Prefs.schoolLogo(this), name, 52))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        col.addView(Ui.tv(this, name, 17f, true))
        col.addView(Ui.tv(this, "${Ui.fa(leagues.count { it.status == Status.ACTIVE })} لیگ فعال • ${Ui.fa(teams)} تیم • ${Ui.fa(matches)} مسابقه",
            12f, false, Ui.sub(this)).apply { setPadding(0, dp(3), 0, 0) })
        card.addView(col, Ui.lp(0, Ui.WRAP, 1f))
        r.addView(card)
    }

    private fun sportCard(emoji: String, label: String, sub: String, color: Int, onClick: () -> Unit): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            background = Ui.glassTint(this@MainActivity, color, dp(22))
            minimumHeight = dp(124); isClickable = true; isFocusable = true
            contentDescription = label
            setOnClickListener { onClick() }
        }
        card.addView(Ui.badge(this, emoji, 0x33FFFFFF, 52, Color.WHITE, 26f))
        card.addView(Ui.tv(this, label, 16f, true, Color.WHITE).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) })
        if (sub.isNotEmpty()) card.addView(Ui.tv(this, sub, 12f, false, 0xCCFFFFFF.toInt()).apply { gravity = Gravity.CENTER })
        return card
    }

    private fun todaySection(leagues: List<League>, ps: List<Participant>, ms: List<MatchEntity>) {
        val today = Jalali.todayKey()
        val dated = ms.filter { it.aId != null && it.bId != null && it.status != MatchStatus.CANCELLED }
            .mapNotNull { m -> Jalali.parseKey(m.planDate)?.let { m to it } }
        var list = dated.filter { it.second == today }.sortedBy { it.first.planTime ?: "" }.map { it.first }
        var title = "مسابقات امروز"
        if (list.isEmpty()) {
            list = dated.filter { !it.first.played && it.second > today }
                .sortedWith(compareBy({ it.second }, { it.first.planTime ?: "" })).take(3).map { it.first }
            title = "مسابقات پیش‌رو"
        }
        r.addView(Ui.tv(this, title, 18f, true).apply { setPadding(dp(2), dp(8), dp(2), dp(10)) })
        if (list.isEmpty()) {
            r.addView(Ui.tv(this, "هنوز مسابقه‌ای با تاریخ تعیین‌شده نداریم. از صفحه‌ی ثبت نتیجه‌ی هر مسابقه، تاریخ و ساعت را وارد کنید.", 13f, false, Ui.sub(this)))
            return
        }
        val leagueOf = leagues.associateBy { it.id }
        fun nm(id: Long?) = ps.firstOrNull { it.id == id }?.name ?: "؟"
        list.forEach { m ->
            val l = leagueOf[m.leagueId]
            val card = Ui.card(this).apply { isClickable = true; isFocusable = true }
            card.addView(Ui.tv(this, "${nm(m.aId)}  ${if (m.played) "${Ui.fa(m.scoreA)} - ${Ui.fa(m.scoreB)}" else "-"}  ${nm(m.bId)}", 15f, true).apply { gravity = Gravity.CENTER })
            val meta = listOfNotNull(l?.let { "${Labels.emoji(it.sport)} ${it.name}" }, m.planDate?.let { "📅 $it" }, m.planTime?.let { "⏰ $it" }, m.venue?.let { "📍 $it" }).joinToString("  ")
            card.addView(Ui.tv(this, Ui.fa(meta), 12f, false, Ui.sub(this)).apply { gravity = Gravity.CENTER; setPadding(0, dp(4), 0, 0) })
            card.addView(Ui.tv(this, if (m.played) "انجام‌شده" else MatchStatus.label(m.status), 12f, true, Prefs.primary(this)).apply { gravity = Gravity.CENTER; setPadding(0, dp(4), 0, 0) })
            card.setOnClickListener { startActivity(Intent(this, MatchActivity::class.java).putExtra(MatchActivity.EXTRA_ID, m.id)) }
            r.addView(card)
        }
    }
}
