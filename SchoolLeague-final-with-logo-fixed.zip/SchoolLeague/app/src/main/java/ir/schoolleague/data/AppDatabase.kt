package ir.schoolleague.data

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [League::class, Participant::class, MatchEntity::class, GameScore::class,
        LeagueSettings::class, ChangeLog::class, Player::class],
    version = 3, exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): LeagueDao

    companion object {
        /** v1 -> v2: match schedule/status columns and the change history table (data is kept). */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE matches ADD COLUMN status TEXT NOT NULL DEFAULT 'SCHEDULED'")
                db.execSQL("ALTER TABLE matches ADD COLUMN planDate TEXT")
                db.execSQL("ALTER TABLE matches ADD COLUMN planTime TEXT")
                db.execSQL("ALTER TABLE matches ADD COLUMN venue TEXT")
                db.execSQL("UPDATE matches SET status = 'DONE' WHERE played = 1")
                db.execSQL("CREATE TABLE IF NOT EXISTS `change_log` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `leagueId` INTEGER NOT NULL, `matchId` INTEGER, `at` INTEGER NOT NULL, `text` TEXT NOT NULL, FOREIGN KEY(`leagueId`) REFERENCES `leagues`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_change_log_leagueId` ON `change_log` (`leagueId`)")
            }
        }

        /** v2 -> v3: team coach/logo and the players table (data is kept). */
        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE participants ADD COLUMN coach TEXT")
                db.execSQL("ALTER TABLE participants ADD COLUMN logoPath TEXT")
                db.execSQL("CREATE TABLE IF NOT EXISTS `players` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `participantId` INTEGER NOT NULL, `name` TEXT NOT NULL, `number` INTEGER, `position` TEXT, `isCaptain` INTEGER NOT NULL, FOREIGN KEY(`participantId`) REFERENCES `participants`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )")
                db.execSQL("CREATE INDEX IF NOT EXISTS `index_players_participantId` ON `players` (`participantId`)")
            }
        }

        @Volatile private var inst: AppDatabase? = null
        fun get(ctx: Context): AppDatabase = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDatabase::class.java, "league.db")
                .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
                .build().also { inst = it }
        }
    }
}
