package ir.schoolleague.ui

import android.content.Intent
import android.os.Bundle
import android.widget.LinearLayout
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.launch

/** All teams/players of every league, grouped by league (bottom-nav "تیم‌ها"). */
class TeamsActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val r = buildScreen("تیم‌ها", back = false, nav = 3)
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                repo.dao.observeAll().collect { leagues ->
                    val ps = repo.dao.allParticipants()
                    val players = repo.dao.allPlayers()
                    r.removeAllViews()
                    if (ps.isEmpty()) {
                        r.addView(Ui.tv(this@TeamsActivity, "هنوز تیمی وجود ندارد. با «ساخت لیگ جدید» شروع کنید.", 14f, false, Ui.sub(this@TeamsActivity)))
                        return@collect
                    }
                    leagues.forEach { l ->
                        val teams = ps.filter { it.leagueId == l.id }.sortedBy { it.seed }
                        if (teams.isEmpty()) return@forEach
                        r.addView(Ui.tv(this@TeamsActivity, "${Labels.emoji(l.sport)} ${l.name}", 16f, true).apply { setPadding(dp(2), dp(8), dp(2), dp(8)) })
                        teams.forEach { t ->
                            val card = Ui.card(this@TeamsActivity).apply {
                                orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL
                                isClickable = true; isFocusable = true
                                setOnClickListener { startActivity(Intent(this@TeamsActivity, TeamActivity::class.java).putExtra(TeamActivity.EXTRA_ID, t.id)) }
                            }
                            card.addView(Ui.avatar(this@TeamsActivity, t.logoPath, t.name, 44))
                            val col = LinearLayout(this@TeamsActivity).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
                            col.addView(Ui.tv(this@TeamsActivity, t.name, 16f, true))
                            val n = players.count { it.participantId == t.id }
                            col.addView(Ui.tv(this@TeamsActivity, "${Ui.fa(n)} ${if (l.sport == ir.schoolleague.data.Sport.PINGPONG) "بازیکن ثبت‌شده" else "بازیکن در فهرست"}", 12f, false, Ui.sub(this@TeamsActivity)))
                            card.addView(col, Ui.lp(0, Ui.WRAP, 1f))
                            card.addView(Ui.tv(this@TeamsActivity, "‹", 22f, true, Ui.sub(this@TeamsActivity)))
                            r.addView(card)
                        }
                    }
                }
            }
        }
    }
}
