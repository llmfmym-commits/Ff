package ir.schoolleague.ui

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import ir.schoolleague.data.League
import ir.schoolleague.data.MatchEntity
import ir.schoolleague.data.MatchStatus
import ir.schoolleague.data.Participant
import kotlinx.coroutines.launch

/** Monthly Jalali calendar; days that have scheduled matches are marked. */
class CalendarActivity : BaseActivity() {
    private lateinit var r: LinearLayout
    private var year = 0
    private var month = 0
    private var selected = 0
    private var leagues: List<League> = emptyList()
    private var teams: List<Participant> = emptyList()
    private var matches: List<MatchEntity> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        r = buildScreen("تقویم مسابقات", back = false, nav = 2)
        val t = Jalali.todayKey()
        year = t / 10000; month = t / 100 % 100; selected = t
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                repo.dao.observeAll().collect { ls ->
                    leagues = ls; teams = repo.dao.allParticipants()
                    matches = repo.dao.allMatches().filter { !it.isBye && it.aId != null && it.bId != null }
                    render()
                }
            }
        }
    }

    private fun shift(d: Int) {
        month += d
        if (month > 12) { month = 1; year++ } else if (month < 1) { month = 12; year-- }
        render()
    }

    private fun render() {
        r.removeAllViews()
        val byDay = HashMap<Int, MutableList<MatchEntity>>()
        matches.forEach { m -> Jalali.parseKey(m.planDate)?.let { byDay.getOrPut(it) { mutableListOf() }.add(m) } }

        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(Ui.tv(this, "›", 28f, true, Prefs.primary(this)).apply {
            gravity = Gravity.CENTER; minWidth = dp(52); minHeight = dp(48); contentDescription = "ماه قبل"; setOnClickListener { shift(-1) }
        })
        head.addView(Ui.tv(this, Ui.fa("${Jalali.monthNames[month - 1]} $year"), 18f, true).apply { gravity = Gravity.CENTER }, Ui.lp(0, Ui.WRAP, 1f))
        head.addView(Ui.tv(this, "‹", 28f, true, Prefs.primary(this)).apply {
            gravity = Gravity.CENTER; minWidth = dp(52); minHeight = dp(48); contentDescription = "ماه بعد"; setOnClickListener { shift(1) }
        })
        r.addView(head)

        val card = Ui.card(this)
        val names = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("ش", "ی", "د", "س", "چ", "پ", "ج").forEach {
            names.addView(Ui.tv(this, it, 13f, true, Ui.sub(this)).apply { gravity = Gravity.CENTER }, Ui.lp(0, Ui.WRAP, 1f))
        }
        card.addView(names, Ui.lp(c = this, b = 6))
        val offset = Jalali.weekdayIndex(year, month, 1)
        val len = Jalali.monthLength(year, month)
        val today = Jalali.todayKey()
        var day = 1 - offset
        while (day <= len) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (col in 0 until 7) {
                if (day in 1..len) {
                    val key = Jalali.key(year, month, day)
                    val has = byDay.containsKey(key)
                    val sel = key == selected
                    val cell = Ui.tv(this, Ui.fa(day) + if (has) "\n•" else "", 14f, sel || key == today,
                        if (sel) Color.WHITE else Ui.ink(this)).apply {
                        gravity = Gravity.CENTER; minHeight = dp(46)
                        if (sel) background = Ui.rounded(Prefs.primary(this@CalendarActivity), dp(12))
                        else if (key == today) background = Ui.rounded(Color.TRANSPARENT, dp(12), Prefs.primary(this@CalendarActivity), dp(1))
                        isClickable = true; isFocusable = true
                        setOnClickListener { selected = key; render() }
                    }
                    row.addView(cell, Ui.lp(0, Ui.WRAP, 1f, this, 1, 1, 1, 1))
                } else row.addView(View(this), Ui.lp(0, dp(46), 1f))
                day++
            }
            card.addView(row)
        }
        r.addView(card)

        val list = (byDay[selected] ?: emptyList<MatchEntity>()).sortedBy { it.planTime ?: "" }
        val selM = selected / 100 % 100
        r.addView(Ui.tv(this, Ui.fa("مسابقه‌های ${Jalali.monthNames[selM - 1]} ${selected % 100}"), 17f, true)
            .apply { setPadding(dp(2), dp(6), dp(2), dp(8)) })
        if (list.isEmpty()) {
            r.addView(Ui.tv(this, "مسابقه‌ای برای این روز ثبت نشده است. تاریخ مسابقه را از صفحه‌ی ثبت نتیجه‌ی همان مسابقه تعیین کنید.", 13f, false, Ui.sub(this)))
            return
        }
        val leagueOf = leagues.associateBy { it.id }
        fun nm(id: Long?) = teams.firstOrNull { it.id == id }?.name ?: "؟"
        list.forEach { m ->
            val c = Ui.card(this).apply { isClickable = true; isFocusable = true }
            c.addView(Ui.tv(this, "${nm(m.aId)} - ${nm(m.bId)}", 15f, true))
            val l = leagueOf[m.leagueId]
            val meta = listOfNotNull(l?.let { "${Labels.emoji(it.sport)} ${it.name}" }, m.planTime?.let { "⏰ $it" }, m.venue?.let { "📍 $it" },
                if (m.played) "${m.scoreA}-${m.scoreB}" else MatchStatus.label(m.status)).joinToString("  ")
            c.addView(Ui.tv(this, Ui.fa(meta), 12f, false, Ui.sub(this)).apply { setPadding(0, dp(3), 0, 0) })
            c.setOnClickListener { startActivity(Intent(this, MatchActivity::class.java).putExtra(MatchActivity.EXTRA_ID, m.id)) }
            r.addView(c)
        }
    }
}
