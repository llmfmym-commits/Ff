package ir.schoolleague.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File

/** Local team/school pictures: copied (downscaled) into the app's private storage. */
object Images {
    private val cache = HashMap<String, Bitmap>()

    fun save(c: Context, uri: Uri, name: String): String? {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 600 || bounds.outHeight / sample > 600) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null
            val dir = File(c.filesDir, "images").apply { mkdirs() }
            val f = File(dir, "$name.png")
            f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            cache.clear()
            return f.absolutePath
        } catch (e: Exception) {
            return null
        }
    }

    fun load(path: String?): Bitmap? {
        if (path == null) return null
        val f = File(path)
        if (!f.exists()) return null
        val key = path + ":" + f.lastModified()
        cache[key]?.let { return it }
        val bmp = try { BitmapFactory.decodeFile(path) } catch (e: Exception) { null } ?: return null
        cache[key] = bmp
        return bmp
    }
}
