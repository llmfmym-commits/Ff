package ir.schoolleague.ui

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.view.ViewOutlineProvider
import android.widget.ImageView
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.dialog.MaterialAlertDialogBuilder

object Ui {
    val NAVY = 0xFF0B1F3A.toInt()
    const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density + 0.5f).toInt()
    fun isDark(c: Context) = (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    fun bg(c: Context) = if (isDark(c)) 0xFF0F172A.toInt() else 0xFFF4F7F6.toInt()
    fun surface(c: Context): Int =
        if (Prefs.glass(c)) (if (isDark(c)) 0x2EFFFFFF else 0xA6FFFFFF.toInt())
        else (if (isDark(c)) 0xFF1E293B.toInt() else Color.WHITE)

    /** Light tint used for table header rows. */
    fun soft(c: Context): Int = if (isDark(c)) 0x1AFFFFFF else 0x14000000
    fun ink(c: Context) = if (isDark(c)) 0xFFE2E8F0.toInt() else NAVY
    fun sub(c: Context) = if (isDark(c)) 0xFF94A3B8.toInt() else 0xFF64748B.toInt()
    fun line(c: Context) = if (isDark(c)) 0xFF334155.toInt() else 0xFFE2E8F0.toInt()
    val ERROR = 0xFFDC2626.toInt()

    fun fa(v: Any): String = v.toString().map { if (it in '0'..'9') ('۰' + (it - '0')) else it }.joinToString("")

    /** Parses Persian/Arabic/Latin digits; null if not a non-negative-looking integer. */
    fun parseInt(s: String): Int? {
        val t = s.trim().map {
            when (it) { in '۰'..'۹' -> '0' + (it - '۰'); in '٠'..'٩' -> '0' + (it - '٠'); else -> it }
        }.joinToString("")
        return t.toIntOrNull()
    }

    fun rounded(color: Int, radius: Int, stroke: Int? = null, strokePx: Int = 0) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius.toFloat(); if (stroke != null) setStroke(strokePx, stroke)
    }

    // ---------- glass look ----------
    private fun blend(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) * t + Color.red(b) * (1 - t)).toInt(),
        (Color.green(a) * t + Color.green(b) * (1 - t)).toInt(),
        (Color.blue(a) * t + Color.blue(b) * (1 - t)).toInt())

    /** Screen background: soft diagonal gradient tinted by the main colour (flat colour when glass is off). */
    fun appBackground(c: Context): Drawable {
        if (Prefs.navy(c)) return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFF050E24.toInt(), 0xFF0B2A5B.toInt()))
        if (!Prefs.glass(c)) return ColorDrawable(bg(c))
        val dark = isDark(c)
        val base = if (dark) 0xFF0B1020.toInt() else Color.WHITE
        return GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
            blend(Prefs.primary(c), base, if (dark) 0.30f else 0.22f),
            blend(0xFF7C3AED.toInt(), base, if (dark) 0.22f else 0.14f),
            blend(0xFF0D9488.toInt(), base, if (dark) 0.22f else 0.18f)))
    }

    /** Header / tab bar: translucent gradient of the main colour. */
    fun headerBg(c: Context): Drawable {
        val p = Prefs.primary(c)
        if (Prefs.navy(c)) return ColorDrawable(Color.TRANSPARENT)
        if (!Prefs.glass(c)) return ColorDrawable(p)
        return GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(
            (p and 0x00FFFFFF) or 0xF2000000.toInt(),
            (blend(p, 0xFF7C3AED.toInt(), 0.7f) and 0x00FFFFFF) or 0xD9000000.toInt()))
    }

    /** Frosted-glass panel: translucent white fill with a light border. */
    fun glass(c: Context, radiusPx: Int): Drawable {
        if (!Prefs.glass(c)) return rounded(surface(c), radiusPx)
        val dark = isDark(c)
        val d = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(
            if (dark) 0x40FFFFFF else 0xCCFFFFFF.toInt(),
            if (dark) 0x1AFFFFFF else 0x80FFFFFF.toInt()))
        d.cornerRadius = radiusPx.toFloat()
        d.setStroke(dp(c, 1), if (dark) 0x33FFFFFF else 0xB3FFFFFF.toInt())
        return d
    }

    /** Coloured glass (used for buttons and the home sport cards). */
    fun glassTint(c: Context, color: Int, radiusPx: Int): Drawable {
        if (!Prefs.glass(c)) return rounded(color, radiusPx)
        val d = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(
            (blend(color, Color.WHITE, 0.85f) and 0x00FFFFFF) or 0xF2000000.toInt(),
            (blend(color, Color.BLACK, 0.80f) and 0x00FFFFFF) or 0xE6000000.toInt()))
        d.cornerRadius = radiusPx.toFloat()
        d.setStroke(dp(c, 1), 0x66FFFFFF)
        return d
    }

    /** White/dark sheet with rounded top corners that holds the content (navy look). */
    fun sheet(c: Context): Drawable = GradientDrawable().apply {
        setColor(if (isDark(c)) 0xFF0F172A.toInt() else 0xFFF1F5FB.toInt())
        val r = dp(c, 26).toFloat()
        cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
    }

    private val avatarColors = intArrayOf(0xFF1677FF.toInt(), 0xFF7C3AED.toInt(), 0xFF16A34A.toInt(), 0xFFEA580C.toInt(), 0xFFE11D48.toInt(), 0xFF0D9488.toInt())

    /** Round team/school picture, or a coloured circle with the first letter when there is no picture. */
    fun avatar(c: Context, path: String?, name: String, sizeDp: Int): View {
        val bmp = Images.load(path)
        if (bmp == null) {
            val color = avatarColors[(name.hashCode() and 0x7FFFFFFF) % avatarColors.size]
            return badge(c, name.trim().take(1).ifEmpty { "؟" }, color, sizeDp, Color.WHITE, sizeDp / 2.6f)
        }
        return ImageView(c).apply {
            setImageBitmap(bmp); scaleType = ImageView.ScaleType.CENTER_CROP
            layoutParams = LinearLayout.LayoutParams(dp(c, sizeDp), dp(c, sizeDp))
            outlineProvider = ViewOutlineProvider.BACKGROUND
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE) }
            clipToOutline = true
            contentDescription = name
        }
    }

    fun lp(w: Int = MATCH, h: Int = WRAP, weight: Float = 0f, c: Context? = null, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0) =
        LinearLayout.LayoutParams(w, h, weight).apply {
            if (c != null) setMargins(dp(c, l), dp(c, t), dp(c, r), dp(c, b))
        }

    fun tv(c: Context, t: String, size: Float = 14f, bold: Boolean = false, color: Int = ink(c)) = TextView(c).apply {
        text = t; textSize = size * Prefs.textScale(c); setTextColor(color)
        typeface = Typeface.create(Prefs.typeface(c), if (bold) Typeface.BOLD else Typeface.NORMAL)
        textAlignment = View.TEXT_ALIGNMENT_VIEW_START
    }

    fun card(c: Context) = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        background = glass(c, dp(c, 20))
        setPadding(dp(c, 14), dp(c, 14), dp(c, 14), dp(c, 14))
        elevation = if (Prefs.glass(c)) 0f else dp(c, 2).toFloat()
        layoutParams = lp(c = c, b = 10)
    }

    fun button(c: Context, t: String, filled: Boolean = true, onClick: () -> Unit) =
        tv(c, t, 15f, true, if (filled) Color.WHITE else Prefs.primary(c)).apply {
            gravity = Gravity.CENTER
            minHeight = dp(c, 48)
            setPadding(dp(c, 16), dp(c, 8), dp(c, 16), dp(c, 8))
            background = if (filled) glassTint(c, Prefs.primary(c), dp(c, 14))
            else rounded(if (Prefs.glass(c)) (if (isDark(c)) 0x22FFFFFF else 0x80FFFFFF.toInt()) else Color.TRANSPARENT,
                dp(c, 14), Prefs.primary(c), dp(c, 1))
            isClickable = true; isFocusable = true
            setOnClickListener { onClick() }
        }

    fun edit(c: Context, hint: String, number: Boolean = false, value: String = "") = EditText(c).apply {
        this.hint = hint; setText(value)
        textSize = 15f * Prefs.textScale(c)
        setTextColor(ink(c)); setHintTextColor(sub(c))
        typeface = Prefs.typeface(c)
        inputType = if (number) InputType.TYPE_CLASS_NUMBER else InputType.TYPE_CLASS_TEXT
        minHeight = dp(c, 48)
        setPadding(dp(c, 12), dp(c, 8), dp(c, 12), dp(c, 8))
        background = rounded(if (Prefs.glass(c)) (if (isDark(c)) 0x22FFFFFF else 0x99FFFFFF.toInt()) else Color.TRANSPARENT,
            dp(c, 12), line(c), dp(c, 1))
        textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        maxLines = 1
    }

    fun badge(c: Context, text: String, bgColor: Int, sizeDp: Int, textColor: Int = Color.WHITE, textSp: Float = 13f): TextView =
        tv(c, text, textSp, true, textColor).apply {
            gravity = Gravity.CENTER
            background = rounded(bgColor, dp(c, sizeDp))
            layoutParams = LinearLayout.LayoutParams(dp(c, sizeDp), dp(c, sizeDp))
        }

    fun rankColor(rank: Int): Int? = when (rank) {
        1 -> 0xFFF5B301.toInt(); 2 -> 0xFF9AA3AE.toInt(); 3 -> 0xFFC0692F.toInt(); else -> null
    }

    fun toast(c: Context, m: String) = Toast.makeText(c, m, Toast.LENGTH_LONG).show()

    fun confirm(c: Context, title: String, msg: String, okLabel: String = "تأیید", onOk: () -> Unit) {
        MaterialAlertDialogBuilder(c).setTitle(title).setMessage(msg)
            .setPositiveButton(okLabel) { _, _ -> onOk() }.setNegativeButton("انصراف", null).show()
    }

    fun prompt(c: Context, title: String, initial: String, onOk: (String) -> Unit) {
        val box = LinearLayout(c).apply { setPadding(dp(c, 20), dp(c, 8), dp(c, 20), 0); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val e = edit(c, "", false, initial)
        box.addView(e, lp())
        MaterialAlertDialogBuilder(c).setTitle(title).setView(box)
            .setPositiveButton("ذخیره") { _, _ -> onOk(e.text.toString()) }.setNegativeButton("انصراف", null).show()
    }

    fun fadeIn(v: View, index: Int) {
        v.alpha = 0f; v.translationY = 40f
        v.animate().alpha(1f).translationY(0f).setStartDelay(index * 70L).setDuration(300).start()
    }
}
