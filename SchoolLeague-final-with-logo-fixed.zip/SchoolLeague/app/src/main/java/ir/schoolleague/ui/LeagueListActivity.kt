package ir.schoolleague.ui

import android.content.Intent
import android.os.Bundle
import android.widget.LinearLayout
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import ir.schoolleague.data.League
import ir.schoolleague.data.Status
import kotlinx.coroutines.launch

/** All leagues ("لیگ‌های من", bottom-nav tab) or only one sport when EXTRA_SPORT is given. */
class LeagueListActivity : BaseActivity() {
    companion object { const val EXTRA_SPORT = "sport" }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sport = intent.getStringExtra(EXTRA_SPORT)
        val r = buildScreen(if (sport == null) "لیگ‌های من" else "لیگ‌های ${Labels.sport(sport)}",
            back = sport != null, nav = if (sport == null) 1 else -1)
        if (sport != null) setHeaderBadge(Labels.emoji(sport))
        val flow = if (sport == null) repo.dao.observeAll() else repo.dao.observeBySport(sport)
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                flow.collect { leagues ->
                    val counts = leagues.associate { it.id to repo.dao.countParticipants(it.id) }
                    r.removeAllViews()
                    section(r, "در حال برگزاری", leagues.filter { it.status == Status.ACTIVE }, counts)
                    section(r, "پایان‌یافته", leagues.filter { it.status == Status.FINISHED }, counts)
                    r.addView(Ui.button(this@LeagueListActivity, "ساخت لیگ جدید") {
                        val i = Intent(this@LeagueListActivity, CreateLeagueActivity::class.java)
                        if (sport != null) i.putExtra(CreateLeagueActivity.EXTRA_SPORT, sport)
                        startActivity(i)
                    }, Ui.lp(c = this@LeagueListActivity, t = 8))
                }
            }
        }
    }

    private fun section(r: LinearLayout, title: String, list: List<League>, counts: Map<Long, Int>) {
        r.addView(Ui.tv(this, "$title (${Ui.fa(list.size)})", 16f, true).apply { setPadding(dp(4), dp(8), dp(4), dp(8)) })
        if (list.isEmpty()) {
            r.addView(Ui.tv(this, "لیگی در این بخش وجود ندارد.", 13f, false, Ui.sub(this)).apply { setPadding(dp(4), 0, dp(4), dp(12)) })
            return
        }
        list.forEach { l ->
            val card = Ui.card(this).apply { orientation = LinearLayout.HORIZONTAL; isClickable = true; isFocusable = true }
            card.addView(Ui.badge(this, Labels.emoji(l.sport), Ui.line(this), 44, ir.schoolleague.ui.Ui.ink(this), 22f))
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
            col.addView(Ui.tv(this, l.name, 16f, true))
            col.addView(Ui.tv(this, "${Labels.sport(l.sport)} • ${Labels.format(l.format)} • ${Ui.fa(counts[l.id] ?: 0)} ${Labels.noun(l.sport)}",
                12f, false, Ui.sub(this)).apply { setPadding(0, dp(3), 0, 0) })
            card.addView(col, Ui.lp(0, Ui.WRAP, 1f))
            card.setOnClickListener { startActivity(Intent(this, LeagueActivity::class.java).putExtra(LeagueActivity.EXTRA_ID, l.id)) }
            r.addView(card)
        }
    }
}
