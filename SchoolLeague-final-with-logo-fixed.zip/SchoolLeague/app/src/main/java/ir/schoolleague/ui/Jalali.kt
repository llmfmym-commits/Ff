package ir.schoolleague.ui

import java.util.Calendar

/** Gregorian → Jalali (Solar Hijri) date, formatted with Persian digits. */
object Jalali {
    fun convert(gy: Int, gm: Int, gd: Int): Triple<Int, Int, Int> {
        val gdm = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
        val gy2 = if (gm > 2) gy + 1 else gy
        var days = 355666 + (365 * gy) + ((gy2 + 3) / 4) - ((gy2 + 99) / 100) + ((gy2 + 399) / 400) + gd + gdm[gm - 1]
        var jy = -1595 + (33 * (days / 12053))
        days %= 12053
        jy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) { jy += (days - 1) / 365; days = (days - 1) % 365 }
        val jm: Int
        val jd: Int
        if (days < 186) { jm = 1 + days / 31; jd = 1 + days % 31 } else { jm = 7 + (days - 186) / 30; jd = 1 + (days - 186) % 30 }
        return Triple(jy, jm, jd)
    }

    /** "۱۴۰۵/۰۷/۲۶ ۱۶:۳۰" for an epoch-millis timestamp. */
    fun stamp(ms: Long): String {
        val c = Calendar.getInstance().apply { timeInMillis = ms }
        val (y, m, d) = convert(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
        return Ui.fa("%04d/%02d/%02d %02d:%02d".format(y, m, d, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE)))
    }

    fun isLeap(y: Int) = (y % 33) in intArrayOf(1, 5, 9, 13, 17, 22, 26, 30)
    fun monthLength(y: Int, m: Int) = if (m <= 6) 31 else if (m <= 11) 30 else if (isLeap(y)) 30 else 29

    fun toGregorian(jy0: Int, jm: Int, jd: Int): Triple<Int, Int, Int> {
        val jy = jy0 + 1595
        var days = -355668 + (365 * jy) + ((jy / 33) * 8) + (((jy % 33) + 3) / 4) + jd +
            (if (jm < 7) (jm - 1) * 31 else ((jm - 7) * 30) + 186)
        var gy = 400 * (days / 146097)
        days %= 146097
        if (days > 36524) {
            days--
            gy += 100 * (days / 36524)
            days %= 36524
            if (days >= 365) days++
        }
        gy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) { gy += (days - 1) / 365; days = (days - 1) % 365 }
        var gd = days + 1
        val leap = (gy % 4 == 0 && gy % 100 != 0) || gy % 400 == 0
        val sal = intArrayOf(0, 31, if (leap) 29 else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
        var gm = 0
        while (gm < 13 && gd > sal[gm]) { gd -= sal[gm]; gm++ }
        return Triple(gy, gm, gd)
    }

    /** 0 = Saturday ... 6 = Friday for the given Jalali date. */
    fun weekdayIndex(jy: Int, jm: Int, jd: Int): Int {
        val (gy, gm, gd) = toGregorian(jy, jm, jd)
        val c = Calendar.getInstance().apply { clear(); set(gy, gm - 1, gd) }
        return c.get(Calendar.DAY_OF_WEEK) % 7   // Calendar: Sunday=1 .. Saturday=7
    }

    val monthNames = listOf("فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند")

    fun key(y: Int, m: Int, d: Int) = y * 10000 + m * 100 + d

    /** "۱۴۰۵/۰۷/۲۶" (Persian, Arabic or Latin digits; / - . separators) -> 14050726, or null. */
    fun parseKey(text: String?): Int? {
        if (text == null) return null
        val t = text.trim().map {
            when (it) { in '۰'..'۹' -> '0' + (it - '۰'); in '٠'..'٩' -> '0' + (it - '٠'); else -> it }
        }.joinToString("")
        val p = t.split('/', '-', '.').map { it.trim().toIntOrNull() ?: return null }
        if (p.size != 3 || p[1] !in 1..12 || p[2] !in 1..31 || p[0] !in 1200..1600) return null
        return key(p[0], p[1], p[2])
    }

    fun todayKey(): Int {
        val c = Calendar.getInstance()
        val (y, m, d) = convert(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
        return key(y, m, d)
    }

    fun today(): String {
        val c = Calendar.getInstance()
        val (y, m, d) = convert(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
        return Ui.fa("$y/${m.toString().padStart(2, '0')}/${d.toString().padStart(2, '0')}")
    }
}
