package ir.schoolleague.data

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

data class BackupData(
    val leagues: List<League>, val participants: List<Participant>, val matches: List<MatchEntity>,
    val games: List<GameScore>, val settings: List<LeagueSettings>,
    val logs: List<ChangeLog> = emptyList(),
    val players: List<Player> = emptyList()
)

/** Pure (no Room) JSON encoder/decoder with validation, so it is unit-testable. */
object BackupCodec {
    const val APP = "SchoolLeague"
    const val VERSION = 1

    fun encode(d: BackupData): String {
        val o = JSONObject()
        o.put("app", APP); o.put("version", VERSION)
        o.put("leagues", JSONArray().also { a -> d.leagues.forEach { l ->
            a.put(JSONObject().put("id", l.id).put("name", l.name).put("sport", l.sport)
                .put("format", l.format).put("status", l.status).put("createdAt", l.createdAt)) } })
        o.put("participants", JSONArray().also { a -> d.participants.forEach { p ->
            a.put(JSONObject().put("id", p.id).put("leagueId", p.leagueId).put("name", p.name).put("seed", p.seed)
                .put("coach", p.coach ?: JSONObject.NULL).put("logoPath", p.logoPath ?: JSONObject.NULL)) } })
        o.put("matches", JSONArray().also { a -> d.matches.forEach { m ->
            a.put(JSONObject().put("id", m.id).put("leagueId", m.leagueId).put("round", m.round)
                .put("indexInRound", m.indexInRound).put("aId", m.aId ?: JSONObject.NULL)
                .put("bId", m.bId ?: JSONObject.NULL).put("played", m.played)
                .put("winnerId", m.winnerId ?: JSONObject.NULL).put("scoreA", m.scoreA).put("scoreB", m.scoreB)
                .put("penA", m.penA ?: JSONObject.NULL).put("penB", m.penB ?: JSONObject.NULL)
                .put("extraTime", m.extraTime).put("isBye", m.isBye)
                .put("yellowA", m.yellowA).put("yellowB", m.yellowB).put("redA", m.redA).put("redB", m.redB)
                .put("dateText", m.dateText ?: JSONObject.NULL)
                .put("status", m.status).put("planDate", m.planDate ?: JSONObject.NULL)
                .put("planTime", m.planTime ?: JSONObject.NULL).put("venue", m.venue ?: JSONObject.NULL)) } })
        o.put("games", JSONArray().also { a -> d.games.forEach { g ->
            a.put(JSONObject().put("id", g.id).put("matchId", g.matchId).put("gameNo", g.gameNo)
                .put("pointsA", g.pointsA).put("pointsB", g.pointsB)) } })
        o.put("settings", JSONArray().also { a -> d.settings.forEach { s ->
            a.put(JSONObject().put("leagueId", s.leagueId).put("winPoints", s.winPoints)
                .put("drawPoints", s.drawPoints).put("losePoints", s.losePoints)
                .put("gamePoints", s.gamePoints).put("deciderPoints", s.deciderPoints)
                .put("doubleRound", s.doubleRound)) } })
        o.put("logs", JSONArray().also { a -> d.logs.forEach { g ->
            a.put(JSONObject().put("id", g.id).put("leagueId", g.leagueId).put("matchId", g.matchId ?: JSONObject.NULL)
                .put("at", g.at).put("text", g.text)) } })
        o.put("players", JSONArray().also { a -> d.players.forEach { p ->
            a.put(JSONObject().put("id", p.id).put("participantId", p.participantId).put("name", p.name)
                .put("number", p.number ?: JSONObject.NULL).put("position", p.position ?: JSONObject.NULL)
                .put("isCaptain", p.isCaptain)) } })
        return o.toString()
    }

    fun decode(text: String): BackupData {
        try {
            val o = JSONObject(text)
            require(o.optString("app") == APP) { "این فایل، پشتیبان این برنامه نیست." }
            require(o.optInt("version", 0) in 1..VERSION) { "نسخه‌ی فایل پشتیبان پشتیبانی نمی‌شود." }
            val leagues = arr(o, "leagues") {
                League(it.getLong("id"), it.getString("name"), it.getString("sport"), it.getString("format"),
                    it.getString("status"), it.getLong("createdAt"))
            }
            val participants = arr(o, "participants") {
                Participant(it.getLong("id"), it.getLong("leagueId"), it.getString("name"), it.getInt("seed"),
                    if (it.isNull("coach")) null else it.getString("coach"),
                    if (it.isNull("logoPath")) null else it.getString("logoPath"))
            }
            val matches = arr(o, "matches") {
                MatchEntity(it.getLong("id"), it.getLong("leagueId"), it.getInt("round"), it.getInt("indexInRound"),
                    it.longOrNull("aId"), it.longOrNull("bId"), it.getBoolean("played"), it.longOrNull("winnerId"),
                    it.getInt("scoreA"), it.getInt("scoreB"), it.intOrNull("penA"), it.intOrNull("penB"),
                    it.getBoolean("extraTime"), it.getBoolean("isBye"),
                    it.optInt("yellowA", 0), it.optInt("yellowB", 0), it.optInt("redA", 0), it.optInt("redB", 0),
                    if (it.isNull("dateText")) null else it.getString("dateText"),
                    it.optString("status", "SCHEDULED").ifEmpty { "SCHEDULED" },
                    if (it.isNull("planDate")) null else it.getString("planDate"),
                    if (it.isNull("planTime")) null else it.getString("planTime"),
                    if (it.isNull("venue")) null else it.getString("venue"))
            }
            val games = arr(o, "games") {
                GameScore(it.getLong("id"), it.getLong("matchId"), it.getInt("gameNo"), it.getInt("pointsA"), it.getInt("pointsB"))
            }
            val settings = arr(o, "settings") {
                LeagueSettings(it.getLong("leagueId"), it.getInt("winPoints"), it.getInt("drawPoints"),
                    it.getInt("losePoints"), it.getInt("gamePoints"), it.getInt("deciderPoints"), it.getBoolean("doubleRound"))
            }
            val logs = if (o.has("logs")) arr(o, "logs") {
                ChangeLog(it.getLong("id"), it.getLong("leagueId"), it.longOrNull("matchId"), it.getLong("at"), it.getString("text"))
            } else emptyList()
            val pids = participants.map { it.id }.toSet()
            val players = if (o.has("players")) arr(o, "players") {
                Player(it.getLong("id"), it.getLong("participantId"), it.getString("name"), it.intOrNull("number"),
                    if (it.isNull("position")) null else it.getString("position"), it.getBoolean("isCaptain"))
            } else emptyList()
            require(players.all { it.participantId in pids }) { "ارجاع بازیکنان در فایل پشتیبان نامعتبر است." }
            val ids = leagues.map { it.id }.toSet()
            val sports = setOf(Sport.PINGPONG, Sport.FOOTBALL, Sport.VOLLEYBALL)
            require(leagues.all { it.sport in sports && it.format in setOf(Format.KNOCKOUT, Format.ROUND_ROBIN) }) { "اطلاعات لیگ‌ها نامعتبر است." }
            require(participants.all { it.leagueId in ids } && matches.all { it.leagueId in ids } &&
                settings.all { it.leagueId in ids }) { "ارجاع داده‌ها در فایل پشتیبان نامعتبر است." }
            require(logs.all { it.leagueId in ids }) { "ارجاع تاریخچه در فایل پشتیبان نامعتبر است." }
            val mids = matches.map { it.id }.toSet()
            require(games.all { it.matchId in mids }) { "ارجاع نتیجه‌ها در فایل پشتیبان نامعتبر است." }
            return BackupData(leagues, participants, matches, games, settings, logs, players)
        } catch (e: JSONException) {
            throw IllegalArgumentException("فایل پشتیبان نامعتبر یا آسیب‌دیده است.")
        }
    }

    private fun <T> arr(o: JSONObject, key: String, f: (JSONObject) -> T): List<T> {
        val a = o.getJSONArray(key)
        return (0 until a.length()).map { f(a.getJSONObject(it)) }
    }
    private fun JSONObject.longOrNull(k: String): Long? = if (isNull(k)) null else getLong(k)
    private fun JSONObject.intOrNull(k: String): Int? = if (isNull(k)) null else getInt(k)
}
