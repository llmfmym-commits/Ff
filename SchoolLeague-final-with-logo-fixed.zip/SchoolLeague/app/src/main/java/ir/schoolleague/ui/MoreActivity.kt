package ir.schoolleague.ui

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/** "بیشتر": statistics, settings and about (bottom-nav). */
class MoreActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val r = buildScreen("بیشتر", back = false, nav = 4)
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "" } ?: ""
        listOf(
            Triple("📊", "آمار کلی", "همه‌ی لیگ‌ها و مسابقه‌ها") to { startActivity(Intent(this, StatsActivity::class.java)) },
            Triple("⚙", "تنظیمات", "ظاهر، فونت، اطلاعات مدرسه، پشتیبان‌گیری") to { startActivity(Intent(this, SettingsActivity::class.java)) },
            Triple("ℹ", "درباره‌ی برنامه", "نسخه ${Ui.fa(ver)}") to {
                MaterialAlertDialogBuilder(this).setTitle("SchoolLeague")
                    .setMessage("مدیریت لیگ‌های ورزشی مدرسه (پینگ‌پنگ، فوتبال، والیبال)\nنسخه ${Ui.fa(ver)}\nهمه‌ی اطلاعات روی همین دستگاه ذخیره می‌شود و برنامه به اینترنت نیاز ندارد.")
                    .setPositiveButton("باشه", null).show(); Unit
            }
        ).forEach { (info, action) ->
            val card = Ui.card(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                isClickable = true; isFocusable = true; contentDescription = info.second
                setOnClickListener { action() }
            }
            card.addView(Ui.badge(this, info.first, Ui.line(this), 44, Ui.ink(this), 22f))
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
            col.addView(Ui.tv(this, info.second, 16f, true))
            col.addView(Ui.tv(this, info.third, 12f, false, Ui.sub(this)))
            card.addView(col, Ui.lp(0, Ui.WRAP, 1f))
            card.addView(Ui.tv(this, "‹", 22f, true, Ui.sub(this)))
            r.addView(card)
        }
    }
}
