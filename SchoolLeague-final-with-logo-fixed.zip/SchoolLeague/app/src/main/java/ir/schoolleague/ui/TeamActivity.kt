package ir.schoolleague.ui

import android.content.DialogInterface
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.LinearLayout
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import ir.schoolleague.data.Participant
import ir.schoolleague.data.Player
import ir.schoolleague.data.Sport
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Team profile: logo, coach, results summary and the player list (number, position, captain). */
class TeamActivity : BaseActivity() {
    companion object { const val EXTRA_ID = "participantId" }

    private lateinit var r: LinearLayout
    private var pid = -1L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pid = intent.getLongExtra(EXTRA_ID, -1)
        r = buildScreen("پروفایل تیم")
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                combine(repo.dao.observeParticipant(pid), repo.dao.observePlayers(pid)) { t, p -> t to p }
                    .collect { (team, players) ->
                        if (team == null) { finish(); return@collect }
                        render(team, players)
                    }
            }
        }
    }

    private fun positionsFor(sport: String): List<String> = when (sport) {
        Sport.FOOTBALL -> listOf("دروازه‌بان", "مدافع", "هافبک", "مهاجم")
        Sport.VOLLEYBALL -> listOf("پاسور", "دیاگونال", "وسط", "کنار", "لیبرو")
        else -> emptyList()
    }

    private suspend fun render(team: Participant, players: List<Player>) {
        val league = repo.dao.getLeague(team.leagueId) ?: run { finish(); return }
        val played = repo.dao.getMatches(team.leagueId).filter { !it.isBye && it.played && (it.aId == team.id || it.bId == team.id) }
        val wins = played.count { it.winnerId == team.id }
        val draws = played.count { it.winnerId == null }
        val losses = played.size - wins - draws
        titleView.text = team.name
        r.removeAllViews()

        val head = Ui.card(this).apply { gravity = Gravity.CENTER_HORIZONTAL }
        val av = Ui.avatar(this, team.logoPath, team.name, 84).apply {
            isClickable = true; isFocusable = true; contentDescription = "تغییر لوگوی تیم"
            setOnClickListener {
                pickImage { uri ->
                    lifecycleScope.launch {
                        val path = withContext(Dispatchers.IO) { Images.save(this@TeamActivity, uri, "team_${team.id}") }
                        if (path != null) repo.setTeamLogo(team.id, path) else Ui.toast(this@TeamActivity, "خواندن تصویر ناموفق بود.")
                    }
                }
            }
        }
        head.addView(av)
        head.addView(Ui.tv(this, "برای تغییر لوگو روی تصویر بزنید", 11f, false, Ui.sub(this)).apply { gravity = Gravity.CENTER; setPadding(0, dp(4), 0, dp(6)) })
        head.addView(Ui.tv(this, team.name, 20f, true).apply { gravity = Gravity.CENTER })
        head.addView(Ui.tv(this, "${Labels.emoji(league.sport)} ${league.name}", 13f, false, Ui.sub(this)).apply { gravity = Gravity.CENTER; setPadding(0, dp(2), 0, dp(8)) })
        head.addView(Ui.tv(this, "مربی: " + (team.coach ?: "ثبت نشده") + "  ✏", 14f, true, Prefs.primary(this)).apply {
            gravity = Gravity.CENTER; minHeight = dp(44); isClickable = true; contentDescription = "ویرایش مربی"
            setOnClickListener { Ui.prompt(this@TeamActivity, "نام مربی", team.coach ?: "") { n -> lifecycleScope.launch { repo.setCoach(team.id, n) } } }
        })
        r.addView(head)

        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("بازی" to played.size, "برد" to wins, "مساوی" to draws, "باخت" to losses).forEach { (label, n) ->
            val c = Ui.card(this).apply { gravity = Gravity.CENTER; setPadding(dp(4), dp(10), dp(4), dp(10)) }
            c.addView(Ui.tv(this, Ui.fa(n), 20f, true, Prefs.primary(this)).apply { gravity = Gravity.CENTER })
            c.addView(Ui.tv(this, label, 12f, false, Ui.sub(this)).apply { gravity = Gravity.CENTER })
            stats.addView(c, Ui.lp(0, Ui.WRAP, 1f, this, 2, 0, 2, 0))
        }
        r.addView(stats)

        r.addView(Ui.tv(this, "فهرست بازیکنان (${Ui.fa(players.size)})", 17f, true).apply { setPadding(dp(2), dp(6), dp(2), dp(8)) })
        if (players.isEmpty()) r.addView(Ui.tv(this, "هنوز بازیکنی ثبت نشده است.", 13f, false, Ui.sub(this)), Ui.lp(c = this, b = 8))
        players.forEach { p ->
            val card = Ui.card(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                isClickable = true; isFocusable = true; contentDescription = p.name
                setOnClickListener { playerDialog(team, league.sport, p) }
            }
            card.addView(Ui.badge(this, p.number?.let { Ui.fa(it) } ?: "-", Prefs.primary(this), 40, Color.WHITE, 14f))
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
            col.addView(Ui.tv(this, p.name + if (p.isCaptain) "  👑" else "", 15f, true))
            val sub = listOfNotNull(p.position, if (p.isCaptain) "کاپیتان" else null).joinToString(" • ")
            if (sub.isNotEmpty()) col.addView(Ui.tv(this, sub, 12f, false, Ui.sub(this)))
            card.addView(col, Ui.lp(0, Ui.WRAP, 1f))
            card.addView(Ui.tv(this, "✏", 18f, false, Ui.sub(this)))
            r.addView(card)
        }
        r.addView(Ui.button(this, "افزودن بازیکن") { playerDialog(team, league.sport, null) }, Ui.lp(c = this, t = 6))
    }

    private fun playerDialog(team: Participant, sport: String, p: Player?) {
        val c = this
        val box = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val name = Ui.edit(c, "نام بازیکن", false, p?.name ?: "")
        val number = Ui.edit(c, "شماره‌ی پیراهن (اختیاری)", true, p?.number?.toString() ?: "")
        box.addView(name, Ui.lp(c = c, b = 8)); box.addView(number, Ui.lp(c = c, b = 8))
        val positions = positionsFor(sport)
        var pos = p?.position
        if (positions.isNotEmpty()) {
            val posBtn = Ui.tv(c, pos ?: "پست (اختیاری)", 15f, true, Prefs.primary(c)).apply {
                minHeight = dp(48); gravity = Gravity.CENTER_VERTICAL; isClickable = true
                background = Ui.rounded(Color.TRANSPARENT, dp(12), Ui.line(c), dp(1)); setPadding(dp(12), 0, dp(12), 0)
            }
            posBtn.setOnClickListener {
                MaterialAlertDialogBuilder(c).setTitle("پست بازیکن")
                    .setItems((listOf("بدون پست") + positions).toTypedArray()) { _, i ->
                        pos = if (i == 0) null else positions[i - 1]; posBtn.text = pos ?: "پست (اختیاری)"
                    }.show()
            }
            box.addView(posBtn, Ui.lp(c = c, b = 8))
        }
        val cap = CheckBox(c).apply { text = "کاپیتان تیم"; isChecked = p?.isCaptain == true; setTextColor(Ui.ink(c)) }
        box.addView(cap)
        val err = Ui.tv(c, "", 13f, false, Ui.ERROR)
        box.addView(err)
        val b = MaterialAlertDialogBuilder(c).setTitle(if (p == null) "افزودن بازیکن" else "ویرایش بازیکن").setView(box)
            .setPositiveButton("ذخیره", null).setNegativeButton("انصراف", null)
        if (p != null) b.setNeutralButton("حذف", null)
        val dlg = b.create(); dlg.show()
        dlg.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
            val nt = number.text.toString()
            val num = if (nt.isBlank()) null else Ui.parseInt(nt)
            if (nt.isNotBlank() && num == null) { err.text = "شماره‌ی پیراهن را به‌صورت عدد وارد کنید."; return@setOnClickListener }
            lifecycleScope.launch {
                val e = if (p == null) repo.addPlayer(team.id, name.text.toString(), num, pos, cap.isChecked)
                else repo.updatePlayer(p, name.text.toString(), num, pos, cap.isChecked)
                if (e != null) err.text = e else dlg.dismiss()
            }
        }
        if (p != null) dlg.getButton(DialogInterface.BUTTON_NEUTRAL).setOnClickListener {
            Ui.confirm(c, "حذف بازیکن", "«${p.name}» از فهرست تیم حذف می‌شود.", "حذف") {
                lifecycleScope.launch { repo.deletePlayer(p); dlg.dismiss() }
            }
        }
    }
}
