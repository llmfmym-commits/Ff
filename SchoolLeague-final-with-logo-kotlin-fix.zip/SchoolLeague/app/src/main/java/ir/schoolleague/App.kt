package ir.schoolleague

import android.app.Application
import ir.schoolleague.ui.Prefs
import ir.schoolleague.ui.CrashReporter

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.applyNightMode(this)
        CrashReporter.install(this)
    }
}
