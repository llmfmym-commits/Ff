package com.nova.browser

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.webkit.WebView
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener

private const val REQ_SAVE_AS = 2001
private const val MAX_BYTES = 1500000

/** Text / code viewer and editor with find, save, HTML preview and JSON formatting. */
class CodeViewerActivity : Activity() {
    private var fileUri: Uri? = null
    private var fileName = "file.txt"
    private var canSave = true
    private var dirty = false
    private var textSizeSp = 13f
    private var edit: EditText? = null
    private var holder: FrameLayout? = null
    private var previewView: WebView? = null
    private var findRow: LinearLayout? = null
    private var findInput: EditText? = null
    private var status: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val u = intent.data
        if (u == null) {
            toast("فایلی انتخاب نشده است")
            finish()
            return
        }
        fileUri = u
        fileName = intent.getStringExtra("name") ?: displayName(u)

        val bytes = readLimited(u)
        if (bytes == null) {
            toast("خواندن فایل ممکن نشد")
            finish()
            return
        }
        var length = bytes.size
        if (length > MAX_BYTES) {
            length = MAX_BYTES
            canSave = false
            toast("فایل بزرگ است؛ فقط بخشی نمایش داده می‌شود (فقط‌خواندنی)")
        }
        val probe = minOf(length, 8000)
        for (i in 0 until probe) {
            if (bytes[i].toInt() == 0) {
                toast("این فایل متنی نیست")
                finish()
                return
            }
        }
        val text = String(bytes, 0, length, Charsets.UTF_8)

        val f = createToolFrame(fileName)
        val ext = FileOpener.extOf(fileName)
        f.header.addView(iconButton(R.drawable.ic_search, 44, 22, C_TEXT) { toggleFind() })
        f.header.addView(iconButton(R.drawable.ic_remove, 44, 22, C_TEXT) { changeSize(-1f) })
        f.header.addView(iconButton(R.drawable.ic_add, 44, 22, C_TEXT) { changeSize(1f) })
        if (ext == "html" || ext == "htm" || ext == "svg") {
            f.header.addView(iconButton(R.drawable.ic_play, 44, 22, C_TEXT) { togglePreview() })
        } else if (ext == "py") {
            f.header.addView(iconButton(R.drawable.ic_cube, 44, 22, C_TEXT) { openInStudio() })
        } else if (ext == "json") {
            f.header.addView(iconButton(R.drawable.ic_refresh, 44, 22, C_TEXT) { formatJson() })
        }
        f.header.addView(iconButton(R.drawable.ic_save, 44, 22, C_TEXT) { save() })

        val fr = LinearLayout(this)
        fr.orientation = LinearLayout.HORIZONTAL
        fr.gravity = Gravity.CENTER_VERTICAL
        fr.setBackgroundColor(C_TOOLBAR)
        fr.setPadding(dp(12), dp(4), dp(4), dp(4))
        fr.visibility = View.GONE
        val fi = EditText(this)
        fi.hint = "یافتن در متن"
        fi.setHintTextColor(C_MUTED)
        fi.setTextColor(C_TEXT)
        fi.textSize = 15f
        fi.setSingleLine(true)
        fi.background = roundRect(C_PILL, 20)
        fi.setPadding(dp(14), 0, dp(14), 0)
        fr.addView(fi, LinearLayout.LayoutParams(0, dp(40), 1f))
        fr.addView(iconButton(R.drawable.ic_up, 40, 22, C_TEXT) { findNext(false) })
        fr.addView(iconButton(R.drawable.ic_down, 40, 22, C_TEXT) { findNext(true) })
        findRow = fr
        findInput = fi
        f.root.addView(fr, LinearLayout.LayoutParams(MATCH, WRAP))

        val h = FrameLayout(this)
        val ed = EditText(this)
        ed.setText(text)
        ed.typeface = Typeface.MONOSPACE
        ed.textSize = textSizeSp
        ed.setTextColor(C_TEXT)
        ed.setBackgroundColor(Color.parseColor("#0E1030"))
        ed.gravity = Gravity.TOP or Gravity.START
        ed.textDirection = View.TEXT_DIRECTION_LTR
        ed.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
            InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        ed.setHorizontallyScrolling(false)
        ed.isVerticalScrollBarEnabled = true
        ed.setPadding(dp(12), dp(8), dp(12), dp(8))
        ed.isEnabled = true
        if (!canSave) ed.isCursorVisible = false
        ed.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                dirty = true
                updateStatus()
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            }
        })
        h.addView(ed, FrameLayout.LayoutParams(MATCH, MATCH))
        holder = h
        edit = ed
        f.root.addView(h, LinearLayout.LayoutParams(MATCH, 0, 1f))

        val st = TextView(this)
        st.textSize = 12f
        st.setTextColor(C_MUTED)
        st.setBackgroundColor(C_TOOLBAR)
        st.setPadding(dp(12), dp(6), dp(12), dp(6))
        status = st
        f.root.addView(st, LinearLayout.LayoutParams(MATCH, WRAP))
        setContentView(f.root)
        dirty = false
        updateStatus()
    }

    private fun readLimited(u: Uri): ByteArray? {
        return try {
            val s = contentResolver.openInputStream(u) ?: return null
            s.use { input ->
                val out = java.io.ByteArrayOutputStream()
                val chunk = ByteArray(8192)
                var total = 0
                while (total <= MAX_BYTES) {
                    val n = input.read(chunk)
                    if (n < 0) break
                    out.write(chunk, 0, n)
                    total += n
                }
                out.toByteArray()
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun updateStatus() {
        val ed = edit ?: return
        status?.text = "خط: " + faDigits(ed.lineCount.toString()) + "  •  نویسه: " +
            faDigits(ed.length().toString()) + "  •  UTF-8" + (if (dirty) "  •  ذخیره‌نشده" else "")
    }

    private fun changeSize(delta: Float) {
        textSizeSp = (textSizeSp + delta).coerceIn(8f, 28f)
        edit?.textSize = textSizeSp
    }

    private fun toggleFind() {
        val row = findRow ?: return
        row.visibility = if (row.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        if (row.visibility == View.VISIBLE) findInput?.requestFocus()
    }

    private fun findNext(forward: Boolean) {
        val ed = edit ?: return
        val q = findInput?.text?.toString() ?: ""
        if (q.isEmpty()) return
        val t = ed.text.toString()
        var found: Int
        if (forward) {
            found = t.indexOf(q, ed.selectionEnd.coerceAtLeast(0), true)
            if (found < 0) found = t.indexOf(q, 0, true)
        } else {
            found = t.lastIndexOf(q, (ed.selectionStart - 1).coerceAtLeast(0), true)
            if (found < 0) found = t.lastIndexOf(q, t.length, true)
        }
        if (found < 0) {
            toast("پیدا نشد")
            return
        }
        ed.requestFocus()
        ed.setSelection(found, found + q.length)
    }

    private fun save() {
        val ed = edit ?: return
        val u = fileUri
        if (u == null || !canSave) {
            saveAs()
            return
        }
        val out = try {
            contentResolver.openOutputStream(u, "wt")
        } catch (e: Exception) {
            null
        }
        if (out == null) {
            saveAs()
            return
        }
        try {
            out.use { it.write(ed.text.toString().toByteArray(Charsets.UTF_8)) }
            dirty = false
            updateStatus()
            toast("ذخیره شد")
        } catch (e: Exception) {
            toast("ذخیره ناموفق بود")
        }
    }

    private fun saveAs() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "text/plain"
        i.putExtra(Intent.EXTRA_TITLE, fileName)
        try {
            startActivityForResult(i, REQ_SAVE_AS)
        } catch (e: Exception) {
            toast("ذخیره ممکن نشد")
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_SAVE_AS && resultCode == RESULT_OK && data != null) {
            val u = data.data
            if (u != null) {
                fileUri = u
                canSave = true
                fileName = displayName(u)
                save()
            }
        }
    }

    private fun openInStudio() {
        val ed = edit ?: return
        getSharedPreferences("nova_py", MODE_PRIVATE).edit().putString("code", ed.text.toString()).apply()
        startActivity(Intent(this, PyStudioActivity::class.java))
    }

    private fun formatJson() {
        val ed = edit ?: return
        try {
            val v = JSONTokener(ed.text.toString()).nextValue()
            val pretty = when (v) {
                is JSONObject -> v.toString(2)
                is JSONArray -> v.toString(2)
                else -> null
            }
            if (pretty == null) toast("JSON معتبر نیست") else ed.setText(pretty)
        } catch (e: Exception) {
            toast("JSON معتبر نیست")
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun togglePreview() {
        val ed = edit ?: return
        val h = holder ?: return
        val existing = previewView
        if (existing != null && existing.visibility == View.VISIBLE) {
            existing.visibility = View.GONE
            ed.visibility = View.VISIBLE
            return
        }
        val w = existing ?: WebView(this)
        if (existing == null) {
            w.settings.javaScriptEnabled = true
            w.settings.allowFileAccess = false
            w.settings.allowContentAccess = false
            h.addView(w, FrameLayout.LayoutParams(MATCH, MATCH))
            previewView = w
        }
        w.loadDataWithBaseURL("https://preview.local/", ed.text.toString(), "text/html", "UTF-8", null)
        w.visibility = View.VISIBLE
        ed.visibility = View.GONE
    }

    override fun onBackPressed() {
        if (dirty && canSave) {
            AlertDialog.Builder(this)
                .setMessage("تغییرات ذخیره نشده است. خارج می‌شوید؟")
                .setPositiveButton("ذخیره و خروج") { _, _ ->
                    save()
                    finish()
                }
                .setNegativeButton("خروج بدون ذخیره") { _, _ ->
                    dirty = false
                    finish()
                }
                .setNeutralButton("ماندن", null)
                .show()
            return
        }
        super.onBackPressed()
    }

    override fun onDestroy() {
        val w = previewView
        if (w != null) {
            (w.parent as? android.view.ViewGroup)?.removeView(w)
            w.destroy()
        }
        previewView = null
        super.onDestroy()
    }
}
