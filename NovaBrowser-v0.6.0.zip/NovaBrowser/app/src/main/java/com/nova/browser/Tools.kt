package com.nova.browser

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.widget.LinearLayout
import android.widget.TextView

internal class ToolFrame(val root: LinearLayout, val header: LinearLayout, val titleView: TextView)

/** Dark full-screen frame with a back button and title, used by the tool screens. */
@Suppress("DEPRECATION")
internal fun Activity.createToolFrame(title: String): ToolFrame {
    window.setBackgroundDrawable(ColorDrawable(C_BG))
    window.statusBarColor = C_STRIP
    window.navigationBarColor = C_BG

    val root = LinearLayout(this)
    root.orientation = LinearLayout.VERTICAL
    root.layoutDirection = View.LAYOUT_DIRECTION_RTL
    root.setBackgroundColor(C_BG)

    val header = LinearLayout(this)
    header.orientation = LinearLayout.HORIZONTAL
    header.gravity = Gravity.CENTER_VERTICAL
    header.setBackgroundColor(C_STRIP)
    header.setPadding(dp(8), dp(4), dp(8), dp(4))
    header.addView(iconButton(R.drawable.ic_back, 48, 24, C_TEXT) { finish() })
    val tv = TextView(this)
    tv.text = title
    tv.textSize = 17f
    tv.typeface = Typeface.DEFAULT_BOLD
    tv.setTextColor(C_TEXT)
    tv.setSingleLine(true)
    tv.ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
    tv.textDirection = View.TEXT_DIRECTION_FIRST_STRONG
    tv.setPadding(dp(8), 0, dp(8), 0)
    header.addView(tv, LinearLayout.LayoutParams(0, WRAP, 1f))
    root.addView(header, LinearLayout.LayoutParams(MATCH, WRAP))

    if (Build.VERSION.SDK_INT >= 35) {
        root.setOnApplyWindowInsetsListener { v, insets ->
            val types = WindowInsets.Type.systemBars() or
                WindowInsets.Type.displayCutout() or
                WindowInsets.Type.ime()
            val b = insets.getInsets(types)
            v.setPadding(b.left, b.top, b.right, b.bottom)
            WindowInsets.CONSUMED
        }
    }
    return ToolFrame(root, header, tv)
}

internal fun Context.displayName(uri: Uri): String {
    var name: String? = null
    try {
        val c = contentResolver.query(uri, null, null, null, null)
        if (c != null) {
            try {
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) name = c.getString(i)
                }
            } finally {
                c.close()
            }
        }
    } catch (e: Exception) {
        // ignore
    }
    if (name.isNullOrEmpty()) name = uri.lastPathSegment
    return name ?: "file"
}

internal fun Context.fileSize(uri: Uri): Long {
    var size = -1L
    try {
        val c = contentResolver.query(uri, null, null, null, null)
        if (c != null) {
            try {
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(OpenableColumns.SIZE)
                    if (i >= 0 && !c.isNull(i)) size = c.getLong(i)
                }
            } finally {
                c.close()
            }
        }
    } catch (e: Exception) {
        // ignore
    }
    return size
}

internal object FileOpener {
    private val CODE_EXT = listOf(
        "txt", "md", "html", "htm", "css", "js", "mjs", "ts", "json", "xml", "svg", "yml", "yaml",
        "py", "kt", "kts", "java", "c", "cpp", "h", "cs", "go", "rs", "php", "rb", "sh", "bat",
        "sql", "csv", "log", "ini", "gradle", "properties", "toml"
    )
    private val IMAGE_EXT = listOf("png", "jpg", "jpeg", "gif", "webp", "bmp")
    private val VIDEO_EXT = listOf("mp4", "mkv", "webm", "avi", "mov", "3gp")

    fun extOf(name: String): String {
        val i = name.lastIndexOf('.')
        return if (i >= 0) name.substring(i + 1).lowercase() else ""
    }

    fun kindOf(name: String, mime: String?): String {
        val ext = extOf(name)
        if (ext == "pdf" || mime == "application/pdf") return "pdf"
        if (ext == "glb" || ext == "gltf") return "3d"
        if (ext == "exe" || ext == "msi" || ext == "dll") return "win"
        if (CODE_EXT.contains(ext)) return "code"
        if (mime != null && (mime.startsWith("text/") || mime == "application/json" || mime == "application/xml")) return "code"
        if (IMAGE_EXT.contains(ext) || (mime != null && mime.startsWith("image/"))) return "image"
        if (VIDEO_EXT.contains(ext) || (mime != null && mime.startsWith("video/"))) return "video"
        return "other"
    }

    fun open(a: Activity, uri: Uri, name: String, mime: String?, forced: String?) {
        val kind = forced ?: kindOf(name, mime)
        val cls: Class<*>? = when (kind) {
            "pdf" -> PdfActivity::class.java
            "3d" -> Viewer3DActivity::class.java
            "code" -> CodeViewerActivity::class.java
            "win" -> WindowsFileActivity::class.java
            else -> null
        }
        if (cls != null) {
            val i = Intent(a, cls)
            i.data = uri
            i.putExtra("name", name)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            a.startActivity(i)
            return
        }
        try {
            val i = Intent(Intent.ACTION_VIEW)
            i.setDataAndType(uri, mime ?: "*/*")
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            a.startActivity(i)
        } catch (e: Exception) {
            a.toast("برنامه‌ای برای باز کردن این فایل نیست")
        }
    }
}
