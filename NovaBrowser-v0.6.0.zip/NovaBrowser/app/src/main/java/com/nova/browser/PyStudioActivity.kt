package com.nova.browser

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.SpannableString
import android.text.Spanned
import android.text.method.ScrollingMovementMethod
import android.text.style.ForegroundColorSpan
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.text.InputType
import org.json.JSONObject

private const val REQ_OPEN_PY = 4001
private const val REQ_SAVE_PY = 4002
private const val REQ_EXPORT = 4003

/**
 * Python 3D Studio: write Python (Pyodide inside a WebView), build a 3D model with the nova3d
 * library, preview it with model-viewer and export GLB / STL / OBJ.
 */
class PyStudioActivity : Activity() {
    private var webView: WebView? = null
    private var editor: EditText? = null
    private var console: TextView? = null
    private var editorArea: LinearLayout? = null
    private var ready = false
    private var previewOnly = false
    private var autoRotate = false
    private var envOn = true
    private var bgIndex = 0
    private val backgrounds = listOf("#0B0D26", "#000000", "#FFFFFF", "#2B2B2B", "#1E3A5F")
    private var pendingBytes: ByteArray? = null
    private var pendingName = "model.glb"
    private var pendingMime = "model/gltf-binary"

    private val snippets = listOf(
        Pair("import", "from nova3d import *\n"),
        Pair("box", "box(20, 20, 20)"),
        Pair("sphere", "sphere(10)"),
        Pair("cylinder", "cylinder(5, 20)"),
        Pair("cone", "cone(8, 15)"),
        Pair("torus", "torus(10, 3)"),
        Pair("move", ".move(0, 0, 10)"),
        Pair("rotate", ".rotate(0, 0, 45)"),
        Pair("scale", ".scale(2)"),
        Pair("color", ".color(\"orange\")"),
        Pair("+", " + "),
        Pair("-", " - "),
        Pair("&", " & "),
        Pair("scene", "scene()"),
        Pair("for", "for i in range(5):\n    "),
        Pair("math", "import math\n")
    )

    inner class Bridge {
        @JavascriptInterface
        fun event(kind: String, a: String, b: String, c: String) {
            runOnUiThread { handleEvent(kind, a, b, c) }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val f = createToolFrame("استودیوی پایتون ۳بعدی")
        f.header.addView(iconButton(R.drawable.ic_play, 44, 24, C_TAG2) { runCode() })
        f.header.addView(iconButton(R.drawable.ic_download, 44, 22, C_TEXT) { exportDialog() })
        f.header.addView(iconButton(R.drawable.ic_list, 44, 22, C_TEXT) { samplesDialog() })
        f.header.addView(iconButton(R.drawable.ic_more, 44, 22, C_TEXT) { moreDialog() })

        // --- 3D preview + python runtime ---
        val wv = WebView(this)
        wv.setBackgroundColor(Color.parseColor("#0B0D26"))
        val s = wv.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = false
        s.allowContentAccess = false
        wv.addJavascriptInterface(Bridge(), "Nova")
        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                if (request == null) return null
                val u = request.url
                if (u.host != "nova.local") return null
                val path = (u.path ?: "").removePrefix("/")
                val headers = HashMap<String, String>()
                headers["Access-Control-Allow-Origin"] = "*"
                return try {
                    val stream = assets.open(path)
                    WebResourceResponse(mimeFor(path), if (isTextPath(path)) "UTF-8" else null, 200, "OK", headers, stream)
                } catch (e: Exception) {
                    WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", headers, java.io.ByteArrayInputStream(ByteArray(0)))
                }
            }
        }
        webView = wv
        f.root.addView(wv, LinearLayout.LayoutParams(MATCH, 0, 5f))

        // --- editor area ---
        val area = LinearLayout(this)
        area.orientation = LinearLayout.VERTICAL
        editorArea = area

        val con = TextView(this)
        con.setBackgroundColor(Color.parseColor("#080A1E"))
        con.setTextColor(C_TEXT)
        con.typeface = Typeface.MONOSPACE
        con.textSize = 12f
        con.setPadding(dp(10), dp(6), dp(10), dp(6))
        con.movementMethod = ScrollingMovementMethod()
        con.textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        con.maxLines = 5
        con.minLines = 3
        console = con
        area.addView(con, LinearLayout.LayoutParams(MATCH, dp(84)))

        val chipScroll = HorizontalScrollView(this)
        chipScroll.isHorizontalScrollBarEnabled = false
        chipScroll.setBackgroundColor(C_TOOLBAR)
        val chips = LinearLayout(this)
        chips.orientation = LinearLayout.HORIZONTAL
        chips.setPadding(dp(6), dp(4), dp(6), dp(4))
        for (sn in snippets) {
            val chip = TextView(this)
            chip.text = sn.first
            chip.textSize = 13f
            chip.typeface = Typeface.MONOSPACE
            chip.setTextColor(C_TEXT)
            chip.background = roundRect(C_PILL, 14, C_PILL_STROKE, 1)
            chip.setPadding(dp(12), dp(6), dp(12), dp(6))
            chip.setOnClickListener { insertText(sn.second) }
            val lp = LinearLayout.LayoutParams(WRAP, WRAP)
            lp.setMargins(dp(3), 0, dp(3), 0)
            chips.addView(chip, lp)
        }
        chipScroll.addView(chips)
        area.addView(chipScroll, LinearLayout.LayoutParams(MATCH, WRAP))

        val ed = EditText(this)
        ed.typeface = Typeface.MONOSPACE
        ed.textSize = 14f
        ed.setTextColor(C_TEXT)
        ed.setBackgroundColor(Color.parseColor("#0E1030"))
        ed.gravity = Gravity.TOP or Gravity.START
        ed.textDirection = View.TEXT_DIRECTION_LTR
        ed.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
            InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        ed.setHorizontallyScrolling(false)
        ed.setPadding(dp(12), dp(8), dp(12), dp(8))
        ed.setText(loadSavedCode())
        editor = ed
        area.addView(ed, LinearLayout.LayoutParams(MATCH, 0, 1f))
        f.root.addView(area, LinearLayout.LayoutParams(MATCH, 0, 6f))

        setContentView(f.root)

        val offline = try {
            assets.open("pyodide/pyodide.js").close()
            true
        } catch (e: Exception) {
            false
        }
        wv.loadUrl("https://nova.local/pystudio.html" + (if (offline) "?offline=1" else ""))
        log("در حال آماده‌سازی پایتون…", C_MUTED)
    }

    override fun onPause() {
        saveCode()
        super.onPause()
    }

    override fun onDestroy() {
        saveCode()
        val wv = webView
        if (wv != null) {
            (wv.parent as? android.view.ViewGroup)?.removeView(wv)
            wv.destroy()
        }
        webView = null
        super.onDestroy()
    }

    // ------------------------------------------------------------------

    private fun mimeFor(path: String): String {
        val ext = FileOpener.extOf(path)
        return when (ext) {
            "html" -> "text/html"
            "js", "mjs" -> "text/javascript"
            "py" -> "text/plain"
            "json" -> "application/json"
            "wasm" -> "application/wasm"
            "zip" -> "application/zip"
            else -> "application/octet-stream"
        }
    }

    private fun isTextPath(path: String): Boolean {
        val ext = FileOpener.extOf(path)
        return ext == "html" || ext == "js" || ext == "mjs" || ext == "py" || ext == "json"
    }

    private fun prefsStore() = getSharedPreferences("nova_py", MODE_PRIVATE)

    private fun loadSavedCode(): String {
        val saved = prefsStore().getString("code", null)
        if (!saved.isNullOrEmpty()) return saved
        return try {
            assets.open("samples/01_basic_shapes.py").bufferedReader(Charsets.UTF_8).use { it.readText() }
        } catch (e: Exception) {
            "from nova3d import *\n\nscene(box(20, 20, 20))\n"
        }
    }

    private fun saveCode() {
        val ed = editor ?: return
        prefsStore().edit().putString("code", ed.text.toString()).apply()
    }

    private fun insertText(text: String) {
        val ed = editor ?: return
        val a = ed.selectionStart.coerceAtLeast(0)
        val b = ed.selectionEnd.coerceAtLeast(0)
        ed.text.replace(minOf(a, b), maxOf(a, b), text)
    }

    private fun log(text: String, color: Int) {
        val c = console ?: return
        val sp = SpannableString(text + "\n")
        sp.setSpan(ForegroundColorSpan(color), 0, sp.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        c.append(sp)
        if (c.length() > 6000) c.text = c.text.subSequence(c.length() - 4000, c.length())
        c.post {
            val l = c.layout
            if (l != null) {
                val y = l.getLineTop(c.lineCount) - c.height + c.paddingBottom
                c.scrollTo(0, maxOf(y, 0))
            }
        }
    }

    private fun handleEvent(kind: String, a: String, b: String, c: String) {
        when (kind) {
            "ready" -> {
                ready = true
                log("✓ پایتون آماده است. روی ▶ بزنید.", C_TAG2)
            }
            "output" -> log(a, C_TEXT)
            "error" -> log(a, C_DANGER)
            "done" -> {
                try {
                    val st = JSONObject(a)
                    val size = st.getJSONArray("size")
                    log(
                        "✓ " + faDigits(st.getInt("shapes").toString()) + " شکل، " +
                            faDigits(st.getInt("triangles").toString()) + " مثلث، اندازه " +
                            faDigits(size.getDouble(0).toString()) + "×" + faDigits(size.getDouble(1).toString()) + "×" +
                            faDigits(size.getDouble(2).toString()),
                        C_TAG2
                    )
                } catch (e: Exception) {
                    log("✓ انجام شد", C_TAG2)
                }
            }
            "export" -> startExport(a, b, c)
        }
    }

    private fun js(code: String) {
        webView?.evaluateJavascript(code, null)
    }

    private fun runCode() {
        val ed = editor ?: return
        if (!ready) {
            toast("پایتون هنوز آماده نیست")
            return
        }
        saveCode()
        log("▶ اجرا…", C_MUTED)
        js("runCode(" + JSONObject.quote(ed.text.toString()) + ")")
    }

    private fun exportDialog() {
        val items = arrayOf<CharSequence>("GLB — نمایش و بازی/وب", "STL — چاپ سه‌بعدی", "OBJ — نرم‌افزارهای مدل‌سازی")
        AlertDialog.Builder(this)
            .setTitle("ذخیره‌ی مدل")
            .setItems(items) { _, which ->
                val fmt = if (which == 0) "glb" else if (which == 1) "stl" else "obj"
                js("exportAs('" + fmt + "')")
            }
            .show()
    }

    private fun startExport(name: String, b64: String, mime: String) {
        try {
            pendingBytes = Base64.decode(b64, Base64.DEFAULT)
        } catch (e: Exception) {
            toast("آماده‌سازی فایل ناموفق بود")
            return
        }
        pendingName = name
        pendingMime = if (mime.isEmpty()) "application/octet-stream" else mime
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = pendingMime
        i.putExtra(Intent.EXTRA_TITLE, name)
        try {
            startActivityForResult(i, REQ_EXPORT)
        } catch (e: Exception) {
            toast("ذخیره ممکن نشد")
        }
    }

    private fun samplesDialog() {
        val names = try {
            (assets.list("samples") ?: arrayOf<String>()).filter { it.endsWith(".py") }.sorted()
        } catch (e: Exception) {
            ArrayList<String>()
        }
        if (names.isEmpty()) {
            toast("نمونه‌ای پیدا نشد")
            return
        }
        val labels = names.map { it.removeSuffix(".py").replace('_', ' ') as CharSequence }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("نمونه‌کدها")
            .setItems(labels) { _, which ->
                try {
                    val code = assets.open("samples/" + names[which]).bufferedReader(Charsets.UTF_8).use { it.readText() }
                    editor?.setText(code)
                    saveCode()
                } catch (e: Exception) {
                    toast("خواندن نمونه ناموفق بود")
                }
            }
            .show()
    }

    private fun moreDialog() {
        val items = arrayOf<CharSequence>(
            "باز کردن فایل .py",
            "ذخیره‌ی کد",
            "راهنمای توابع",
            "پاک کردن ویرایشگر",
            "ری‌استارت پایتون (توقف اجرا)",
            "چرخش خودکار مدل",
            "رنگ پس‌زمینه‌ی پیش‌نمایش",
            "نورپردازی محیطی",
            "بازنشانی دوربین",
            "پیش‌نمایش تمام‌صفحه / بازگشت"
        )
        AlertDialog.Builder(this)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> openPy()
                    1 -> savePy()
                    2 -> showHelp()
                    3 -> editor?.setText("from nova3d import *\n\n")
                    4 -> restartPython()
                    5 -> {
                        autoRotate = !autoRotate
                        js("setAuto(" + autoRotate + ")")
                    }
                    6 -> {
                        bgIndex = (bgIndex + 1) % backgrounds.size
                        js("setBg('" + backgrounds[bgIndex] + "')")
                    }
                    7 -> {
                        envOn = !envOn
                        js("setEnv(" + envOn + ")")
                    }
                    8 -> js("resetCam()")
                    else -> togglePreviewOnly()
                }
            }
            .show()
    }

    private fun togglePreviewOnly() {
        previewOnly = !previewOnly
        editorArea?.visibility = if (previewOnly) View.GONE else View.VISIBLE
    }

    private fun restartPython() {
        ready = false
        log("در حال راه‌اندازی دوباره‌ی پایتون…", C_MUTED)
        val offline = try {
            assets.open("pyodide/pyodide.js").close()
            true
        } catch (e: Exception) {
            false
        }
        webView?.loadUrl("https://nova.local/pystudio.html" + (if (offline) "?offline=1" else ""))
    }

    private fun openPy() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        try {
            startActivityForResult(i, REQ_OPEN_PY)
        } catch (e: Exception) {
            toast("انتخاب فایل ممکن نشد")
        }
    }

    private fun savePy() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "text/x-python"
        i.putExtra(Intent.EXTRA_TITLE, "model.py")
        try {
            startActivityForResult(i, REQ_SAVE_PY)
        } catch (e: Exception) {
            toast("ذخیره ممکن نشد")
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        val u: Uri = data.data ?: return
        when (requestCode) {
            REQ_OPEN_PY -> {
                try {
                    val text = contentResolver.openInputStream(u)?.use { it.readBytes() }
                    if (text == null || text.size > 1000000) {
                        toast("فایل خوانده نشد یا خیلی بزرگ است")
                    } else {
                        editor?.setText(String(text, Charsets.UTF_8))
                        saveCode()
                    }
                } catch (e: Exception) {
                    toast("خواندن فایل ناموفق بود")
                }
            }
            REQ_SAVE_PY -> {
                try {
                    val code = editor?.text?.toString() ?: ""
                    contentResolver.openOutputStream(u, "wt")?.use { it.write(code.toByteArray(Charsets.UTF_8)) }
                    toast("ذخیره شد")
                } catch (e: Exception) {
                    toast("ذخیره ناموفق بود")
                }
            }
            REQ_EXPORT -> {
                val bytes = pendingBytes
                if (bytes != null) {
                    try {
                        contentResolver.openOutputStream(u, "wt")?.use { it.write(bytes) }
                        toast("مدل ذخیره شد: " + pendingName)
                    } catch (e: Exception) {
                        toast("ذخیره ناموفق بود")
                    }
                }
                pendingBytes = null
            }
        }
    }

    private fun showHelp() {
        val text = "محورها: X راست، Y جلو، Z بالا.\n\n" +
            "شکل‌ها:\n" +
            "box(w, d, h) • cube(s) • sphere(r) • cylinder(r, h) • cone(r, h) • torus(R, r)\n" +
            "extrude([(x,y),...], h) — کشیدن چندضلعی\n" +
            "revolve([(r,z),...]) — چرخاندن نیم‌رخ\n" +
            "tube([(x,y,z),...], r) — لوله روی مسیر\n" +
            "surface(f, u, v) — سطح پارامتریک\n" +
            "heightmap(f, x, y, n, base) — سطح z=f(x,y) به‌صورت جسم توپر\n" +
            "gear(teeth, module, thickness, hole)\n\n" +
            "تبدیل‌ها:\n" +
            ".move(x,y,z) • .rotate(x,y,z) (درجه) • .scale(s) • .mirror('x') • .color('#ff8800')\n" +
            ".center() • .on_floor() • .volume() • .size()\n\n" +
            "ترکیب:\n" +
            "a + b (اجتماع) • a - b (تفریق) • a & b (اشتراک)\n" +
            "combine(a, b) — ادغام سریع بدون محاسبه\n" +
            "polar(m, n) — تکرار دایره‌ای • linear(m, n, dx, dy, dz)\n\n" +
            "نمایش: scene(a, b, ...)\n\n" +
            "نکته: ترکیب‌های a-b و a+b روی شکل‌های پرمثلث کند است؛ seg را کم کنید.\n" +
            "هشدار: فقط کدی را اجرا کنید که به آن اطمینان دارید."
        AlertDialog.Builder(this)
            .setTitle("راهنمای nova3d")
            .setMessage(text)
            .setPositiveButton("بستن", null)
            .show()
    }
}
