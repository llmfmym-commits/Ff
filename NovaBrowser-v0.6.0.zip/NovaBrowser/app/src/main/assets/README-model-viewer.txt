Optional offline 3D viewer:
put a copy of model-viewer.min.js (from https://cdn.jsdelivr.net/npm/@google/model-viewer@3.5.0/dist/model-viewer.min.js)
in this folder. If present, the 3D viewer works without internet.
