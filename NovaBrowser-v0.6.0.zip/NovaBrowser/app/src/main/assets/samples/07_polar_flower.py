# تکرار دایره‌ای: گل
from nova3d import *

petal = sphere(5, 16).scale(1, 0.4, 1.8).move(9, 0, 0).color("pink")
petals = polar(petal, 8)
center = sphere(4, 16).color("yellow")

scene(petals, center)
