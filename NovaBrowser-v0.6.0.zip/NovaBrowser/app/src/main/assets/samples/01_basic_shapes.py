# شکل‌های پایه
from nova3d import *

base = box(40, 40, 4).color("#3a3f6b")
tower = cylinder(7, 26).move(0, 0, 15).color("gold")
ball = sphere(9).move(0, 0, 37).color("#5B6CFF")
ring = torus(14, 2).move(0, 0, 4).color("pink")

scene(base, tower, ball, ring)
